// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// ============================================================
// Glcoin RPC commands for the Miner Permission Registry
//
// registerminer   <address> <kyc_id> <display_name>
//   Submit a mining application (no authority sig required).
//
// approveminer    <address> <authority_sig>
//   Approve a pending miner. Requires a valid authority signature.
//
// revokeminer     <address> <authority_sig> [reason]
//   Permanently revoke a miner. Requires a valid authority signature.
//
// suspendminer    <address> <authority_sig> <until_timestamp>
//   Temporarily suspend a miner until a given Unix timestamp.
//
// renewminer      <address> <authority_sig> <new_expires_at>
//   Update the expiry date for an approved miner (0 = no expiry).
//
// listminers      [status]
//   List miners filtered by status: pending|approved|revoked|suspended|all
//
// getminerinfo    <address>
//   Return the full record for a specific miner address.
//
// getminerregistrystats
//   Return aggregate counts and configuration.
// ============================================================

#include <rpc/minerregistry.h>

#include <chainparams.h>
#include <common/signmessage.h>
#include <consensus/params.h>
#include <kernel/chainparams.h>
#include <minerregistry.h>
#include <node/context.h>
#include <rpc/server.h>
#include <rpc/server_util.h>
#include <rpc/util.h>
#include <univalue.h>
#include <util/strencodings.h>
#include <util/time.h>

#include <memory>
#include <string>

// Global DB instance — initialised by AppInitMain() via InitMinerRegistryDB()
static std::unique_ptr<CMinerRegistryDB> g_miner_registry_db;

void InitMinerRegistryDB(const fs::path& datadir, bool in_memory)
{
    g_miner_registry_db = std::make_unique<CMinerRegistryDB>(
        datadir / "minerregistry", 1 << 20, in_memory);
}

CMinerRegistryDB* GetMinerRegistryDB()
{
    return g_miner_registry_db.get();
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
static std::string StatusString(uint8_t status)
{
    switch (status) {
    case MINER_STATUS_PENDING:   return "pending";
    case MINER_STATUS_APPROVED:  return "approved";
    case MINER_STATUS_REVOKED:   return "revoked";
    case MINER_STATUS_SUSPENDED: return "suspended";
    default:                     return "unknown";
    }
}

static UniValue RecordToJSON(const CMinerRecord& rec, bool include_notes = false)
{
    const int64_t now = GetTime<std::chrono::seconds>().count();
    UniValue obj(UniValue::VOBJ);
    obj.pushKV("address",          rec.address);
    obj.pushKV("kyc_id",           rec.kyc_id);
    obj.pushKV("display_name",     rec.display_name);
    obj.pushKV("status",           StatusString(rec.EffectiveStatus(now)));
    obj.pushKV("registered_at",    rec.registered_at);
    obj.pushKV("approved_at",      rec.approved_at);
    obj.pushKV("expires_at",       rec.expires_at);
    obj.pushKV("suspended_until",  rec.suspended_until);
    if (include_notes) obj.pushKV("notes", rec.notes);
    return obj;
}

// Verify that the caller supplied a valid authority signature for `action`
// on `address`.  Accepts signatures from the current hour and the previous
// hour to tolerate clock skew at signing time.
static void CheckAuthoritySignature(const std::string& action,
                                    const std::string& address,
                                    const std::string& sig_base64,
                                    const std::string& authority_address)
{
    if (authority_address.empty()) {
        // Dev/regtest: no authority key configured — skip verification.
        return;
    }
    const int64_t now_hour = GetTime<std::chrono::seconds>().count() / 3600;
    // Accept current hour and the previous hour to absorb clock skew.
    for (int64_t h : {now_hour, now_hour - 1}) {
        const std::string msg = MakeAuthorityMessage(action, address, h);
        if (VerifyAuthoritySignature(authority_address, msg, sig_base64)) return;
    }
    throw JSONRPCError(RPC_INVALID_PARAMETER,
        "Invalid authority signature. Sign the message: "
        "GLCOIN-MINER-" + action + ":<address>:<unix_time/3600> "
        "using signmessage with the authority address.");
}

// ---------------------------------------------------------------------------
// registerminer
// ---------------------------------------------------------------------------
static RPCMethod registerminer()
{
    return RPCMethod{
        "registerminer",
        "Submit a miner registration application.\n"
        "The record is created with status 'pending' and must be approved by the "
        "administrator using approveminer before the address can produce blocks.\n"
        "No authority signature is required — this is the public application step.",
        {
            {"address",      RPCArg::Type::STR, RPCArg::Optional::NO,
             "The Glcoin address that will appear in coinbase outputs."},
            {"kyc_id",       RPCArg::Type::STR, RPCArg::Optional::NO,
             "KYC reference identifier assigned by the administrator (max 64 chars)."},
            {"display_name", RPCArg::Type::STR, RPCArg::Optional::NO,
             "Human-readable name for this miner (max 128 chars)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",       "Miner address"},
                {RPCResult::Type::STR, "kyc_id",        "KYC reference"},
                {RPCResult::Type::STR, "display_name",  "Display name"},
                {RPCResult::Type::STR, "status",        "Always 'pending' on registration"},
                {RPCResult::Type::NUM, "registered_at", "Unix timestamp of registration"},
            },
        },
        RPCExamples{
            HelpExampleCli("registerminer",
                "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\" "
                "\"KYC-2026-001\" "
                "\"Alice Mining Ltd\"")
            + HelpExampleRpc("registerminer",
                "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\", "
                "\"KYC-2026-001\", "
                "\"Alice Mining Ltd\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address      = request.params[0].get_str();
            const std::string kyc_id       = request.params[1].get_str();
            const std::string display_name = request.params[2].get_str();

            if (address.empty())
                throw JSONRPCError(RPC_INVALID_PARAMETER, "address must not be empty");
            if (kyc_id.empty() || kyc_id.size() > 64)
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "kyc_id must be 1–64 characters");
            if (display_name.empty() || display_name.size() > 128)
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "display_name must be 1–128 characters");

            if (g_miner_registry_db->GetMiner(address)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Address is already registered");
            }

            CMinerRecord rec;
            rec.address       = address;
            rec.kyc_id        = kyc_id;
            rec.display_name  = display_name;
            rec.status        = MINER_STATUS_PENDING;
            rec.registered_at = GetTime<std::chrono::seconds>().count();

            if (!g_miner_registry_db->StoreMiner(rec)) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Failed to store registration record");
            }
            return RecordToJSON(rec);
        },
    };
}

// ---------------------------------------------------------------------------
// approveminer
// ---------------------------------------------------------------------------
static RPCMethod approveminer()
{
    return RPCMethod{
        "approveminer",
        "Approve a pending miner registration.\n"
        "Requires a valid signature from the administrator's authority key.\n\n"
        "To generate the signature:\n"
        "  glcoin-cli signmessage <authority_address> "
        "\"GLCOIN-MINER-APPROVE:<miner_address>:<unix_time/3600>\"\n\n"
        "The timestamp component is the current Unix time integer-divided by 3600 "
        "(rounded to the current hour). The previous hour is also accepted to absorb "
        "clock skew.",
        {
            {"address",       RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address to approve."},
            {"authority_sig", RPCArg::Type::STR, RPCArg::Optional::NO,
             "Base64 signature from signmessage with the authority key."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",     "Miner address"},
                {RPCResult::Type::STR, "status",      "Always 'approved' on success"},
                {RPCResult::Type::NUM, "approved_at", "Unix timestamp of approval"},
            },
        },
        RPCExamples{
            HelpExampleCli("approveminer",
                "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\" \"<base64_sig>\"")
            + HelpExampleRpc("approveminer",
                "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\", \"<base64_sig>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address   = request.params[0].get_str();
            const std::string sig_b64   = request.params[1].get_str();
            const std::string authority = Params().GetConsensus().minerAuthorityAddress;

            CheckAuthoritySignature("APPROVE", address, sig_b64, authority);

            auto rec = g_miner_registry_db->GetMiner(address);
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "Address not found in registry. Call registerminer first.");
            }
            if (rec->status == MINER_STATUS_APPROVED) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Miner is already approved");
            }

            const int64_t now = GetTime<std::chrono::seconds>().count();
            rec->status      = MINER_STATUS_APPROVED;
            rec->approved_at = now;

            if (!g_miner_registry_db->UpdateMiner(*rec)) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "Failed to update registry");
            }

            UniValue result(UniValue::VOBJ);
            result.pushKV("address",     rec->address);
            result.pushKV("status",      std::string{"approved"});
            result.pushKV("approved_at", rec->approved_at);
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// revokeminer
// ---------------------------------------------------------------------------
static RPCMethod revokeminer()
{
    return RPCMethod{
        "revokeminer",
        "Permanently revoke a miner's registration.\n"
        "Blocks from this address will be rejected from the next block onwards.\n"
        "Requires a valid authority signature.\n\n"
        "Sign: \"GLCOIN-MINER-REVOKE:<miner_address>:<unix_time/3600>\"",
        {
            {"address",       RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address to revoke."},
            {"authority_sig", RPCArg::Type::STR, RPCArg::Optional::NO,
             "Base64 signature from signmessage with the authority key."},
            {"reason",        RPCArg::Type::STR, RPCArg::Default{std::string{}},
             "Optional reason for revocation (stored in notes, max 256 chars)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address", "Miner address"},
                {RPCResult::Type::STR, "status",  "Always 'revoked' on success"},
            },
        },
        RPCExamples{
            HelpExampleCli("revokeminer",
                "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\" \"<base64_sig>\" "
                "\"Violated terms of service\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address   = request.params[0].get_str();
            const std::string sig_b64   = request.params[1].get_str();
            const std::string reason    = request.params.size() > 2
                ? request.params[2].get_str() : "";
            const std::string authority = Params().GetConsensus().minerAuthorityAddress;

            CheckAuthoritySignature("REVOKE", address, sig_b64, authority);

            auto rec = g_miner_registry_db->GetMiner(address);
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "Address not found in registry");
            }

            rec->status = MINER_STATUS_REVOKED;
            if (!reason.empty() && reason.size() <= 256) {
                rec->notes = reason;
            }

            if (!g_miner_registry_db->UpdateMiner(*rec)) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "Failed to update registry");
            }

            UniValue result(UniValue::VOBJ);
            result.pushKV("address", rec->address);
            result.pushKV("status",  std::string{"revoked"});
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// suspendminer
// ---------------------------------------------------------------------------
static RPCMethod suspendminer()
{
    return RPCMethod{
        "suspendminer",
        "Temporarily suspend a miner until a given Unix timestamp.\n"
        "The miner is automatically reinstated once the timestamp passes.\n"
        "Requires a valid authority signature.\n\n"
        "Sign: \"GLCOIN-MINER-SUSPEND:<miner_address>:<unix_time/3600>\"",
        {
            {"address",         RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address to suspend."},
            {"authority_sig",   RPCArg::Type::STR, RPCArg::Optional::NO,
             "Base64 signature from signmessage with the authority key."},
            {"until_timestamp", RPCArg::Type::NUM, RPCArg::Optional::NO,
             "Unix timestamp at which the suspension is automatically lifted."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",         "Miner address"},
                {RPCResult::Type::STR, "status",          "Always 'suspended' on success"},
                {RPCResult::Type::NUM, "suspended_until", "Unix timestamp of auto-reinstatement"},
            },
        },
        RPCExamples{
            HelpExampleCli("suspendminer",
                "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\" \"<base64_sig>\" 1800000000")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address       = request.params[0].get_str();
            const std::string sig_b64       = request.params[1].get_str();
            const int64_t     until_ts      = request.params[2].getInt<int64_t>();
            const std::string authority     = Params().GetConsensus().minerAuthorityAddress;

            if (until_ts <= GetTime<std::chrono::seconds>().count()) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "until_timestamp must be in the future");
            }

            CheckAuthoritySignature("SUSPEND", address, sig_b64, authority);

            auto rec = g_miner_registry_db->GetMiner(address);
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "Address not found in registry");
            }

            rec->status          = MINER_STATUS_SUSPENDED;
            rec->suspended_until = until_ts;

            if (!g_miner_registry_db->UpdateMiner(*rec)) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "Failed to update registry");
            }

            UniValue result(UniValue::VOBJ);
            result.pushKV("address",         rec->address);
            result.pushKV("status",          std::string{"suspended"});
            result.pushKV("suspended_until", rec->suspended_until);
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// renewminer
// ---------------------------------------------------------------------------
static RPCMethod renewminer()
{
    return RPCMethod{
        "renewminer",
        "Update the expiry date for an approved miner's registration.\n"
        "Pass 0 as new_expires_at to remove the expiry (no expiry).\n"
        "Requires a valid authority signature.\n\n"
        "Sign: \"GLCOIN-MINER-RENEW:<miner_address>:<unix_time/3600>\"",
        {
            {"address",        RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address."},
            {"authority_sig",  RPCArg::Type::STR, RPCArg::Optional::NO,
             "Base64 signature from signmessage with the authority key."},
            {"new_expires_at", RPCArg::Type::NUM, RPCArg::Optional::NO,
             "New expiry as Unix timestamp, or 0 to remove expiry."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",    "Miner address"},
                {RPCResult::Type::NUM, "expires_at", "New expiry timestamp (0 = never)"},
            },
        },
        RPCExamples{
            HelpExampleCli("renewminer",
                "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\" \"<base64_sig>\" 1900000000")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address      = request.params[0].get_str();
            const std::string sig_b64      = request.params[1].get_str();
            const int64_t     new_expiry   = request.params[2].getInt<int64_t>();
            const std::string authority    = Params().GetConsensus().minerAuthorityAddress;

            CheckAuthoritySignature("RENEW", address, sig_b64, authority);

            auto rec = g_miner_registry_db->GetMiner(address);
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "Address not found in registry");
            }

            rec->expires_at = new_expiry;

            if (!g_miner_registry_db->UpdateMiner(*rec)) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "Failed to update registry");
            }

            UniValue result(UniValue::VOBJ);
            result.pushKV("address",    rec->address);
            result.pushKV("expires_at", rec->expires_at);
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// listminers
// ---------------------------------------------------------------------------
static RPCMethod listminers()
{
    return RPCMethod{
        "listminers",
        "List all miners in the registry.\n"
        "Optional status filter: pending, approved, revoked, suspended, all (default: all).",
        {
            {"status", RPCArg::Type::STR, RPCArg::Default{std::string{"all"}},
             "Filter by status: pending|approved|revoked|suspended|all"},
        },
        RPCResult{
            RPCResult::Type::ARR, "", "",
            {
                {RPCResult::Type::OBJ, "", "",
                 {
                     {RPCResult::Type::STR, "address",        "Miner address"},
                     {RPCResult::Type::STR, "kyc_id",         "KYC reference"},
                     {RPCResult::Type::STR, "display_name",   "Display name"},
                     {RPCResult::Type::STR, "status",         "Effective status"},
                     {RPCResult::Type::NUM, "registered_at",  "Unix timestamp"},
                     {RPCResult::Type::NUM, "approved_at",    "Unix timestamp (0 if not approved)"},
                     {RPCResult::Type::NUM, "expires_at",     "Unix timestamp (0 = never)"},
                     {RPCResult::Type::NUM, "suspended_until","Unix timestamp (0 if not suspended)"},
                 }},
            },
        },
        RPCExamples{
            HelpExampleCli("listminers", "")
            + HelpExampleCli("listminers", "\"approved\"")
            + HelpExampleRpc("listminers", "\"pending\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string filter_str = request.params.empty()
                ? "all" : request.params[0].get_str();

            int filter = -1; // -1 = all
            if      (filter_str == "pending")   filter = MINER_STATUS_PENDING;
            else if (filter_str == "approved")  filter = MINER_STATUS_APPROVED;
            else if (filter_str == "revoked")   filter = MINER_STATUS_REVOKED;
            else if (filter_str == "suspended") filter = MINER_STATUS_SUSPENDED;
            else if (filter_str != "all") {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "status must be: pending|approved|revoked|suspended|all");
            }

            UniValue arr(UniValue::VARR);
            for (const auto& rec : g_miner_registry_db->ListMiners(filter)) {
                arr.push_back(RecordToJSON(rec, false));
            }
            return arr;
        },
    };
}

// ---------------------------------------------------------------------------
// getminerinfo
// ---------------------------------------------------------------------------
static RPCMethod getminerinfo()
{
    return RPCMethod{
        "getminerinfo",
        "Return the full registry record for a miner address.",
        {
            {"address", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",        "Miner address"},
                {RPCResult::Type::STR, "kyc_id",         "KYC reference"},
                {RPCResult::Type::STR, "display_name",   "Display name"},
                {RPCResult::Type::STR, "status",         "Effective status"},
                {RPCResult::Type::NUM, "registered_at",  "Unix timestamp of registration"},
                {RPCResult::Type::NUM, "approved_at",    "Unix timestamp of approval"},
                {RPCResult::Type::NUM, "expires_at",     "Unix timestamp of expiry (0=never)"},
                {RPCResult::Type::NUM, "suspended_until","Unix timestamp of suspension end"},
            },
        },
        RPCExamples{
            HelpExampleCli("getminerinfo", "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\"")
            + HelpExampleRpc("getminerinfo", "\"1A1zP1eP5QGefi2DMPTfTL5SLmv7Divf\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address = request.params[0].get_str();
            const auto rec = g_miner_registry_db->GetMiner(address);
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "Address not found in registry: " + address);
            }
            return RecordToJSON(*rec, false);
        },
    };
}

// ---------------------------------------------------------------------------
// getminerregistrystats
// ---------------------------------------------------------------------------
static RPCMethod getminerregistrystats()
{
    return RPCMethod{
        "getminerregistrystats",
        "Return aggregate statistics about the miner registry.",
        {},
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::NUM, "total",               "Total records"},
                {RPCResult::Type::NUM, "approved",            "Approved miners"},
                {RPCResult::Type::NUM, "pending",             "Pending applications"},
                {RPCResult::Type::NUM, "revoked",             "Revoked miners"},
                {RPCResult::Type::NUM, "suspended",           "Suspended miners"},
                {RPCResult::Type::NUM, "enforcement_height",  "Block height enforcement begins"},
                {RPCResult::Type::STR, "authority_address",   "Administrator authority address"},
            },
        },
        RPCExamples{
            HelpExampleCli("getminerregistrystats", "")
            + HelpExampleRpc("getminerregistrystats", "")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const auto& consensus = Params().GetConsensus();
            const auto all = g_miner_registry_db->ListMiners(-1);
            const int64_t now = GetTime<std::chrono::seconds>().count();

            int n_approved = 0, n_pending = 0, n_revoked = 0, n_suspended = 0;
            for (const auto& rec : all) {
                switch (rec.EffectiveStatus(now)) {
                case MINER_STATUS_APPROVED:  ++n_approved;  break;
                case MINER_STATUS_PENDING:   ++n_pending;   break;
                case MINER_STATUS_REVOKED:   ++n_revoked;   break;
                case MINER_STATUS_SUSPENDED: ++n_suspended; break;
                default: break;
                }
            }

            UniValue result(UniValue::VOBJ);
            result.pushKV("total",              static_cast<int>(all.size()));
            result.pushKV("approved",           n_approved);
            result.pushKV("pending",            n_pending);
            result.pushKV("revoked",            n_revoked);
            result.pushKV("suspended",          n_suspended);
            result.pushKV("enforcement_height", consensus.MinerRegistryHeight);
            result.pushKV("authority_address",  consensus.minerAuthorityAddress.empty()
                                                ? std::string{"(not configured — dev mode)"}
                                                : consensus.minerAuthorityAddress);
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------
void RegisterMinerRegistryRPCCommands(CRPCTable& t)
{
    static const CRPCCommand commands[]{
        {"mining", &registerminer},
        {"mining", &approveminer},
        {"mining", &revokeminer},
        {"mining", &suspendminer},
        {"mining", &renewminer},
        {"mining", &listminers},
        {"mining", &getminerinfo},
        {"mining", &getminerregistrystats},
    };
    for (const auto& c : commands) t.appendCommand(c.name, &c);
}
