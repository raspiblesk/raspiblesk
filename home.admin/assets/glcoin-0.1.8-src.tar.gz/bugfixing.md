# Glcoin Bug Fixes — 2026-04-26

## Bug 1 — Initial Block Download deadlock prevents mining on mainnet

### Status: FIXED

### File changed
`src/chain.h` — `CChain::IsTipRecent()`

### Root cause

`IsInitialBlockDownload()` (validation.cpp:1940) uses a cached flag that is set
by `UpdateIBDStatus()` (validation.cpp:3276). That function calls `IsTipRecent()`:

```cpp
// src/chain.h (before fix)
bool IsTipRecent(const arith_uint256& min_chain_work,
                 std::chrono::seconds max_tip_age) const
{
    const auto tip{Tip()};
    return tip &&
           tip->nChainWork >= min_chain_work &&
           tip->Time() >= Now<NodeSeconds>() - max_tip_age;
}
```

The default `max_tip_age` is `24h` (kernel/chainstatemanager_opts.h:24).
The Glcoin mainnet genesis block has timestamp `1744761600` (2025-04-16).

Because the genesis is more than 24 hours old and no blocks had been mined yet,
`tip->Time() >= Now() - 24h` was **permanently false**. `UpdateIBDStatus()` never
latched IBD to false, so `IsInitialBlockDownload()` returned `true` forever.

### Consequence

`getblocktemplate` in `src/rpc/mining.cpp` checks `miner.isInitialBlockDownload()`
and throws `"Glcoin Core is in initial sync and waiting for blocks..."` when it
returns true. Mining was therefore impossible on any fresh node.

Additionally, new blocks are only announced to peers when IBD is false
(validation.cpp:4381):

```cpp
if (!IsInitialBlockDownload() && ActiveTip() == pindex->pprev && m_options.signals)
    m_options.signals->NewPoWValidBlock(pindex, pblock);
```

So even if blocks were somehow submitted via `submitblock`, they were silently
not propagated to connected peers.

### Fix

When `nMinimumChainWork == 0` (explicitly declared fresh chain with no expected
accumulated work), the time-based staleness check serves no security purpose —
there is no "real chain ahead" to be behind. The fix skips the age check in that
case:

```cpp
// src/chain.h (after fix)
bool IsTipRecent(const arith_uint256& min_chain_work,
                 std::chrono::seconds max_tip_age) const
{
    const auto tip{Tip()};
    if (!tip || tip->nChainWork < min_chain_work) return false;
    // Skip time check on fresh chains (nMinimumChainWork == 0): requiring a
    // recent tip would prevent bootstrapping a chain whose genesis is older
    // than max_tip_age.
    if (min_chain_work == 0) return true;
    return tip->Time() >= Now<NodeSeconds>() - max_tip_age;
}
```

`nMinimumChainWork` is set to `uint256{}` (zero) for the Glcoin mainnet in
`src/kernel/chainparams.cpp`. The fix is therefore mainnet-only in practice;
Bitcoin-style chains with a real `nMinimumChainWork` are unaffected.

### How to apply

Rebuild `glcoind` and `glcoin-cli` after patching `src/chain.h`:

```bash
cmake --build build/ --target glcoind glcoin-cli -j$(nproc)
```

Nodes already in operation do **not** need `-maxtipage` once they have at least
one block with a current timestamp in their chain. The flag is only required to
bootstrap the very first block on a node that has never synced.

---

## Bug 2 — Genesis initial difficulty too low for 10-minute block target

### Status: KNOWN ISSUE (not yet fixed — requires chain restart)

### Location
`src/kernel/chainparams.cpp:120` — `CreateGenesisBlock(...)` call for `CMainParams`

```cpp
genesis = CreateGenesisBlock(
    "Glcoin Genesis 2026-04-16 - Built for the community",
    CScript() << "04678afdb0..." << OP_CHECKSIG,
    1744761600, 3, 0x207fffff, 1, 50 * COIN);
//                              ^
//                              nBits = minimum difficulty (regtest level)
```

`0x207fffff` is the absolute minimum difficulty: any SHA256d hash qualifies
on the first or second try. This is appropriate for regtest and testnet
bootstrap but causes mainnet blocks to be mined in milliseconds rather than
the targeted 10 minutes (`nPowTargetSpacing = 10 * 60`).

### Impact

The first 2016-block retarget window fills in seconds, producing
hundreds of blocks with correct timestamps but at near-zero work. At the
retarget boundary the difficulty adjustment caps at 4× per period
(`CalculateNextWorkRequired` in `src/pow.cpp:57-60`), so it takes many
retarget cycles for the chain to reach a real 10-minute cadence.

### Correct fix

Replace `0x207fffff` with `0x1d00ffff` (Bitcoin mainnet genesis difficulty)
and re-mine the genesis block to find a valid nNonce. This changes the
genesis hash, requiring a coordinated chain restart.

```cpp
// target nBits for ~10-minute initial blocks with CPU mining
genesis = CreateGenesisBlock(..., 1744761600, <NEW_NONCE>, 0x1d00ffff, 1, 50 * COIN);
consensus.hashGenesisBlock = genesis.GetHash();
assert(consensus.hashGenesisBlock == uint256{"<NEW_HASH>"});
```

A genesis miner utility needs to iterate nonces until
`SHA256d(header) ≤ target(0x1d00ffff)` — approximately 2³² hashes, taking
~30–60 seconds with a multi-threaded C implementation.

This fix is deferred pending a decision on whether to restart the mainnet chain.
