# Glcoin v0.1.x — Server Permission System

## Purpose

This document describes the production server setup for glcoin.org running on Debian Bookworm (12.x). It covers user permissions, the miner registry admin tools, the web admin panel, WireGuard VPN access, and the two-step signing workflow that keeps the authority key off the internet.

## File Locations

| Path | Purpose |
|------|---------|
| `/usr/local/bin/glcoind` | Glcoin daemon |
| `/usr/local/bin/glcoin-cli` | CLI interface |
| `/usr/local/bin/glcoin-admin` | Admin shell wrapper |
| `/etc/glcoin/glcoin.conf` | Node configuration (mode 0600) |
| `/etc/glcoin/admin.env` | Web admin environment (mode 0600) |
| `/var/lib/glcoin/.glcoin/` | Block data, wallets, LevelDB |
| `/var/lib/glcoin/.glcoin/minerregistry/` | Miner permission LevelDB |
| `/opt/glcoin-admin/` | Flask web admin panel |
| `/etc/systemd/system/glcoind.service` | Daemon systemd unit |
| `/etc/systemd/system/glcoin-admin.service` | Web admin systemd unit |
| `/etc/wireguard/wg0.conf` | WireGuard server config (mode 0600) |
| `/etc/wireguard/server.key` | WireGuard server private key (mode 0600) |
| `/etc/wireguard/server.pub` | WireGuard server public key |
| `/etc/wireguard/peers/<name>/` | Per-admin-peer key + client configs |

## Quick Install

```bash
# On the production server, as root:
sudo bash contrib/glcoin-server/install.sh /path/to/glcoin/build/bin
```

The installer runs 9 steps including WireGuard VPN setup (interactive — adds your first admin peer). Then edit `/etc/glcoin/glcoin.conf` and `/etc/glcoin/admin.env` before starting services.

## WireGuard VPN Network

Admin access to RPC and the web panel is secured through a WireGuard VPN. Nothing else opens these ports to the internet.

| Host | VPN IP |
|------|--------|
| glcoin.org server (`wg0`) | `10.99.0.1/24` |
| Admin peer 1 | `10.99.0.2/32` |
| Admin peer 2 | `10.99.0.3/32` |
| Additional admins | `10.99.0.x/32` |

**Public ports** (UFW allows): `22/tcp` (SSH), `1618/tcp` (P2P), `51820/udp` (WireGuard)

**VPN-only ports** (restricted to `wg0` interface): `1617/tcp` (RPC), `9090/tcp` (web admin)

### First-Time WireGuard Setup

```bash
# Install WireGuard and add your first admin peer:
sudo bash contrib/glcoin-server/wireguard/setup-wireguard.sh install
sudo bash contrib/glcoin-server/wireguard/setup-wireguard.sh --add-peer admin-laptop
```

### Connecting as an Admin

```bash
# Copy your peer config from the server:
scp root@glcoin.org:/etc/wireguard/peers/admin-laptop/admin-laptop.conf ~/glcoin-admin.conf

# Connect (Linux/macOS):
wg-quick up ~/glcoin-admin.conf

# Or import the QR code (shown during --add-peer) into the WireGuard mobile app.

# Once connected, access:
#   Web admin:  http://10.99.0.1:9090
#   RPC direct: http://10.99.0.1:1617  (with rpcuser/rpcpassword)
```

### Managing WireGuard Peers

```bash
# Add a new admin:
sudo bash setup-wireguard.sh --add-peer alice-workstation

# List configured peers:
sudo bash setup-wireguard.sh --list-peers

# Remove a peer (revokes access immediately):
sudo bash setup-wireguard.sh --remove-peer alice-workstation

# Check VPN status:
sudo bash setup-wireguard.sh --status
# or: wg show wg0
```

## Miner Registry Admin CLI

The `glcoin-admin` command wraps all miner registry RPC calls:

```bash
# Overview
glcoin-admin status

# List all miners by status
glcoin-admin list approved
glcoin-admin list pending

# Inspect one miner
glcoin-admin info <address>

# Register a new miner application (no authority key needed)
glcoin-admin register gc1q... KYC-2026-001 "Alice Mining Ltd"

# Get the signmessage command to run on air-gapped machine
glcoin-admin sign-approve gc1q...

# Apply the approval (after signing on air-gapped machine)
glcoin-admin approve gc1q... H<base64_signature>

# Revoke a miner
glcoin-admin sign-revoke gc1q...
glcoin-admin revoke gc1q... H<base64_sig> "Violated ToS"

# Suspend temporarily
glcoin-admin sign-suspend gc1q...
glcoin-admin suspend gc1q... H<base64_sig> 2027-01-01

# Update expiry
glcoin-admin sign-renew gc1q...
glcoin-admin renew gc1q... H<base64_sig> 2028-01-01
```

## Two-Step Signing Workflow

The authority key **never lives on the internet-connected server**. The signing workflow:

1. **On server** — run `glcoin-admin sign-approve <address>` to get the message
2. **On air-gapped machine** — run `glcoin-cli signmessage <authority_addr> "<message>"`
3. **On server** — run `glcoin-admin approve <address> <signature>`

The message includes an hourly timestamp so signatures expire automatically.

## Web Admin Panel

The Flask app runs on `10.99.0.1:9090` — accessible only through the WireGuard tunnel:

```bash
# Start
systemctl start glcoin-admin

# Connect via WireGuard on your admin device, then browse:
http://10.99.0.1:9090
```

Features:
- Dashboard: node status + pending applications
- Miners list: filterable by status
- Miner detail: full record + approve/revoke/suspend/renew forms
- Signing messages: generated automatically, valid for current hour

## Firewall Rules (UFW — set by setup-wireguard.sh)

| Port | Protocol | Action | Note |
|------|----------|--------|------|
| 22   | TCP | ALLOW public | SSH |
| 1618 | TCP | ALLOW public | Glcoin P2P mainnet |
| 51820 | UDP | ALLOW public | WireGuard VPN |
| 1617 | TCP | ALLOW `wg0` only | RPC — VPN-secured |
| 9090 | TCP | ALLOW `wg0` only | Web admin — VPN-secured |

## Authority Key Generation

```bash
# On air-gapped machine running Glcoin:
glcoin-cli getnewaddress "" bech32
# → gc1q...

# Export and store securely (hardware wallet or paper backup):
glcoin-cli dumpprivkey gc1q...

# Add to /etc/glcoin/glcoin.conf on production server:
minerauthorityaddress=gc1q...
# (No private key needed on server — only the address for verification)
```

## Activating Enforcement

1. Set `minerauthorityaddress` in glcoin.conf
2. Register and approve at least one miner
3. Choose a future block height (allow time for miners to register)
4. Set `minerregistryheight=<height>` in chainparams.cpp and rebuild
5. Distribute updated binaries before the activation height

**Warning**: Once enforcement is active, any block from an unapproved address is rejected by consensus. Ensure approved miners are online before activation.
