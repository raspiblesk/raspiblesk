# Glcoin v0.1.7 — Changes and Enhancements

**Base**: Bitcoin Core 31.x (fully preserved)
**Date**: 2026-04-22

---

## Summary

This release completes the v1 miner permission system, fixes all compilation issues, adds the server permission infrastructure, and documents the full development roadmap.

---

## New Files

### Core miner permission registry

| File | Description |
|------|-------------|
| `src/minerregistry.h` | `CMinerRecord` struct (serializable), `CMinerRegistryDB` class, authority-signature helpers |
| `src/minerregistry.cpp` | LevelDB implementation: store, update, get, list, remove, IsMinerApproved, EffectiveStatus |
| `src/rpc/minerregistry.h` | `InitMinerRegistryDB`, `GetMinerRegistryDB`, `RegisterMinerRegistryRPCCommands` |
| `src/rpc/minerregistry.cpp` | 8 RPC commands (see RPC section below) |

### IPFS infrastructure (inactive — activation height = INT_MAX)

| File | Description |
|------|-------------|
| `src/ipfslink.h` | Off-chain IPFS link store interface |
| `src/ipfslink.cpp` | LevelDB-backed node-local CID↔txid mapping |
| `src/consensus/ipfscommit.h` | On-chain IPFS commitment parsing |
| `src/consensus/ipfscommit.cpp` | `glc1` OP_RETURN payload validator |
| `src/util/cid.h` | Shared CID parser (CIDv0 + CIDv1 multibase) |
| `src/util/cid.cpp` | CID binary/string parsing with codec and multihash allowlists |
| `src/test/ipfscommit_tests.cpp` | Unit tests for IPFS commitment parsing |

### Server infrastructure

| File | Description |
|------|-------------|
| `contrib/glcoin-server/install.sh` | One-shot Debian Bookworm server setup |
| `contrib/glcoin-server/scripts/glcoin-admin.sh` | Admin CLI for miner registry |
| `contrib/glcoin-server/systemd/glcoind.service` | Systemd unit (hardened) |
| `contrib/glcoin-server/etc/glcoin.conf.template` | Production config template |
| `contrib/glcoin-server/web-admin/app.py` | Flask web admin panel |
| `contrib/glcoin-server/web-admin/templates/` | HTML templates (login, dashboard, miners, detail, register) |
| `contrib/glcoin-server/web-admin/requirements.txt` | Python dependencies (flask only) |

### Documentation

| File | Description |
|------|-------------|
| `doc/glcoin-roadmap.md` | Full v1→v4 development roadmap |
| `doc/glcoin-v1-server-setup.md` | Production server setup guide |
| `doc/glcoin-changes-v017.md` | This file |

---

## Modified Files

### `src/consensus/params.h`
Added two new fields to `Consensus::Params`:
```cpp
std::string minerAuthorityAddress;     // secp256k1 authority address for signing
int MinerRegistryHeight{INT_MAX};      // enforcement activation height (default: disabled)
int IPFSCommitHeight{INT_MAX};         // IPFS commitment activation height (default: disabled)
CAmount IPFSCommitBurnPerByte{0};      // burn fee per CID byte (default: 0 = no burn)
```

### `src/kernel/chainparams.cpp`
- Mainnet: `minerAuthorityAddress = ""` (empty = dev mode, no enforcement)
- Mainnet: `MinerRegistryHeight = INT_MAX` (disabled by default)
- Mainnet: `IPFSCommitHeight = INT_MAX` (disabled by default)
- Mainnet: `IPFSCommitBurnPerByte = 0`

### `src/validation.cpp`
Added `ContextualCheckBlock` enforcement:
```cpp
// Once MinerRegistryHeight is reached, every block's coinbase must pay
// to at least one address that is currently approved in the registry.
if (nHeight >= consensus.MinerRegistryHeight) {
    CMinerRegistryDB* registry = GetMinerRegistryDB();
    // ... check coinbase outputs ...
    if (!found_approved) {
        return state.Invalid(..., "miner-not-permitted", ...);
    }
}
```
Uses median-time-past for consistent timestamp evaluation across nodes.

### `src/init.cpp`
- `InitMinerRegistryDB(args.GetDataDirNet())` — opens registry LevelDB at startup
- `RegisterMinerRegistryRPCCommands(tableRPC)` — registers 8 new RPC commands

### `src/CMakeLists.txt`
Added to `glcoin_common` library:
- `util/cid.cpp`

Added to `glcoin_node` library:
- `minerregistry.cpp`
- `rpc/minerregistry.cpp`

---

## Bug Fixes

| Bug | Fix |
|-----|-----|
| `t.appendCommand(c.category, &c)` — wrong field | Changed to `t.appendCommand(c.name, &c)` — the name is extracted from the RPCMethod object |
| `TryParseHex` default returns `std::vector<std::byte>` | Changed to `TryParseHex<uint8_t>` in `util/cid.cpp` to avoid `reinterpret_cast` |

---

## New RPC Commands

All commands are in the `"mining"` category. Default behavior when `MinerRegistryHeight = INT_MAX`: registry is operational but not enforced.

| Command | Auth Required | Description |
|---------|:---:|-------------|
| `registerminer <address> <kyc_id> <name>` | No | Submit application (→ pending) |
| `approveminer <address> <sig>` | Yes | Approve pending miner |
| `revokeminer <address> <sig> [reason]` | Yes | Permanently revoke |
| `suspendminer <address> <sig> <until_ts>` | Yes | Temporarily suspend |
| `renewminer <address> <sig> <expiry_ts>` | Yes | Update expiry date |
| `listminers [status]` | No | List by status filter |
| `getminerinfo <address>` | No | Get full record |
| `getminerregistrystats` | No | Aggregate stats + config |

**Authority signature format**:
```
glcoin-cli signmessage <authority_address> "GLCOIN-MINER-<ACTION>:<miner_addr>:<unix_time/3600>"
```
Valid for current hour ± 1 hour (clock skew tolerance).

---

## Miner Record Fields

```
address         — Glcoin coinbase address (registry key)
kyc_id          — Off-chain KYC reference (max 64 chars)
display_name    — Human-readable name (max 128 chars)
status          — pending | approved | revoked | suspended
registered_at   — Unix timestamp
approved_at     — Unix timestamp (0 if pending)
expires_at      — Unix timestamp (0 = never)
suspended_until — Unix timestamp (0 if not suspended)
notes           — Admin notes (max 256 chars, not broadcast)
```

**Effective status** is computed at query time:
- `SUSPENDED` + `suspended_until` in past → treated as `APPROVED`
- `APPROVED` + `expires_at` in past → treated as `REVOKED`

---

## Activation Instructions

### To activate miner enforcement in production:

1. Generate authority key on air-gapped machine:
   ```bash
   glcoin-cli getnewaddress "" bech32
   glcoin-cli dumpprivkey <address>   # store on hardware wallet
   ```

2. Set in `src/kernel/chainparams.cpp` and rebuild:
   ```cpp
   consensus.minerAuthorityAddress = "gc1q...";
   consensus.MinerRegistryHeight   = 10000;   // choose future height
   ```

3. Register and approve miners before the activation height.

4. Distribute v0.2.x binaries. All nodes enforce the registry at height 10000.

### To activate IPFS commitments (future — v1.0):
```cpp
consensus.IPFSCommitHeight      = <chosen_height>;
consensus.IPFSCommitBurnPerByte = 1000; // satoshis per byte
```

---

## Architecture Notes

### Why `rpc/minerregistry.h` is included in `validation.cpp`

`GetMinerRegistryDB()` is declared in `rpc/minerregistry.h` because the global DB instance is owned there (initialized by `InitMinerRegistryDB`). In future, `GetMinerRegistryDB` should be moved to a non-RPC header (e.g., a standalone `node/minerregistry_global.h`) to keep validation and RPC layers properly separated. For v0.1.7 this is the minimal-change approach.

### Why IPFS files are not in CMakeLists.txt

`ipfslink.cpp` and `consensus/ipfscommit.cpp` exist but are **not compiled** by default. They will be added to CMakeLists.txt when their activation heights are set. This keeps v0.1.x build output identical to Bitcoin Core 31.x for all subsystems except the miner registry.
