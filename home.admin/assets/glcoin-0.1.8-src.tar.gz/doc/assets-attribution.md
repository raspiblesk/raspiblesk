The list of assets used in the glcoin source and their attribution can now be found in [contrib/debian/copyright](../contrib/debian/copyright).
