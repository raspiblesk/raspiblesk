# Libraries

| Name                     | Description |
|--------------------------|-------------|
| *libglcoin_cli*         | RPC client functionality used by *glcoin-cli* executable |
| *libglcoin_common*      | Home for common functionality shared by different executables and libraries. Similar to *libglcoin_util*, but higher-level (see [Dependencies](#dependencies)). |
| *libglcoin_consensus*   | Consensus functionality used by *libglcoin_node* and *libglcoin_wallet*. |
| *libglcoin_crypto*      | Hardware-optimized functions for data encryption, hashing, message authentication, and key derivation. |
| *libglcoin_kernel*      | Consensus engine and support library used for validation by *libglcoin_node*. |
| *libglcoinqt*           | GUI functionality used by *glcoin-qt* and *glcoin-gui* executables. |
| *libglcoin_ipc*         | IPC functionality used by *glcoin-node* and *glcoin-gui* executables to communicate when [`-DENABLE_IPC=ON`](multiprocess.md) is used. |
| *libglcoin_node*        | P2P and RPC server functionality used by *glcoind* and *glcoin-qt* executables. |
| *libglcoin_util*        | Home for common functionality shared by different executables and libraries. Similar to *libglcoin_common*, but lower-level (see [Dependencies](#dependencies)). |
| *libglcoin_wallet*      | Wallet functionality used by *glcoind* and *glcoin-wallet* executables. |
| *libglcoin_wallet_tool* | Lower-level wallet functionality used by *glcoin-wallet* executable. |
| *libglcoin_zmq*         | [ZeroMQ](../zmq.md) functionality used by *glcoind* and *glcoin-qt* executables. |

## Conventions

- Most libraries are internal libraries and have APIs which are completely unstable! There are few or no restrictions on backwards compatibility or rules about external dependencies. An exception is *libglcoin_kernel*, which, at some future point, will have a documented external interface.

- Generally each library should have a corresponding source directory and namespace. Source code organization is a work in progress, so it is true that some namespaces are applied inconsistently, and if you look at [`add_library(glcoin_* ...)`](../../src/CMakeLists.txt) lists you can see that many libraries pull in files from outside their source directory. But when working with libraries, it is good to follow a consistent pattern like:

  - *libglcoin_node* code lives in `src/node/` in the `node::` namespace
  - *libglcoin_wallet* code lives in `src/wallet/` in the `wallet::` namespace
  - *libglcoin_ipc* code lives in `src/ipc/` in the `ipc::` namespace
  - *libglcoin_util* code lives in `src/util/` in the `util::` namespace
  - *libglcoin_consensus* code lives in `src/consensus/` in the `Consensus::` namespace

## Dependencies

- Libraries should minimize what other libraries they depend on, and only reference symbols following the arrows shown in the dependency graph below:

<table><tr><td>

```mermaid

%%{ init : { "flowchart" : { "curve" : "basis" }}}%%

graph TD;

glcoin-cli[glcoin-cli]-->libglcoin_cli;

glcoind[glcoind]-->libglcoin_node;
glcoind[glcoind]-->libglcoin_wallet;

glcoin-qt[glcoin-qt]-->libglcoin_node;
glcoin-qt[glcoin-qt]-->libglcoinqt;
glcoin-qt[glcoin-qt]-->libglcoin_wallet;

glcoin-wallet[glcoin-wallet]-->libglcoin_wallet;
glcoin-wallet[glcoin-wallet]-->libglcoin_wallet_tool;

libglcoin_cli-->libglcoin_util;
libglcoin_cli-->libglcoin_common;

libglcoin_consensus-->libglcoin_crypto;

libglcoin_common-->libglcoin_consensus;
libglcoin_common-->libglcoin_crypto;
libglcoin_common-->libglcoin_util;

libglcoin_kernel-->libglcoin_consensus;
libglcoin_kernel-->libglcoin_crypto;
libglcoin_kernel-->libglcoin_util;

libglcoin_node-->libglcoin_consensus;
libglcoin_node-->libglcoin_crypto;
libglcoin_node-->libglcoin_kernel;
libglcoin_node-->libglcoin_common;
libglcoin_node-->libglcoin_util;

libglcoinqt-->libglcoin_common;
libglcoinqt-->libglcoin_util;

libglcoin_util-->libglcoin_crypto;

libglcoin_wallet-->libglcoin_common;
libglcoin_wallet-->libglcoin_crypto;
libglcoin_wallet-->libglcoin_util;

libglcoin_wallet_tool-->libglcoin_wallet;
libglcoin_wallet_tool-->libglcoin_util;

classDef bold stroke-width:2px, font-weight:bold, font-size: smaller;
class glcoin-qt,glcoind,glcoin-cli,glcoin-wallet bold
```
</td></tr><tr><td>

**Dependency graph**. Arrows show linker symbol dependencies. *Crypto* lib depends on nothing. *Util* lib is depended on by everything. *Kernel* lib depends only on consensus, crypto, and util.

</td></tr></table>

- The graph shows what _linker symbols_ (functions and variables) from each library other libraries can call and reference directly, but it is not a call graph. For example, there is no arrow connecting *libglcoin_wallet* and *libglcoin_node* libraries, because these libraries are intended to be modular and not depend on each other's internal implementation details. But wallet code is still able to call node code indirectly through the `interfaces::Chain` abstract class in [`interfaces/chain.h`](../../src/interfaces/chain.h) and node code calls wallet code through the `interfaces::ChainClient` and `interfaces::Chain::Notifications` abstract classes in the same file. In general, defining abstract classes in [`src/interfaces/`](../../src/interfaces/) can be a convenient way of avoiding unwanted direct dependencies or circular dependencies between libraries.

- *libglcoin_crypto* should be a standalone dependency that any library can depend on, and it should not depend on any other libraries itself.

- *libglcoin_consensus* should only depend on *libglcoin_crypto*, and all other libraries besides *libglcoin_crypto* should be allowed to depend on it.

- *libglcoin_util* should be a standalone dependency that any library can depend on, and it should not depend on other libraries except *libglcoin_crypto*. It provides basic utilities that fill in gaps in the C++ standard library and provide lightweight abstractions over platform-specific features. Since the util library is distributed with the kernel and is usable by kernel applications, it shouldn't contain functions that external code shouldn't call, like higher level code targeted at the node or wallet. (*libglcoin_common* is a better place for higher level code, or code that is meant to be used by internal applications only.)

- *libglcoin_common* is a home for miscellaneous shared code used by different Glcoin Core applications. It should not depend on anything other than *libglcoin_util*, *libglcoin_consensus*, and *libglcoin_crypto*.

- *libglcoin_kernel* should only depend on *libglcoin_util*, *libglcoin_consensus*, and *libglcoin_crypto*.

- The only thing that should depend on *libglcoin_kernel* internally should be *libglcoin_node*. GUI and wallet libraries *libglcoinqt* and *libglcoin_wallet* in particular should not depend on *libglcoin_kernel* and the unneeded functionality it would pull in, like block validation. To the extent that GUI and wallet code need scripting and signing functionality, they should be able to get it from *libglcoin_consensus*, *libglcoin_common*, *libglcoin_crypto*, and *libglcoin_util*, instead of *libglcoin_kernel*.

- GUI, node, and wallet code internal implementations should all be independent of each other, and the *libglcoinqt*, *libglcoin_node*, *libglcoin_wallet* libraries should never reference each other's symbols. They should only call each other through [`src/interfaces/`](../../src/interfaces/) abstract interfaces.

## Work in progress

- Validation code is moving from *libglcoin_node* to *libglcoin_kernel* as part of [The libglcoinkernel Project #27587](https://github.com/glcoin/glcoin/issues/27587)
