# Glcoin Session State — Preservation Document

**Date**: 2026-04-22
**Version**: v0.1.7
**Base**: Bitcoin Core 31.x (all functions preserved)
**Purpose**: Complete record of all work done, for resuming if `claude --resume` fails.

---

## What Glcoin Is

Glcoin is a Bitcoin Core 31.x fork. Phase 1 strategy: stay functionally identical to Bitcoin 31.x. Custom features (miner KYC, IPFS) are additive layers, all **disabled by default**. This allows existing Bitcoin tooling to work immediately on Glcoin without any changes.

---

## Branding Rule

- `Glcoin` — correct (capital G only)
- `glcoin` — correct (all lowercase, command names/paths)
- `GLCoin`, `GLcoin` — wrong
- Exception: genesis coinbase `"GLCoin Genesis 2026-04-16..."` is immutable (part of the block hash)

---

## Completed Work (v0.1.7)

### 1. Full Bitcoin→Glcoin Rebrand
- 2,179 files renamed/rebranded; Qt targets renamed; signet init bug fixed
- 11 orphan `bitcoin-*.cpp` / `bitcoind.cpp` files deleted from `src/`
- Version set to `0.1.7` in `CMakeLists.txt`

### 2. Genesis Block Hashes (verified with runtime asserts)

| Chain    | Hash |
|----------|------|
| mainnet  | `3563293d950fd5ba7840bdfa562cc896298378e970b984f3751522b8afa7bcb8` |
| testnet  | `3be2b4a0c17265a9d81f0e3768490e2bb55b0802462b785f985f6d64921e28ec` |
| signet   | `c8217f7dd403ecfd6e8528ed39db486f90da2dcedbaaebabeba56f6e148e80c5` |
| regtest  | `0892a55306d37d2532416b451b6988c94aa051bb105f183b76df986391cda868` |

### 3. Network Magic Bytes (all unique — no Bitcoin collision)

| Chain    | Bytes          | Mnemonic |
|----------|----------------|----------|
| mainnet  | `f9 b4 b4 d9`  | custom   |
| testnet  | `47 4c 54 4e`  | GLTn     |
| testnet4 | `47 4c 54 34`  | GLT4     |
| signet   | derived from challenge hash | unique |
| regtest  | `47 4c 52 54`  | GLRT     |

### 4. Ports

| Chain    | P2P   | RPC   |
|----------|-------|-------|
| mainnet  | 1618  | 1617  |
| testnet  | 11618 | 11617 |
| testnet4 | 21618 | 21617 |
| signet   | 31618 | 31617 |
| regtest  | 41618 | 41617 |

### 5. Activation Heights (all chains)

| Parameter         | Height   | Notes                         |
|-------------------|----------|-------------------------------|
| BIP34/65/66/CSV   | 1        | Active from block 1           |
| Segwit            | 1        | Active from block 1           |
| MinerRegistryHeight | 1000   | Enforcement at block 1000     |
| IPFSCommitHeight  | INT_MAX  | Disabled — v1.0 target        |

### 6. Miner Permission Registry

**New source files**: `src/minerregistry.h/.cpp`, `src/rpc/minerregistry.h/.cpp`

**8 RPC commands** (category: "mining"):
`registerminer`, `approveminer`, `revokeminer`, `suspendminer`, `renewminer`, `listminers`, `getminerinfo`, `getminerregistrystats`

Authority signature: `GLCOIN-MINER-<ACTION>:<miner_addr>:<unix_time/3600>` — valid ±1 hour.

`minerAuthorityAddress = ""` — dev mode (skip sig verification). Must be set before mainnet.

### 7. Bug Fixes

| File | Bug | Fix |
|------|-----|-----|
| `src/rpc/minerregistry.cpp` | `appendCommand(c.category)` | `appendCommand(c.name)` |
| `src/util/cid.cpp` | `TryParseHex` → `std::byte` mismatch | `TryParseHex<uint8_t>` |
| `src/rpc/minerregistry.cpp` | Missing `<chainparams.h>` | Added include |
| `src/rpc/minerregistry.cpp` | `get_int64()` removed in 31.x | `getInt<int64_t>()` |
| `src/validation.cpp` | `<script/standard.h>` removed | Replaced with `<addresstype.h>` |

### 8. Server Permission System (`contrib/glcoin-server/`)

| File | Description |
|------|-------------|
| `install.sh` | 9-step Debian Bookworm setup (WireGuard included) |
| `scripts/glcoin-admin.sh` | Admin CLI for all miner registry RPCs |
| `systemd/glcoind.service` | Hardened systemd unit |
| `etc/glcoin.conf.template` | Production config |
| `web-admin/app.py` | Flask panel (port 9090, WireGuard VPN only) |
| `wireguard/setup-wireguard.sh` | Full WireGuard lifecycle |

WireGuard network: `10.99.0.1/24` — RPC (1617) and web admin (9090) locked to `wg0`.

### 9. Build Status

- `glcoin-qt` builds and runs cleanly (verified)
- Regtest: 10 blocks mined, all softforks confirmed active at height 1
- All binaries: `glcoind`, `glcoin-cli`, `glcoin-qt`, `glcoin-tx`, `glcoin-util`, `glcoin-wallet`
- Version: `v0.1.7` / user agent: `/Gsatoshi:0.1.7/`

---

## Architecture Notes

- `GetMinerRegistryDB()` is in `rpc/minerregistry.h` — architectural debt, move to `node/` in future
- IPFS files (`ipfslink.cpp`, `consensus/ipfscommit.cpp`) exist but not in CMakeLists — intentional
- `util/cid.cpp` IS compiled (shared CID validator used by registry)
- RPCMethod registration: `t.appendCommand(c.name, &c)` — `c.name` from fn ptr constructor

---

## Pending (pre-launch)

See `doc/hardeningprestart.md` for the full 10-item launch gate checklist.

Critical path:
1. Generate authority keypair on air-gapped machine → set `minerAuthorityAddress`
2. Register + approve trusted miners before block 999
3. Live DNS seeds before public announcement
4. Multi-node P2P test (block propagation, mempool sync, reorg handling)

---

## Roadmap Summary

| Phase | Version | Goal |
|-------|---------|------|
| 1 | v0.1.x | Bitcoin fork foundation (current) |
| 1.5 | v0.2.x | Miner permission enforcement |
| 2 | v1.0 | IPFS on-chain |
| 3 | v2.0 | Structured data layer |
| 4 | v3.0 | Archive network |
| 5 | v3.5 | Proof of Authority (remove PoW) |
| 6 | v4.0 | DID + AI provenance + cross-chain oracle |

Full details: `doc/glcoin-roadmap.md` | Hardening: `doc/hardeningprestart.md`
How to resume: read this file + `git log --oneline -10`
