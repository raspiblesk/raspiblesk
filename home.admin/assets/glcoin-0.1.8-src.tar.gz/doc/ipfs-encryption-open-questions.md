# Glcoin IPFS Content Encryption — Open Questions

These questions are deferred until after the foundational pre-0.2.0 implementation
is complete. The foundation locks in only the wire format, key path, curve choice,
and HKDF domain strings. Everything below can be decided independently without
breaking that foundation.

---

## Locked-in decisions (not open)

These are settled and must not be revisited without a formal deprecation path:

| Decision | Value | Reason |
|---|---|---|
| Encryption key BIP32 path | `m/200'/1618'/account'/0/index` | Hardened at purpose + coin type; independent of spending path |
| Curve | X25519 (Curve25519) | Designed for ECDH; WebCrypto native; zero cross-protocol surface with secp256k1 |
| Content cipher | AES-256-GCM | AEAD; IETF standard; hardware acceleration everywhere |
| Key derivation | HKDF-SHA256 (RFC 5869) | Composable; domain-separated |
| Blob magic | `0x474C4345` ("GLCE") | Identifies encrypted blobs at the IPFS layer |
| Blob version byte | `0x01` | Allows future format evolution without magic change |
| HKDF domain string (wrap) | `"glcoin-ipfs-wrap-v1"` | Domain separation; version suffix allows future rotation |
| Recipient identification | `SHA256(x25519_pubkey)` | Blinded; 128-bit collision resistance |
| Envelope size | 80 bytes per recipient | 32 (id) + 12 (nonce) + 48 (wrapped DEK) — fixed, not variable |

---

## Open Questions

### Q1 — Sender authentication

**Question:** Should the encrypted blob be signed by the sender's key (proves who encrypted it), or fully anonymous (sender is not identifiable from the blob)?

**Trade-off:**
- Signed: aligns with Glcoin's provenance/accountability mission; recipient can verify the sender. Adds ~64 bytes to every blob.
- Anonymous: maximum privacy for the sender; attacker cannot determine who sent what even with the blob.

**What needs to be decided:** Which key signs (spending key? encryption key? ephemeral key?), and whether the signature is over the full blob or only the header.

**Dependency:** Does not affect the blob format if we reserve space in v1 header (the version byte handles this — v2 blobs can add a signature field).

---

### Q2 — Pubkey announcement mechanism

**Question:** How does a sender discover a recipient's X25519 encryption pubkey?

**Options:**
- **A** — OP_RETURN announcement transaction: wallet publishes `address → x25519_pubkey` on-chain. Permanent, decentralized, requires a new OP_RETURN format.
- **B** — Derived from on-chain spending: derive or publish encryption pubkey when the user first spends from an address. No new tx type needed, but delayed (requires prior spend).
- **C** — Off-chain / direct exchange: sender asks recipient out-of-band. Works always; not scalable.
- **D** — CIDLink embedded announcement: first CID commitment also announces encryption pubkey. Self-bootstrapping but conflates two concerns.

**What needs to be decided:** Whether this is a consensus-layer concern (new tx format) or a convention (OP_RETURN metadata).

**Dependency:** Does not affect blob format. Explorer and wallet UX only.

---

### Q3 — Self-encryption (sender as implicit recipient)

**Question:** Should the sender always be added as a recipient of their own encrypted content automatically?

**Arguments for:** Without this, the sender cannot re-read content they encrypted, cannot re-encrypt for a new recipient list, and cannot verify decryption worked.

**Arguments against:** Adds one envelope (80 bytes) to every blob; slightly increases IPFS content size and IPFS CID churn on re-encryption.

**What needs to be decided:** Whether the RPC enforces this automatically or leaves it to the caller.

**Dependency:** No impact on wire format. RPC behavior only.

---

### Q4 — Group / shared keys

**Question:** Should there be a concept of a group key — a shared X25519 keypair that an organization distributes to members, allowing "encrypt to the group" without listing every individual?

**Arguments for:** Real-world use case (organizational documents); simpler for N-member groups than N individual envelopes.

**Arguments against:** Group key is a single point of failure; any member compromise exposes all group content; member revocation requires re-keying the entire group and re-encrypting all content.

**What needs to be decided:** Whether this is a wallet-layer convention (just a keypair that multiple people hold) or a first-class protocol concept.

**Dependency:** No impact on v1 blob format — a group key is just another X25519 pubkey from the blob's perspective.

---

### Q5 — v1 scope: single-recipient vs multi-recipient

**Question:** The blob format supports N recipients (N field in header). Should v1 implement multi-recipient in the RPC/wallet layer, or only single-recipient?

**Current state:** The wire format already supports N recipients. The question is only whether the `storeencryptedipfslink` RPC accepts a list of recipients or only one.

**What needs to be decided:** RPC API surface for v1. Can be extended to multi-recipient in a point release without any wire format change.

---

### Q6 — Revocation and re-encryption UX

**Question:** Since cryptographic revocation is impossible (a recipient who has the blob can always decrypt it), what is the user-facing workflow for "revoking" access?

**The realistic answer:** Re-encrypt the content for a new recipient list, upload the new blob, commit a new CID. The old CID still exists and old recipients retain access to old content. Only forward-looking.

**What needs to be decided:**
- Should there be a `reencryptipfslink` RPC?
- Should the node track the "current canonical CID" for a piece of content across re-encryptions?
- Should the explorer show a re-encryption lineage (old CID → new CID)?

---

### Q7 — Explorer decryption UX

**Question:** How does the explorer allow a user to decrypt content client-side without ever sending the private key to the server?

**Options:**
- **A** — WebCrypto API in browser: user imports their X25519 key into the browser key store; decryption runs locally. Clean, but requires user to export their key from the wallet.
- **B** — Local wallet integration: explorer page calls a local glcoind RPC endpoint to decrypt. No key export; but requires a running local node.
- **C** — Downloadable blob: explorer serves the ciphertext blob as a download; user decrypts locally with a standalone tool.

**What needs to be decided:** Which path is the v1 explorer target. Does not affect any cryptographic design.

---

### Q8 — Key rotation

**Question:** When a user rotates their encryption key (increments the BIP32 index), how do others know which key index to use when encrypting new content?

**Problem:** If Alice is at key index 3, Bob needs to know to use index 3, not 0.

**Options:**
- On-chain pubkey announcement (see Q2) includes the current active index.
- The wallet always uses index 0 (never rotates the identity key; rotation means generating a new account).
- Rotation is manual and out-of-band.

**Dependency:** Tied to Q2 resolution.

---

## Notes

- All questions above are independent of the blob wire format. The format is fixed at v1.
- Questions Q1, Q2, Q8 are related (all touch key identity and authentication).
- Questions Q5, Q3 are low-stakes and can be decided by convention rather than protocol.
- Q6 and Q7 are explorer/UX concerns and do not affect the core cryptographic layer.
- Revisit this file when starting the GLC-RPC-Explorer implementation.
