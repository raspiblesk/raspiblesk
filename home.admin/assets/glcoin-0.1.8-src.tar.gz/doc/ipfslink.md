# Glcoin — IPFS Link Storage

Glcoin ships a built-in module that lets any node operator anchor
an [IPFS](https://ipfs.tech/) Content Identifier (CID) to a Glcoin
transaction and store it locally.

## Architecture

```
┌─────────────────────────────────────────────────┐
│                  glcoind / glcoin-qt             │
│                                                 │
│  RPC layer  ──►  src/rpc/ipfslink.cpp           │
│                       │                         │
│                       ▼                         │
│  Storage    ──►  src/ipfslink.cpp               │
│              (CIPFSLinkDB : CDBWrapper)         │
│                       │                         │
│                       ▼                         │
│  Disk       ──►  <datadir>/ipfslinks/           │
│                  (LevelDB)                      │
└─────────────────────────────────────────────────┘
```

- Records are **node-local** — they are not broadcast to peers and
  do not affect block validity or consensus.
- Each record links one `txid` to one IPFS CID.
- CIDs are validated (CIDv0 `Qm…` or CIDv1 `bafy…/b…`).

## RPC Commands

### `storeipfslink <txid> <cid> [description]`

Store an IPFS CID anchored to a transaction.

```bash
glcoin-cli storeipfslink \
  "<txid>" \
  "QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG" \
  "My whitepaper"
```

Returns:
```json
{
  "txid": "<txid>",
  "cid": "QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG",
  "description": "My whitepaper",
  "timestamp": 1744761600
}
```

### `getipfslink <txid>`

Retrieve the IPFS link for a transaction.

```bash
glcoin-cli getipfslink "<txid>"
```

### `listipfslinks [limit] [offset]`

List stored links, newest first. Supports pagination.

```bash
# All links (newest first)
glcoin-cli listipfslinks

# Page 1: first 20 records
glcoin-cli listipfslinks 20 0

# Page 2: next 20 records
glcoin-cli listipfslinks 20 20
```

### `removeipfslink <txid>`

Delete the link record for a transaction.

```bash
glcoin-cli removeipfslink "<txid>"
```

## Integration Status ✅ COMPLETE

All integration steps are done. The module is fully wired into the build and runtime:

| Step | File | Status |
|------|------|--------|
| `ipfslink.cpp` in build | `src/CMakeLists.txt:115` | ✅ |
| `rpc/ipfslink.cpp` in build | `src/CMakeLists.txt:264` | ✅ |
| DB init on startup | `src/init.cpp:1932` | ✅ |
| RPC registration | `src/init.cpp:1528` | ✅ |
| Unified CID validator | `src/util/cid.h/cpp` (both subsystems) | ✅ |
| Description sanitization | `src/ipfslink.cpp:IsValidIPFSDescription` | ✅ |
| Pagination | `src/ipfslink.cpp:ListLinks(limit,offset)` | ✅ |

Rebuild: `cmake --build build -j$(nproc)`
