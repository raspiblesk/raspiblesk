# Glcoin Development Roadmap

**Status**: Living document. Each phase builds on the previous. Order matters more than timeline.

**Last updated:** 2026-04-22

---

## Phase 1 — v0.1.x: Bitcoin Fork Foundation ✅ COMPLETE

**Goal**: Glcoin is a fully functional Bitcoin Core 31.x fork, rebranded and cleaned, with permissioned mining as an opt-in layer on top. All standard Bitcoin functions work identically.

### What is preserved from Bitcoin Core 31.x
- Full UTXO model and transaction validation
- Taproot, Segwit, all BIPs active from genesis
- P2P networking (same protocol)
- Wallet (descriptor wallets, hardware signer support)
- JSON-RPC API (all Bitcoin RPC commands)
- Mining (getblocktemplate, submitblock)
- Qt GUI
- All consensus rules

### What is changed
- Branding: Bitcoin → Glcoin everywhere
- Ports: mainnet P2P=1618, RPC=1617 (see blockclean.md §6.3)
- Genesis blocks: fresh Glcoin genesis for all chains
- BIP activation heights: reset to 0 or 1 (active from genesis)
- DNS seeds: cleared (no hardcoded peers)

### What is added (inactive by default)
- Miner Permission Registry (`src/minerregistry.h/cpp`) — LevelDB-backed, enforcement at `MinerRegistryHeight` ✅
- IPFS Link Store — node-local, not consensus (`src/ipfslink.cpp`) ✅
- IPFS Consensus Commitment — inactive (`IPFSCommitHeight = INT_MAX`) ✅
- Shared CID validator (`src/util/cid.h/cpp`) — strict binary multihash validation ✅
- IPFS description sanitization (UTF-8 + control-char checks) ✅
- IPFS list pagination (limit/offset) ✅
- RPC: `registerminer`, `approveminer`, `revokeminer`, `suspendminer`, `renewminer`, `listminers`, `getminerinfo`, `getminerregistrystats` ✅
- Consensus enforcement in `ContextualCheckBlock` (`miner-not-permitted` error) ✅

### Web infrastructure
- glcoin.org miner permission portal (`/home/vboxuser/porubing/glcoin-website/`) ✅
  - Public miner list, application form, admin panel with sign-helper
  - Flask backend calling glcoind RPC directly
  - All admin actions require authority-key signature (key never touches the server)

### Build status
All components build cleanly. `glcoin-qt`, `glcoind`, all CLI tools compile with no errors.

### Strategic reason for plain Bitcoin fork in Phase 1
The network needs real participants before it has custom rules. Existing Bitcoin tooling (miners, wallets, explorers) works immediately on Glcoin. This builds the operational foundation before enabling KYC enforcement or IPFS features.

---

## Phase 1.5 — v0.2.x: Miner Permission Enforcement (CURRENT — pending authority key)

**Goal**: Activate the miner registry for the Glcoin network. Only KYC-approved miners produce blocks.

### What changes
- Set `minerAuthorityAddress` to production key
- Set `MinerRegistryHeight` to activation block (announce 2 weeks in advance)
- Rebuild and distribute v0.2.x binaries
- All nodes running v0.2.x begin enforcing the registry at the activation height

### KYC Workflow
1. Miner submits application: `registerminer <address> <kyc_id> <name>`
2. Admin performs off-chain identity verification
3. Admin approves: `approveminer <address> <sig>`
4. Miner can now produce valid blocks

### What remains unchanged
- All Bitcoin consensus rules (PoW still runs, just with approved addresses only)
- All wallet and transaction functions
- IPFS still inactive

---

## Phase 2 — v1.0: IPFS On-Chain

**Goal**: IPFS CIDs written to blocks via OP_RETURN. Content becomes permanently anchored.

### Technical work required
1. Activate `IPFSCommitHeight` and `IPFSCommitBurnPerByte`
2. Deploy Trusted IPFS Entity registry (modeled on miner registry)
3. Implement automatic pinning by trusted entities (external software)
4. Index `glc1`-tagged OP_RETURN outputs
5. Extend RPC: `listipfslinks`, `getipfslinkbycid`, `verifyipfslink`

### Prerequisites
- At least 2 trusted IPFS entities KYC-verified and operational
- Content pinning infrastructure tested on signet/testnet first
- Burn fee calibrated (IPFSCommitBurnPerByte — economic gate against spam)

### OP_RETURN payload format
```
"glc1" + txid_anchor(32 bytes) + cid_bytes(34-44 bytes)
Total: 70-80 bytes (within OP_RETURN limit)
```

---

## Phase 3 — v2.0: Structured Data Layer

**Goal**: DAG-CBOR structured content, mutable pointers (IPNS-on-chain), REST API.

### Technical work
- Schema registry anchored on-chain
- `glcaddr → current_cid` mutable pointer records
- ZMQ subscriptions for IPFS events
- REST API for link index (no full node needed for queries)
- Update chains: `IPFS_FLAG_UPDATE` referencing previous transaction

---

## Phase 4 — v3.0: Archive Network

**Goal**: Long-term preservation at institutional scale.

### Technical work
- Full archive node KYC tier (universities, libraries, government)
- Content availability proofs (cryptographic, anchored on-chain)
- Block explorer 2.0 with content browsing

---

## Phase 5 — v3.5: Proof of Authority

**Goal**: Remove PoW entirely. Block production by validator signatures.

### Why this is safe at v3.5
By this point, the validator set has been running for months or years. Their performance record is on-chain. The network is permissioned — there is no Sybil threat to defend against with hash power.

### Technical work
- `PoAActivationHeight` in `Consensus::Params`
- Validator signature set replaces hash target in block validation
- Deterministic rotation schedule
- Slashing for equivocation (double-signing)
- Validator federation coordination protocol

---

## Phase 6 — v4.0: Trust Infrastructure

**Goal**: Glcoin as the identity and provenance layer for the broader ecosystem.

### Components
- W3C DID compatible identity (did:glc:...)
- Verifiable Credentials (KYC attestations, licenses)
- Programmable content contracts (deliberately non-Turing-complete)
- AI data provenance module (dataset → model lineage on-chain)
- Cross-chain notarization oracle (Ethereum bridge)

---

## Invariants Across All Phases

The following NEVER changes regardless of phase:

1. **Bitcoin transaction model** — UTXO, signatures, scripts preserved forever
2. **Glcoin-specific features are additive** — no existing function is removed
3. **Authority key stays air-gapped** — never exposed on internet-connected server
4. **IPFS and mining are decoupled** — IPFS is never part of mining competition
5. **KYC is off-chain** — the registry stores references, not personal data
