# Glcoin — IPFS Implementation Reference

**Date:** 2026-04-22  
**Scope:** Everything currently in the codebase — what is implemented, where it lives, how it works, and what still needs to be wired up before it is active.

---

## 1. Overview

Glcoin contains two distinct IPFS subsystems that serve different purposes and operate at different layers of the node:

| Subsystem | Layer | Consensus-critical? | Status |
|-----------|-------|---------------------|--------|
| Off-chain Link Store | Storage / RPC / GUI | No | Code complete and perfected; **not yet wired into build** |
| Consensus Commitment | Block validation | Yes | Code complete and perfected; **not yet wired into consensus** |

Both subsystems share a single, strict CID validator (`src/util/cid.h`) so they can never diverge in what they accept. All consensus parameters are declared with safe disabled defaults. The code is production-ready — the integration steps in section 6 are the only remaining work before activation.

---

## 2. Shared CID Validator — `src/util/cid.h` / `src/util/cid.cpp`

This module is the foundation of both IPFS subsystems. It is the single, authoritative CID validator for all Glcoin IPFS code.

### 2.1 Purpose

Provides a strict binary-level CID parser that both the off-chain link store and the consensus commitment layer use. Before this module existed, each subsystem had its own validator — the off-chain store used a loose string heuristic while the consensus layer used a strict binary parser. They are now unified.

### 2.2 `ParsedCID` struct

```cpp
namespace cid {

struct ParsedCID {
    unsigned int         version;   // 0 = CIDv0, 1 = CIDv1
    uint64_t             codec;     // multicodec (CIDv0 implicit: dag-pb = 0x70)
    uint64_t             hash_fn;   // multihash function code
    unsigned int         hash_len;  // digest length in bytes
    std::vector<uint8_t> bytes;     // raw binary CID (no multibase prefix)
};

} // namespace cid
```

### 2.3 `cid::ParseBytes` — binary-level parser

Takes raw CID bytes (no multibase prefix) and returns a `ParsedCID` or `std::nullopt`.

**CIDv0** (exactly 34 bytes):
- Bytes 0–1 must be `0x12 0x20` (sha2-256 multihash prefix)
- Remaining 32 bytes are the sha2-256 digest
- Version = 0, codec implicitly set to `dag-pb` (0x70)

**CIDv1** (variable length, 35–44 bytes):
- Unsigned LEB128 varints: version (must be 1), codec, hash_fn, hash_len
- Digest bytes follow immediately
- Total byte count must equal exactly `varint_bytes + hash_len`
- Codec and multihash function must be on the allowlists

**Codec allowlist:**

| Code | Name |
|------|------|
| `0x55` | raw |
| `0x70` | dag-pb |
| `0x71` | dag-cbor |
| `0x72` | libp2p-key |
| `0x0129` | dag-json |

**Multihash allowlist:**

| Code | Name | Digest length |
|------|------|---------------|
| `0x12` | sha2-256 | 32 bytes |
| `0x13` | sha2-512 | 64 bytes |
| `0x16` | sha3-256 | 32 bytes |
| `0x1B` | keccak-256 | 32 bytes |
| `0x1E` | blake3 | 32 bytes |
| `0xB220` | blake2b-256 | 32 bytes |
| `0xB260` | blake2s-256 | 32 bytes |

Any codec or multihash not on these lists causes `ParseBytes` to return `std::nullopt`.

### 2.4 `cid::ParseString` — string parser with multibase decoding

Takes a human-readable CID string (multibase-encoded), decodes the encoding, then calls `ParseBytes`.

**Supported multibase prefixes:**

| Prefix | Encoding | Example |
|--------|----------|---------|
| `Q` (implicit CIDv0) | base58btc, no prefix char | `QmYwAPJ…` |
| `b` | base32 lowercase, no padding | `bafybei…` |
| `B` | base32 uppercase, no padding | `BAFYBEI…` |
| `z` | base58btc | `z5ZnPHv…` |
| `f` | base16 lowercase | `f0170122…` |

CIDv0 special case: the entire string (starting with `"Qm"`) is base58btc-encoded — there is no separate multibase prefix character. The string must be exactly 46 characters. Full base58btc charset is validated before decoding.

For base32 inputs (`b`/`B`): padding is computed and added automatically before calling `DecodeBase32`, since IPFS does not include `=` padding in multibase strings.

### 2.5 `cid::IsValid` — convenience wrapper

```cpp
inline bool IsValid(const std::string& cid_str) {
    return ParseString(cid_str).has_value();
}
```

Used by `IsValidIPFSCID()` in `ipfslink.cpp`.

### 2.6 Build target

`src/util/cid.cpp` is compiled into `glcoin_common` (the shared library used by node, wallet, and GUI). Both IPFS subsystems link against `glcoin_common` and thus share the same validator binary.

---

## 3. Subsystem A — Off-chain IPFS Link Store

### 3.1 Purpose

Allows a node operator to attach an IPFS CID to any Glcoin transaction and store that association locally. Records are private to the node — not broadcast, not consensus-critical, deletable.

### 3.2 Source files

| File | Purpose |
|------|---------|
| `src/ipfslink.h` | `CIPFSLink` struct, `CIPFSLinkDB` class, `IsValidIPFSCID()`, `IsValidIPFSDescription()` |
| `src/ipfslink.cpp` | LevelDB implementation, UTF-8 validator, pagination |
| `src/rpc/ipfslink.h` | `InitIPFSLinkDB()`, `GetIPFSLinkDB()`, `RegisterIPFSLinkRPCCommands()` |
| `src/rpc/ipfslink.cpp` | 4 RPC command implementations |
| `src/qt/ipfslinksdialog.h` | Qt dialog class |
| `src/qt/ipfslinksdialog.cpp` | Qt dialog implementation |

### 3.3 Data model

```cpp
struct CIPFSLink {
    uint256     txid;        // on-chain anchor transaction
    std::string cid;         // IPFS CID (human-readable multibase string)
    std::string description; // optional label (max 256 bytes, valid UTF-8)
    int64_t     timestamp;   // Unix time of local storage
};
```

**LevelDB key layout:**
```
Key:   'I' (1 byte) + txid (32 bytes) = 33 bytes
Value: serialised CIPFSLink (DataStream format, in-order fields)
```

**Database location:** `<datadir>/ipfslinks/` (LevelDB, 1 MiB block cache)

### 3.4 CID validation

`IsValidIPFSCID(cid)` delegates to `cid::IsValid(cid)` which calls `cid::ParseString`. This uses the identical strict binary multihash parser as the consensus commitment layer — the two subsystems accept exactly the same set of CIDs.

### 3.5 Description validation (`IsValidIPFSDescription`)

Rules enforced at write time:
- Maximum 256 bytes
- No C0 control characters (U+0000–U+001F) except horizontal tab (U+0009)
- No DEL (U+007F)
- Well-formed UTF-8 — validated by a built-in state machine that also rejects:
  - Overlong encodings
  - UTF-16 surrogates (U+D800–U+DFFF)
  - Codepoints beyond U+10FFFF

### 3.6 Storage behaviour

- **Idempotent writes:** `StoreLinkForTx` rejects overwriting an existing record for the same txid.
- **Validation at write:** Both CID and description are validated before the write is attempted.
- **Corrupt entries:** `ListLinks` silently skips entries that fail deserialization.
- **Sort order:** Results are sorted newest-first by timestamp before pagination is applied.

### 3.7 Pagination (`ListLinks`)

```cpp
std::vector<CIPFSLink> ListLinks(size_t limit = 0, size_t offset = 0) const;
```

- `limit = 0` returns all records (no limit)
- `offset` skips the first N records (after sort, before limit)
- Sorting happens before pagination, so results are always consistent

### 3.8 RPC interface

All four commands are in the `"ipfs"` RPC category. The node must be started with the DB initialised (see section 6) for any of these to work.

---

#### `storeipfslink <txid> <cid> [description]`

Store an IPFS CID anchored to a transaction.

**Parameters:**
| # | Name | Type | Required | Description |
|---|------|------|----------|-------------|
| 1 | txid | STR_HEX | Yes | Transaction ID (64 hex chars) |
| 2 | cid | STR | Yes | IPFS CID (validated against strict allowlists) |
| 3 | description | STR | No | Label: max 256 bytes, valid UTF-8, no control chars |

**Returns:**
```json
{ "txid": "…", "cid": "…", "description": "…", "timestamp": 1744761600 }
```

**Errors:**
- `RPC_INVALID_PARAMETER` — invalid CID (bad multibase, unknown codec/multihash), invalid description (control chars, bad UTF-8, too long), or record already exists for this txid

---

#### `getipfslink <txid>`

Retrieve the stored link for a transaction. Returns the same JSON object as `storeipfslink`.

---

#### `listipfslinks [limit] [offset]`

List stored records, newest first.

| # | Name | Type | Default | Description |
|---|------|------|---------|-------------|
| 1 | limit | NUM | 0 | Max records to return (0 = all) |
| 2 | offset | NUM | 0 | Records to skip from the newest end |

```bash
# Page 1: newest 10
glcoin-cli listipfslinks 10 0

# Page 2: next 10
glcoin-cli listipfslinks 10 10
```

---

#### `removeipfslink <txid>`

Delete the link record for a transaction. Returns `true` if found and deleted.

---

### 3.9 Qt GUI (`IPFSLinksDialog`)

Located in `src/qt/ipfslinksdialog.h/.cpp`.

- **Store form:** txid, CID, description inputs + Store button
- **Links table:** Timestamp, Txid, CID, Description columns; single-row selection
- **Buttons:** Refresh, Open in IPFS gateway (`https://ipfs.io/ipfs/<cid>`), Remove
- **CID inspector:** Paste a CID to see its multibase encoding, codec and hash function (heuristic classification — not authoritative)
- **Status line:** green/red feedback on operations

---

## 4. Subsystem B — Consensus IPFS Commitment

### 4.1 Purpose

An optional, per-block mechanism for anchoring one IPFS CID to a specific non-coinbase transaction. This commitment is part of block data, validated by all nodes, and immutable once confirmed.

### 4.2 Source files

| File | Purpose |
|------|---------|
| `src/consensus/ipfscommit.h` | Constants, `IPFSCommitment` struct, function declarations |
| `src/consensus/ipfscommit.cpp` | Implementation (delegates CID parsing to `cid::ParseBytes`) |
| `src/test/ipfscommit_tests.cpp` | Comprehensive Boost.Test suite |

### 4.3 OP_RETURN payload format

```
OP_RETURN  <payload>

Payload layout (≤ 80 bytes total):
┌──────────┬───────────────┬──────────────────────────┐
│  "glc1"  │  txid_anchor  │  cid_bytes               │
│  4 bytes │  32 bytes     │  34–44 bytes             │
└──────────┴───────────────┴──────────────────────────┘

IPFS_COMMIT_MAGIC    = {'g', 'l', 'c', '1'}
IPFS_COMMIT_MAX_PAYLOAD  = 80  bytes
IPFS_COMMIT_MIN_PAYLOAD  = 70  bytes (4 + 32 + 34)
IPFS_COMMIT_MAX_CID_SIZE = 44  bytes
```

### 4.4 `IPFSCommitment` struct

```cpp
struct IPFSCommitment {
    uint256              txid_anchor;  // non-coinbase tx in the same block
    std::vector<uint8_t> cid_bytes;   // raw binary CID (no multibase prefix)
    unsigned int         version;     // 0 = CIDv0, 1 = CIDv1
    uint64_t             codec;       // multicodec
    uint64_t             hash_fn;     // multihash function code
    unsigned int         hash_len;    // digest length in bytes
};
```

### 4.5 CID parsing

`ParseCIDBytes(bytes)` in `ipfscommit.cpp` now delegates to `cid::ParseBytes(bytes)` from `src/util/cid.h` and converts the result to an `IPFSCommitment`. The API of `ipfscommit.h` is unchanged — all existing tests continue to work without modification.

### 4.6 Consensus rules (`CheckBlockIPFSCommitment`)

**Rule 1 — Optional:** A block with no `glc1` OP_RETURN output is always valid.

**Rule 2 — Malformed commitment is height-gated:** A malformed `glc1` output is rejected only at `nHeight >= params.IPFSCommitHeight`. Before activation it is treated as an ordinary OP_RETURN.

**Rule 3 — Anchor must exist (always enforced):** If a well-formed commitment is present, `txid_anchor` must be a non-coinbase transaction in the same block. Enforced regardless of height.

**Rule 4 — Anti-spam burn (post-activation, configurable):** From `params.IPFSCommitHeight` onwards, if `params.IPFSCommitBurnPerByte > 0`, the anchor transaction must contain OP_RETURN outputs summing to at least `cid_bytes.size() × IPFSCommitBurnPerByte` satoshis.

### 4.7 Consensus error codes

| Code | Meaning |
|------|---------|
| `ipfs-commit-too-large` | Payload > 80 bytes |
| `ipfs-commit-too-small` | Payload < 70 bytes |
| `ipfs-commit-bad-cid` | CID bytes failed `cid::ParseBytes` |
| `ipfs-commit-duplicate` | More than one `glc1` output in coinbase |
| `ipfs-commit-anchor-missing` | `txid_anchor` not found in block |
| `ipfs-commit-anchor-underpaid` | Anchor tx burned insufficient satoshis |

### 4.8 Test suite (`src/test/ipfscommit_tests.cpp`)

15 tests covering: CIDv0/CIDv1 parse, unknown codec rejection, wrong length rejection, round-trip (build→extract), duplicate detection, bad CID extraction, no-commitment validity, pre/post-activation behaviour, missing anchor, burn rule sufficient/insufficient/disabled.

---

## 5. Consensus Parameters

Both new parameters are declared in `src/consensus/params.h` and set to safe disabled defaults in all five network configurations in `src/kernel/chainparams.cpp`.

```cpp
// In Consensus::Params:

/** Block height at which IPFS commitment rules are enforced.
 *  Default: max int (disabled). */
int IPFSCommitHeight{std::numeric_limits<int>::max()};

/** Satoshis per CID byte the anchor tx must burn.
 *  0 = burn rule disabled. */
CAmount IPFSCommitBurnPerByte{0};
```

**Activation sequence (when the time comes):**
1. Set `IPFSCommitBurnPerByte` to the desired rate (e.g., `1` sat/byte as a starting point)
2. Set `IPFSCommitHeight` to a future block height with enough lead time for all nodes to upgrade
3. Wire `CheckBlockIPFSCommitment` into `ContextualCheckBlock` (see section 6.5)

---

## 6. Integration Status — What Is Not Yet Wired

The code is complete and production-ready. Neither subsystem is active. The following steps activate them:

### 6.1 Build system — `src/CMakeLists.txt`

Add to the `glcoin_node` STATIC library target (the `util/cid.cpp` entry is already in `glcoin_common`):

```cmake
# In the glcoin_node sources list:
ipfslink.cpp
rpc/ipfslink.cpp
consensus/ipfscommit.cpp
```

### 6.2 Node startup — `src/init.cpp`

Add include at the top:
```cpp
#include <rpc/ipfslink.h>
```

In `AppInitMain()`, after the data directory is locked (alongside the miner registry init):
```cpp
InitIPFSLinkDB(args.GetDataDirNet());
```

In the RPC registration block:
```cpp
RegisterIPFSLinkRPCCommands(tableRPC);
```

### 6.3 Block validation — `src/validation.cpp`

Add include:
```cpp
#include <consensus/ipfscommit.h>
```

In `ContextualCheckBlock()`, after the block weight check and before `return true`:
```cpp
std::string ipfs_reason;
if (!CheckBlockIPFSCommitment(block, nHeight, chainman.GetConsensus(), ipfs_reason)) {
    return state.Invalid(BlockValidationResult::BLOCK_CONSENSUS,
        ipfs_reason, "IPFS commitment check failed: " + ipfs_reason);
}
```

### 6.4 Qt GUI — `src/qt/bitcoingui.cpp`

Instantiate `IPFSLinksDialog` and add it to the **File** menu.

### 6.5 Activation parameters — `src/kernel/chainparams.cpp`

When ready to activate on mainnet:
```cpp
consensus.IPFSCommitHeight      = <chosen_block_height>;
consensus.IPFSCommitBurnPerByte = <satoshis_per_byte>;  // e.g. 1
```

---

## 7. File Map

```
src/
├── util/
│   ├── cid.h                         Shared CID validator: ParsedCID, ParseBytes,
│   │                                 ParseString, IsValid (namespace cid)
│   └── cid.cpp                       Implementation: multibase decoders, varint
│                                     reader, codec/multihash allowlists
│
├── ipfslink.h                        Off-chain store: CIPFSLink struct, CIPFSLinkDB,
│                                     IsValidIPFSCID(), IsValidIPFSDescription()
├── ipfslink.cpp                      LevelDB implementation, UTF-8 validator,
│                                     pagination (limit/offset)
│
├── consensus/
│   ├── ipfscommit.h                  Consensus commitment: IPFSCommitment struct,
│   │                                 ParseCIDBytes, BuildIPFSCommitScript,
│   │                                 ExtractCoinbaseIPFSCommitment,
│   │                                 CheckBlockIPFSCommitment
│   └── ipfscommit.cpp                Implementation — delegates CID parsing to
│                                     cid::ParseBytes (no duplicate logic)
│
├── rpc/
│   ├── ipfslink.h                    InitIPFSLinkDB(), GetIPFSLinkDB(),
│   │                                 RegisterIPFSLinkRPCCommands()
│   └── ipfslink.cpp                  storeipfslink, getipfslink,
│                                     listipfslinks (paginated), removeipfslink
│
├── qt/
│   ├── ipfslinksdialog.h             Qt dialog class declaration
│   └── ipfslinksdialog.cpp           Qt dialog implementation
│
└── test/
    └── ipfscommit_tests.cpp          15 consensus commitment tests

doc/
├── IPFS_Implementation.md            This file — full technical reference
├── ipfslink.md                       User guide and RPC examples
└── release-notes/
    └── release-notes-ipfslink.md     Release notes for the feature
```

---

## 8. Changes Made in the Perfection Pass (2026-04-22)

A summary of every improvement made to the existing IPFS code:

| File | Change | Reason |
|------|--------|--------|
| `src/util/cid.h` | **New file** — shared CID validator namespace `cid::` | Unify the two previously inconsistent validators |
| `src/util/cid.cpp` | **New file** — multibase decoding + strict binary multihash parser | Single source of truth for what constitutes a valid CID |
| `src/consensus/ipfscommit.cpp` | Removed duplicate varint reader, codec and multihash allowlists; now calls `cid::ParseBytes` | Eliminate code duplication; enforce single validator |
| `src/consensus/params.h` | Added `IPFSCommitHeight` and `IPFSCommitBurnPerByte` fields | Were referenced in `ipfscommit.cpp` and tests but never declared — would have been a compile error |
| `src/consensus/params.h` | Added `#include <consensus/amount.h>` | Required for `CAmount IPFSCommitBurnPerByte` |
| `src/kernel/chainparams.cpp` | Set `IPFSCommitHeight` and `IPFSCommitBurnPerByte` for all 5 networks | Every network needs safe defaults; missing values = UB |
| `src/ipfslink.h` | `IsValidIPFSCID` now delegates to `cid::IsValid`; `ListLinks` gets `limit`/`offset` parameters; added `IsValidIPFSDescription()` | Strict validation, pagination, description safety |
| `src/ipfslink.cpp` | Use `cid::IsValid`; built-in UTF-8 state machine; pagination in `ListLinks`; validate description at write time | Security audit fixes H2, M3, M4 |
| `src/rpc/ipfslink.cpp` | `storeipfslink` validates description; `listipfslinks` exposes `limit`/`offset` | Security audit fixes M3, M4 |
| `src/CMakeLists.txt` | `util/cid.cpp` added to `glcoin_common` | New file must be compiled |
