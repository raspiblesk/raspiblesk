# Glcoin — Pre-Start Hardening Checklist

**Version**: v0.1.7
**Status**: Work in progress — complete all items before mainnet launch
**Chain**: Glcoin mainnet (P2P port 1618, RPC port 1617)

Everything in this document must be completed and verified before block 0 is broadcast to the public network. Items are ordered by dependency — earlier items must be done before later ones.

---

## 1. Authority Key Generation (CRITICAL — blocks 0–999 window)

The miner permission system activates at block 1000. Before that block is mined, at least one miner must be registered and approved in the registry. Without this, no block after 999 will be valid.

**Steps:**

- [ ] Generate the authority keypair on a permanently air-gapped machine (never connected to the internet)
  ```bash
  # On air-gapped machine running Glcoin:
  glcoin-cli getnewaddress "" bech32
  # → gc1q...
  glcoin-cli dumpprivkey gc1q...
  ```
- [ ] Store the private key on a hardware wallet or paper backup — never on any networked device
- [ ] Record the authority address (public — safe to share): `gc1q...`
- [ ] Set `minerAuthorityAddress` in `src/kernel/chainparams.cpp`:
  ```cpp
  consensus.minerAuthorityAddress = "gc1q...";  // production authority address
  ```
- [ ] Rebuild binaries after setting the address
- [ ] Distribute updated binaries to all nodes before block 1000

**Current state**: `minerAuthorityAddress = ""` — dev mode, no signature verification. This MUST be changed before mainnet.

---

## 2. Trusted Miner Registration (must complete before block 999)

With `MinerRegistryHeight = 1000`, all blocks from height 1000 onward must have a coinbase output paying to a registry-approved address. If no miners are approved before block 1000, the chain stalls.

**Steps:**

- [ ] Identify the initial set of trusted miners (KYC-verified off-chain)
- [ ] For each trusted miner, submit their application:
  ```bash
  glcoin-cli registerminer <miner_address> <kyc_id> "<display_name>"
  ```
- [ ] For each pending miner, generate the authority signature on the air-gapped machine:
  ```bash
  # On server — get the message to sign:
  glcoin-admin sign-approve <miner_address>
  # On air-gapped machine — sign it:
  glcoin-cli signmessage <authority_address> "GLCOIN-MINER-APPROVE:<miner_addr>:<unix_time/3600>"
  # On server — apply the signature:
  glcoin-admin approve <miner_address> <signature>
  ```
- [ ] Verify all intended miners are approved before block 999:
  ```bash
  glcoin-admin list approved
  ```
- [ ] Confirm at least one approved miner is actively mining before block 1000

---

## 3. Network Magic Bytes (testnet/regtest isolation)

The mainnet magic bytes (`f9 b4 b4 d9`) are unique to Glcoin. However, testnet, testnet4, and regtest currently share magic bytes with Bitcoin's corresponding test networks. This causes nodes to initially handshake before rejecting each other on genesis mismatch — wasted connections.

**Current state:**

| Chain     | Glcoin bytes   | Bitcoin bytes  | Isolated? |
|-----------|----------------|----------------|-----------|
| mainnet   | `f9 b4 b4 d9`  | `f9 be b4 d9`  | YES       |
| testnet3  | `0b 11 09 07`  | `0b 11 09 07`  | **NO**    |
| testnet4  | `1c 16 3f 28`  | `1c 16 3f 28`  | **NO**    |
| regtest   | `fa bf b5 da`  | `fa bf b5 da`  | **NO**    |

**Steps:**

- [ ] Choose unique magic bytes for testnet, testnet4, and regtest in `src/kernel/chainparams.cpp`
  ```cpp
  // Example — testnet (CTestNetParams):
  pchMessageStart[0] = 0x47;  // 'G'
  pchMessageStart[1] = 0x4c;  // 'L'
  pchMessageStart[2] = 0x54;  // 'T'
  pchMessageStart[3] = 0x4e;  // 'N'
  ```
- [ ] Rebuild and re-verify genesis block hashes still assert correctly (magic bytes do not affect hashes)
- [ ] Update any tooling that hardcodes magic bytes
- [ ] **Note**: changing magic bytes requires all testnet participants to upgrade simultaneously — coordinate before testnet launch

---

## 4. DNS Seeds

Without DNS seeds, new nodes cannot discover peers automatically. Every node operator must manually specify `-addnode=<ip>` until seeds are live. This is not viable for a public network.

**Steps:**

- [ ] Provision the glcoin.org server (Debian Bookworm)
- [ ] Run `contrib/glcoin-server/install.sh` to deploy the node + WireGuard VPN
- [ ] Deploy a DNS seeder (see `seeder.md` and `dns.glcoin.org.md`)
- [ ] Configure the following DNS records at `dns.glcoin.org`:
  - `seed.glcoin.org` A/AAAA → seed node IPs
  - `dnsseed.glcoin.org` NS → seeder server
- [ ] Add seed hostnames to `src/kernel/chainparams.cpp` `vSeeds`:
  ```cpp
  vSeeds.emplace_back("seed.glcoin.org");
  vSeeds.emplace_back("dnsseed.glcoin.org");
  ```
- [ ] Run at least 2 seed nodes for redundancy before public launch
- [ ] Rebuild binaries with seeds populated

**Current state**: `vSeeds.clear()` on all chains — no peer discovery.

---

## 5. Multi-Node P2P Testing

Single-node regtest is passing. The following must be tested with at least two real nodes on separate machines before mainnet.

- [ ] **Peer connection**: two nodes find each other (via `-addnode` or DNS seed) and handshake successfully
- [ ] **Block propagation**: block mined on node A appears on node B within 1–2 seconds
- [ ] **Mempool sync**: transaction broadcast on node A appears in node B's mempool
- [ ] **Reorg handling**: force a 2-block reorg and verify both nodes converge on the longer chain
- [ ] **Miner registry sync**: `registerminer` RPC on node A; verify `listminers` shows the entry on node B after block inclusion
- [ ] **Enforcement at block 1000**: mine blocks 999–1001 in a controlled testnet; verify block 1001 from an unapproved address is rejected
- [ ] **Signet validation**: mine at least 10 signet blocks with the challenge key; verify blocks are accepted

---

## 6. Code Review — New Subsystems

The following files are new in Glcoin v0.1.7 and have not been reviewed outside this development session. They should be audited before mainnet.

| File | Risk | Notes |
|------|------|-------|
| `src/minerregistry.cpp` | High | LevelDB write paths, iterator safety |
| `src/rpc/minerregistry.cpp` | High | Authority signature verification, all 8 RPC commands |
| `src/validation.cpp` (miner check) | Critical | Consensus enforcement — a bug here can split the chain |
| `src/util/cid.cpp` | Medium | CID parser — currently compiled but not enforced |
| `src/ipfslink.cpp` | Low | Not compiled — inactive until v1.0 |

**Specific items to verify:**

- [ ] `IsMinerApproved()` correctly handles `SUSPENDED` + expired suspension (should revert to `APPROVED`)
- [ ] `IsMinerApproved()` correctly handles `APPROVED` + expired `expires_at` (should reject)
- [ ] `ContextualCheckBlock` enforcement in `validation.cpp` handles empty registry gracefully (no crash, correct rejection)
- [ ] Authority signature message format is consistent between `CheckAuthoritySignature()` in RPC and `VerifyAuthoritySignature()` in `minerregistry.cpp`
- [ ] No unbounded iteration in `ListMiners()` — confirm LevelDB iterator is released on error paths
- [ ] RPC commands return correct error codes (not `RPC_INTERNAL_ERROR` for user input errors)

---

## 7. Binary Distribution Hardening

- [ ] Strip debug symbols from release binaries:
  ```bash
  cmake -DCMAKE_BUILD_TYPE=Release -B build_release
  cmake --build build_release -j$(nproc)
  strip build_release/bin/glcoind build_release/bin/glcoin-cli
  ```
- [ ] Generate SHA256 checksums for all release binaries:
  ```bash
  sha256sum build_release/bin/glcoin* > SHA256SUMS
  ```
- [ ] Sign `SHA256SUMS` with the release key (GPG or Glcoin `signmessage`)
- [ ] Publish binaries and checksums on glcoin.org before announcing mainnet launch
- [ ] **Do not** distribute the debug binary currently at `build/bin/glcoind` — it is unstripped and large

---

## 8. Server Security

- [ ] Complete WireGuard VPN setup: `contrib/glcoin-server/wireguard/setup-wireguard.sh install`
- [ ] Add at least 2 admin peers before launch
- [ ] Set strong `rpcpassword` in `/etc/glcoin/glcoin.conf` (never use the template placeholder)
- [ ] Set `GLCOIN_ADMIN_PASSWORD` and `GLCOIN_ADMIN_SECRET` in `/etc/glcoin/admin.env`
- [ ] Verify UFW rules: only ports 22, 1618, 51820 are public
- [ ] Verify RPC port 1617 and web admin port 9090 respond only on `wg0` interface:
  ```bash
  curl http://10.99.0.1:9090     # from VPN client — should respond
  curl http://<public_ip>:9090   # from internet — must time out
  ```
- [ ] Enable unattended-upgrades for OS security patches:
  ```bash
  apt-get install unattended-upgrades
  dpkg-reconfigure -plow unattended-upgrades
  ```
- [ ] Disable password SSH — key-only authentication:
  ```bash
  # /etc/ssh/sshd_config
  PasswordAuthentication no
  PubkeyAuthentication yes
  ```

---

## 9. Version Number

The binary currently reports `v0.1.6` in the P2P user agent (`/Gsatoshi:0.1.6/`). The codebase is `v0.1.7`. Update before release:

- [ ] Update `CMakeLists.txt`:
  ```cmake
  set(CLIENT_VERSION_MAJOR 0)
  set(CLIENT_VERSION_MINOR 1)
  set(CLIENT_VERSION_BUILD 7)
  ```
- [ ] Rebuild — user agent will become `/Gsatoshi:0.1.7/`
- [ ] Verify with `glcoin-cli getnetworkinfo | grep subversion`

**Note**: `CLIENT_VERSION_MAJOR 31` is the upstream Bitcoin Core base version used for the build system. Glcoin uses its own semantic version embedded via the version constants above.

---

## 10. Genesis Block Public Announcement

The genesis block is already mined and its hash is hardcoded with `assert()`. Before launching:

- [ ] Publish the genesis block hash publicly (website, social, GitHub):
  ```
  Mainnet genesis: 3563293d950fd5ba7840bdfa562cc896298378e970b984f3751522b8afa7bcb8
  ```
- [ ] Document the coinbase string: `"GLCoin Genesis 2026-04-16 — Built for the community"`
  (Note: the genesis coinbase uses `GLCoin` — this is immutable, part of the block hash)
- [ ] Publish the genesis timestamp: `1744761600` (2026-04-16 00:00:00 UTC)
- [ ] Announce the miner enforcement activation height: block 1000
- [ ] Announce the authority address (after generating it in step 1)

---

## Summary: Launch Gate

Do not open the public network until all of the following are true:

| Gate | Status |
|------|--------|
| Authority keypair generated (air-gapped) | ⬜ Pending |
| `minerAuthorityAddress` set in chainparams + rebuilt | ⬜ Pending |
| At least 1 trusted miner approved in registry | ⬜ Pending |
| DNS seeds live and resolving | ⬜ Pending |
| 2+ nodes P2P tested (block propagation confirmed) | ⬜ Pending |
| Miner enforcement at block 1000 validated on testnet | ⬜ Pending |
| Release binary stripped + checksums published | ⬜ Pending |
| Server WireGuard + UFW confirmed | ⬜ Pending |
| Version set to v0.1.7 in CMakeLists | ⬜ Pending |
| Genesis hash announced publicly | ⬜ Pending |

---

## What Is Already Production-Ready

| Item | Status |
|------|--------|
| Full Bitcoin 31.x consensus rules | ✅ Complete |
| All BIPs active from block 1 (BIP34, 65, 66, CSV, Segwit) | ✅ Complete |
| Unique mainnet magic bytes (`f9 b4 b4 d9`) | ✅ Complete |
| Custom genesis block (mainnet, testnet, signet, regtest) | ✅ Complete |
| Glcoin address prefix (`gc1...` bech32) | ✅ Complete |
| Custom ports (P2P 1618, RPC 1617) | ✅ Complete |
| Miner registry LevelDB + 8 RPC commands | ✅ Complete |
| Enforcement wired into `ContextualCheckBlock` | ✅ Complete |
| WireGuard VPN server setup scripts | ✅ Complete |
| Web admin panel (Flask, port 9090) | ✅ Complete |
| Regtest smoke test: 10 blocks mined | ✅ Complete |
| `glcoin-qt` builds and runs cleanly | ✅ Complete |
