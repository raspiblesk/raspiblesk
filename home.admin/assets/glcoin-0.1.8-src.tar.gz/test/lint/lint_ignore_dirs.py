#!/usr/bin/env python3
#
# Copyright (c) 2024-present The Glcoin Core developers
# Distributed under the MIT software license, see the accompanying
# file COPYING or https://opensource.org/license/mit.

SHARED_EXCLUDED_SUBTREES = ["src/leveldb/",
                 "src/crc32c/",
                 "src/secp256k1/",
                 "src/minisketch/",
                 "src/ipc/libmultiprocess/",
                 "src/crypto/ctaes/",
                ]
