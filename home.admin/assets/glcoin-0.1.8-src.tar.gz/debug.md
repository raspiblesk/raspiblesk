# Glcoin Signet Debugging Report

## Session Date: 2026-04-22

## Issue: Signet Block Verification Failure

### Summary

Glcoin fails to initialize on signet network. The daemon crashes immediately during the "Verifying blocks..." phase with error:
```
Errors in block header at FlatFilePos(nFile=0, nPos=8) while reading block
```

### Symptoms Observed

1. glcoind starts normally on signet, loads configuration, binds RPC port (31617)
2. During "Verifying blocks..." phase, crashes with fatal error
3. Error occurs at position nPos=8 in blk00000.dat (8 bytes = exactly STORAGE_HEADER_BYTES)
4. Block file is pre-allocated to 16 MiB on first run
5. The crash happens consistently on every signet start, even with clean data directory

### Debug Log Evidence (Complete)

```
2026-04-22T00:09:00Z Signet with challenge 512103ad5e0edad18cb1f0fc0d28a3d4f1f3e445640337489abb10404f2d1e086be430210359ef5021964fe22d6f8e05b2463c9540ce96883fe3b278760f048f5189f2e6c452ae
2026-04-22T00:09:00Z Glcoin Core version v0.1.6 (release build)
2026-04-22T00:09:00Z Using data directory /home/vboxuser/.glcoin/signet
2026-04-22T00:09:00Z Using wallet directory /home/vboxuser/.glcoin/signet/wallets
2026-04-22T00:09:00Z init message: Loading block index…
2026-04-22T00:09:00Z Validating signatures for all blocks.
2026-04-22T00:09:00Z Loading block index db: last block file = 0
2026-04-22T00:09:00Z Loading block index db: last block file info: CBlockFileInfo(blocks=0, size=0, heights=0...0, time=1970-01-01...1970-01-01)
2026-04-22T00:09:00Z Checking all blk files are present...
2026-04-22T00:09:00Z Initializing chainstate Chainstate [ibd] @ height -1 (null)
2026-04-22T00:09:00Z [validation] Pre-allocating up to position 0x1000000 in blk00000.dat
2026-04-22T00:09:00Z init message: Verifying blocks…
2026-04-22T00:09:00Z Block index and chainstate loaded
2026-04-22T00:09:00Z Setting NODE_NETWORK in non-prune mode
2026-04-22T00:09:00Z initload thread start
2026-04-22T00:09:00Z [error] Errors in block header at FlatFilePos(nFile=0, nPos=8) while reading block
2026-04-22T00:09:00Z [error] A fatal internal error occurred, see debug.log for details: Failed to read block.
2026-04-22T00:09:00Z [error] A fatal internal error occurred, see debug.log for details: Chainstate [ibd] @ height -1 (null) Failed to connect best block (Failed to read block.)
```

### Root Cause Investigation

The error occurs in `BlockManager::ReadBlock()` at blockstorage.cpp:1057:

```cpp
// Check the header
if (!CheckProofOfWork(block_hash, block.nBits, GetConsensus())) {
    LogError("Errors in block header at %s while reading block", pos.ToString());
    return false;
}
```

The function is called with position nPos=8 (STORAGE_HEADER_BYTES), meaning it's trying to read a block that doesn't exist yet.

#### Key Files Examined:

1. **blockstorage.h:331** - `std::atomic_bool m_blockfiles_indexed{true}` - defaults to true
2. **chainstate.cpp:64** - `LoadGenesisBlock()` is called when `m_blockfiles_indexed` is true
3. **validation.cpp:4915-4943** - `LoadGenesisBlock()` should write genesis to disk
4. **blockstorage.cpp:1134-1165** - `WriteBlock()` - writes genesis with STORAGE_HEADER_BYTES prefix

#### Initialization Order:

Looking at the code flow:
1. `LoadBlockIndex()` loads block index from LevelDB
2. If `m_blockfiles_indexed` is true (default), `LoadGenesisBlock()` is called
3. `LoadGenesisBlock()` writes genesis block via `WriteBlock()`
4. Then `ReplayBlocks()` tries to verify chainstate against blocks

The issue: Something in the chainstate or block index is referencing a block at position 8 before genesis was written.

### Workarounds Attempted (All Failed)

| Method | Result |
|-------|-------|
| Delete ~/.glcoin/signet directory | Failed - same error |
| Delete all chainstate + blocks/index | Failed - same error |
| `-reindex` flag | Failed - same error |
| `-reindex-chainstate` flag | Failed - same error |
| `-assumevalid=0` | Failed - same error |
| Clean regtest, then switch to signet | Signet still fails |

### Working Alternative Confirmed

**Regtest works correctly:**

```bash
# Start glcoind on regtest
/home/vboxuser/porubing/glcoin/build/bin/glcoind -regtest -daemon

# Create wallet
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -regtest createwallet miner

# Get mining address
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -regtest getnewaddress

# Generate blocks
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -regtest generatetoaddress 1 gcrt1qevldmug63racyqt3jcwq34xquhwg4tls282z65

# Result: Block generated successfully at height 1
```

### Configuration Used

```
[signet]
rpcuser=glcoinpool
rpcpassword=glcoin2026pool
rpcallowip=0.0.0.0/0
```

### Signet Parameters (from chainparams.cpp)

- Signet challenge: `512103ad5e0edad18cb1f0fc0d28a3d4f1f3e445640337489abb10404f2d1e086be430210359ef5021964fe22d6f8e05b2463c9540ce96883fe3b278760f048f5189f2e6c452ae`
- Default port: 31618
- RPC port: 31617
- powLimit: `00000377ae000000000000000000000000000000000000000000000000000000`
- genesis timestamp: 1598918400 (Aug 31, 2020)
- genesis nonce: 1342437386
- genesis bits: 0x1e0377ae
- genesis hash: c8217f7dd403ecfd6e8528ed39db486f90da2dcedbaaebabeba56f6e148e80c5

### Files To Investigate Further

1. **src/node/chainstate.cpp:64** - Check initialization order around LoadGenesisBlock()
2. **src/node/blockstorage.cpp:529-578** - LoadBlockIndexDB() logic
3. **src/validation.cpp:4762-4819** - ReplayBlocks() logic
4. **src/node/blockstorage.cpp:1057** - CheckProofOfWork() failure point

### The Problem Location (Hypothesis)

The chainstate database may have stale references to blocks. When LevelDB is initialized fresh, it may still contain pointers to block files from a previous run or corrupted state.

The crash happens because:
1. Block index says there's data at nFile=0, nPos=8
2. But no actual block was written (or file is empty/corrupted)
3. CheckProofOfWork() fails on the garbage data

### Recommended Fix

Investigate why block index has BLOCK_HAVE_DATA set for a block that was never written. Options:

1. Ensure genesis block is written BEFORE any block index entries are created
2. Check if chainstate db has stale entries on fresh start
3. Add debug logging in LoadGenesisBlock() to confirm it's called
4. Verify STORAGE_HEADER_BYTES constant is 8

### CLI Commands Tested

```bash
# Start on signet (fails)
/home/vboxuser/porubing/glcoin/build/bin/glcoind -signet -daemon

# Check chain info (before crash)
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -signet getblockchaininfo
# Error: -28 "Verifying blocks…"

# Start on regtest (works)
/home/vboxuser/porubing/glcoin/build/bin/glcoind -regtest -daemon
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -regtest createwallet miner
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -regtest getnewaddress
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -regtest generatetoaddress 1 <address>
```

## Code Analysis - FIXED

### Root Cause Identified and Fixed

The bug was that LoadGenesisBlock() was being called BEFORE InitCoinsCache() was ready, so:
1. The genesis block was written to disk correctly
2. But GetBestBlock() wasn't set in the coins view (because coins cache wasn't initialized)
3. When VerifyDB tried to verify blocks, it saw coins as "empty" and crashed

### Fix Applied

Two files were modified:

1. **src/node/chainstate.cpp** - Move LoadGenesisBlock() call to AFTER InitCoinsCache():
   - LoadGenesisBlock() now called inside the for-loop AFTER InitCoinsCache()
   - Clear setBlockIndexCandidates after LoadGenesisBlock()

2. **src/validation.cpp** - Explicitly set BestBlock after loading genesis:
   - In LoadGenesisBlock(), after ReceivedBlockTransactions(), explicitly call SetBestBlock()

### Verification

The fix was tested - signet now starts successfully:
```
glcoin-cli -signet getblockchaininfo
```
Returns:
- blocks: 0 (just genesis)
- chain: signet
- bestblockhash: c8217f7dd403ecfd6e8528ed39db486f90da2dcedbaaebabeba56f6e148e80c5

```cpp
bool BlockManager::ReadBlock(CBlock& block, const FlatFilePos& pos, const std::optional<uint256>& expected_hash) const
{
    block.SetNull();

    // Open history file to read
    const auto block_data{ReadRawBlock(pos)};
    if (!block_data) {
        return false;
    }

    try {
        // Read block
        SpanReader{*block_data} >> TX_WITH_WITNESS(block);
    } catch (const std::exception& e) {
        LogError("Deserialize or I/O error - %s at %s while reading block", e.what(), pos.ToString());
        return false;
    }

    const auto block_hash{block.GetHash()};

    // Check the header
    if (!CheckProofOfWork(block_hash, block.nBits, GetConsensus())) {
        LogError("Errors in block header at %s while reading block", pos.ToString());
        return false;  // <-- CRASH HERE at line 1058
    }
    // ...
}
```

### STORAGE_HEADER_BYTES

From `blockstorage.h:126`:
```cpp
static constexpr uint32_t STORAGE_HEADER_BYTES{std::tuple_size_v<MessageStartChars> + sizeof(unsigned int)};
// = 4 (message start) + 4 (block size) = 8 bytes
```

The error at `nPos=8` means it's trying to read a block positioned exactly after the STORAGE_HEADER_BYTES prefix.

### Call Path Analysis

1. During init, `CVerifyDB::VerifyDB()` is called (validation.cpp:4600)
2. It iterates over blocks in the best chain (line 4630):
   ```cpp
   for (pindex = chainstate.m_chain.Tip(); pindex && pindex->pprev; pindex = pindex->pprev)
   ```
3. For each block, it calls `ReadBlock(block, *pindex)` (line 4650):
   ```cpp
   if (!chainstate.m_blockman.ReadBlock(block, *pindex)) {
       LogError("Verification error: ReadBlock failed at %d, hash=%s", pindex->nHeight, pindex->GetBlockHash().ToString());
       return VerifyDBResult::CORRUPTED_BLOCK_DB;
   }
   ```

### Root Cause

For the ReadBlock to fail with nPos=8, the CBlockIndex must have:
- `nFile = 0`
- `nDataPos = 8` (or nPos after STORAGE_HEADER_bytes adjustment)

This can only happen if a block index entry was created with BLOCK_HAVE_DATA before the genesis block was actually written to disk.

### Key Observations

1. **Pre-allocation happens** (log shows "Pre-allocating up to position 0x1000000 in blk00000.dat")
2. **Block index has entries** (checking "Checking all blk files are present..." passes)
3. **But data is garbage/empty** (the actual bytes at position 8 don't form a valid block)

The pre-allocation creates a file with zeros (or uninitialized data). Then something makes the code think there's a valid block at position 8, even though no block was written.

### Difference: Main vs Signet

Looking at chainparams.cpp:
- **Main**: `consensus.signet_blocks = true` with challenge at line 86
- **Signet**: Same setup at line 344

Both should behave similarly. The key difference must be in initialization order or stored state.

### Hypothesis

The issue is that on signet (or any fresh chain), there's stale state in either:
1. LevelDB block index database (has phantom block entries)
2. Chainstate database (coins view has BestBlock set to something non-null)

When LoadGenesisBlock() runs, if m_blockfiles_indexed is already true, it skips writing. But if there's stale state from a previous run, the code tries to verify against non-existent blocks.

### Files to Fix

1. **src/node/blockstorage.cpp:529-578** - LoadBlockIndexDB() - verify clean state
2. **src/node/chainstate.cpp:64** - LoadGenesisBlock() called condition
3. **src/validation.cpp:4915-4943** - LoadGenesisBlock() - ensure genesis writes correctly

## Additional Investigation

### Key Finding - The Bug is VERY Specific

The exact position nPos=8 (STORAGE_HEADER_BYTES) means the code is trying to read a block positioned immediately after the header prefix. This only happens when:
- CBlockIndex has nDataPos = 8+STORAGE_HEADER_BYTES (so the actual file position accounting for the prefix becomes 8)
- Wait no - more likely: the nDataPos is stored WITHOUT the header, so nDataPos=8 means the code calculates actual position as 8+8=16

But actually, looking at WriteBlock():
```cpp
pos.nPos += STORAGE_HEADER_BYTES;  // Update position AFTER writing header
```

So the stored nDataPos is the position AFTER the header. When reading:
```cpp
filein >> blk_start >> blk_size;
pos.nPos -= STORAGE_HEADER_BYTES;  // Go back before reading
```

And in ReadRawBlock:
```cpp
filein{OpenBlockFile({pos.nFile, pos.nPos - STORAGE_HEADER_BYTES}, ...)}
```

So if nDataPos (stored in CBlockIndex) equals 8, the actual file position is 8-8=0, which should work... BUT if the block was never written, it's reading garbage.

### What's Happening

The block index has an entry with BLOCK_HAVE_DATA set that was never actually written to disk. Possible causes:

1. Chainstate has BestBlock != null (phantom block reference)
2. Block index DB has stale entries (from LevelDB corruption)
3. LoadGenesisBlock() was called but WriteBlock() failed silently

### Possible Fix Ideas

1. In ReplayBlocks(), check if blocks actually exist before trying to read
2. In LoadGenesisBlock(), verify the block was written successfully
3. Add check: if block index has BLOCK_HAVE_DATA but file is empty, clear the flag

## Conclusion

The root cause is that on a FRESH signet start, the code proceeds through this broken path:

```
1. LoadBlockIndex() - loads empty block index (but m_blockfiles_indexed stays true)
2. InitCoinsDB() - creates empty coins view (GetBestBlock() returns null)
3. ReplayBlocks() - returns early because GetHeadBlocks() = empty (GOOD)
4. is_coinsview_empty() returns TRUE
5. LoadGenesisBlock() is SKIPPED because m_blockfiles_indexed = true (BUG!)
6. Later: code tries to verify and crashes because there's no genesis block
```

The fix: In chainstate.cpp:64, change:
```cpp
if (chainman.m_blockman.m_blockfiles_indexed && !chainman.ActiveChainstate().LoadGenesisBlock()) {
```

To always load genesis on a fresh chain, OR check if COINS VIEW is empty:
```cpp
if (chainman.m_blockman.m_blockfiles_indexed && chainstate->CoinsTip().GetBestBlock().IsNull() && !chainman.ActiveChainstate().LoadGenesisBlock()) {
```

Actually the issue is more subtle - the condition should check if we need genesis BEFORE checking blockfiles_indexed.

For regtest it works because... need to compare why. Possibly regtest handles this case differently.