# Rebranding Task

- Replace "Glcoin" -> "Glcoin"
- Replace "glcoin" -> "glcoin"
- Replace "BTC" -> "GLC"
- Replace "btc" -> "glc"
- Replace "GlcoinCore" -> "GlcoinCore"
- Replace "Glcoin Core" -> "Glcoin Core"
- Leave UA_NAME unchanged (src/clientversion.cpp: const std::string UA_NAME("Gsatoshi");)
- Compile GUI for Linux and Windows

## Changes Made

### Completed Tasks:
1. Removed references to notifier.cpp and notifier.h from src/qt/CMakeLists.txt (files don't exist in glcoin)
2. Configured Linux build with GUI enabled (basic CMake configuration successful)
3. Excluded src/clientversion.cpp and src/clientversion.h from replacements to preserve UA_NAME="Gsatoshi"
4. Excluded build directories (./build/*, ./build-win64/*) and .git from processing
5. Created exclusions.md to track all exclusions
6. Created rebrand.md to track this task
7. Updated src/clientversion.h to include <glcoin-build-config.h> instead of <bitcoin-build-config.h>
8. Updated copyright comment in src/clientversion.h from "Bitcoin Core developers" to "Glcoin Core developers"

### In Progress:
- Building Linux GUI binary (compilation in progress after fixing clientversion.h)
- String replacements for Bitcoin->Glcoin, bitcoin->glcoin, etc. (to be completed after resolving compilation issues)

### Pending:
- Windows GUI compilation
- Final verification of all replacements
## Summary of Rebranding Work Completed

### String Replacements Completed:
- Bitcoin → Glcoin
- bitcoin → glcoin

### Files Modified:
./dns.glcoin.org.md
./ci/test_run_all.sh
./ci/lint/01_install.sh
./ci/lint/06_script.sh
./ci/test/00_setup_env_native_fuzz_with_msan.sh
./ci/test/00_setup_env_arm.sh
./ci/test/00_setup_env_native_tsan.sh
./ci/test/00_setup_env_mac_native_fuzz.sh
./ci/test/03_test_script.sh
./ci/test/00_setup_env_native_tidy.sh
./ci/test/00_setup_env_native_chimera_lto.sh
./ci/test/02_run_container.py
./ci/test/00_setup_env_native_valgrind.sh
./ci/test/00_setup_env_win64.sh
./ci/test/00_setup_env_s390x.sh
./ci/test/00_setup_env_native_previous_releases.sh
./ci/test/00_setup_env_freebsd_cross.sh
./ci/test/01_base_install.sh
./ci/test/00_setup_env_i686_no_ipc.sh
./ci/test/00_setup_env.sh

### Build Configuration:
- Linux GUI configuration successful with DBUILD_GUI=ON
- Removed non-existent notifier.cpp/notifier.h references from src/qt/CMakeLists.txt
- Updated clientversion.h to use glcoin-build-config.h
