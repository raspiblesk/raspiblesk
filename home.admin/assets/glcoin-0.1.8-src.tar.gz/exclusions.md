# Exclusions for Rebranding Task

The following files/patterns were excluded from automatic string replacement:

1. `src/clientversion.cpp` - Contains UA_NAME definition that must remain unchanged
2. `src/clientversion.h` - Contains UA_NAME declaration that must remain unchanged
3. `src/qt/notifier.cpp` - Referenced in CMakeLists.txt but file does not exist; removed from CMakeLists.txt
4. `src/qt/notifier.h` - Referenced in CMakeLists.txt but file does not exist; removed from CMakeLists.txt

Additionally, the following build directories were excluded:
- `./build/*`
- `./build-win64/*`
- `./.git/*`

These exclusions ensure that:
- The UA_NAME ("Gsatoshi") remains untouched as requested
- Non-existent files don't cause build failures
- Version control and build artifacts are not modified

# Replacements Performed

*To be filled after replacements.*
