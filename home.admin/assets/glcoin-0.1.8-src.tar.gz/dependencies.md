# Dependencies Installation Guide

This guide provides commands to install the required dependencies for building glcoin on Ubuntu/Debian systems.

## Essential Build Dependencies

Run these commands to install the core dependencies needed to build glcoin:

```bash
# Update package list
sudo apt-get update

# Install essential build tools
sudo apt-get install -y build-essential cmake pkg-config

# Install required libraries
sudo apt-get install -y libevent-dev libboost-dev libsqlite3-dev
```

## Optional Dependencies

These dependencies are needed for additional features:

### Wallet Support (SQLite)
```bash
sudo apt-get install -y libsqlite3-dev
```

### GUI (Qt)
```bash
sudo apt-get install -y qt6-base-dev qt6-tools-dev qt6-l10n-tools qt6-tools-dev-tools libgl-dev libqrencode-dev
```

### IPC (Cap'n Proto)
```bash
sudo apt-get install -y libcapnp-dev capnproto
```

### ZeroMQ Notifications
```bash
sudo apt-get install -y libzmq3-dev
```

### User-Space Tracing (USDT)
```bash
sudo apt-get install -y systemtap-sdt-dev
```

### Wayland Support (for GUI)
```bash
sudo apt-get install -y qt6-wayland
```

## All Dependencies (Complete Installation)

To install everything at once:

```bash
sudo apt-get update
sudo apt-get install -y \
    build-essential \
    cmake \
    pkg-config \
    libevent-dev \
    libboost-dev \
    libsqlite3-dev \
    libcapnp-dev \
    capnproto \
    libzmq3-dev \
    systemtap-sdt-dev \
    qt6-base-dev \
    qt6-tools-dev \
    qt6-l10n-tools \
    qt6-tools-dev-tools \
    libgl-dev \
    libqrencode-dev \
    qt6-wayland
```

## Verification

After installing dependencies, you can verify the build works by running:

```bash
# Create build directory
mkdir -p build && cd build

# Configure build
cmake ..

# Build glcoin
cmake --build . -j$(nproc)
```

## Notes

- The minimum required versions are:
  - GCC: 12.1+
  - Boost: 1.74.0+
  - CMake: 3.22+
  - libevent: 2.1.8+
  - SQLite: 3.7.17+ (required for wallet)

- For the most up-to-date dependency information, see `/doc/dependencies.md`

- For platform-specific build instructions, see `/doc/build-*.md`