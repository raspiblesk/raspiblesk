// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// ============================================================
// Glcoin — Miner Permission Registry
//
// KYC-gated registry of approved mining addresses.  Only
// addresses listed here with status APPROVED are permitted
// to produce blocks once MinerRegistryHeight is reached.
//
// Follows the same LevelDB / CDBWrapper pattern as ipfslink.cpp.
// ============================================================

#pragma once

#include <dbwrapper.h>
#include <uint256.h>

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// On-chain GLCM (Glcoin Miner Registry) transaction constants
// OP_RETURN format: GLCM | action(1) | miner_pkh(20) [| extra(8)]
// Authority proof: tx must have an input spending from the authority address.
// ---------------------------------------------------------------------------
static constexpr uint8_t GLCM_MAGIC[4]  = {'G','L','C','M'};
static constexpr uint8_t GLCM_APPROVE   = 0x01;
static constexpr uint8_t GLCM_REVOKE    = 0x02;
static constexpr uint8_t GLCM_SUSPEND   = 0x03;
static constexpr uint8_t GLCM_RENEW     = 0x04;
static constexpr size_t  GLCM_MIN_SIZE  = 25; // 4 + 1 + 20
static constexpr size_t  GLCM_EXT_SIZE  = 33; // 4 + 1 + 20 + 8 (with extra)

// ---------------------------------------------------------------------------
// Status codes
// ---------------------------------------------------------------------------
static constexpr uint8_t MINER_STATUS_PENDING   = 0;
static constexpr uint8_t MINER_STATUS_APPROVED  = 1;
static constexpr uint8_t MINER_STATUS_REVOKED   = 2;
static constexpr uint8_t MINER_STATUS_SUSPENDED = 3;

// ---------------------------------------------------------------------------
// CMinerRecord — one entry in the registry
// ---------------------------------------------------------------------------
struct CMinerRecord {
    std::string address;          // Glcoin address (coinbase payout address)
    std::string kyc_id;           // Internal KYC reference (max 64 chars)
    std::string display_name;     // Human-readable name (max 128 chars)
    uint8_t     status{MINER_STATUS_PENDING};
    int64_t     registered_at{0}; // Unix timestamp of application
    int64_t     approved_at{0};   // Unix timestamp of approval (0 if pending)
    int64_t     expires_at{0};    // Unix timestamp of expiry (0 = no expiry)
    int64_t     suspended_until{0}; // Unix timestamp — suspended until this time
    std::string notes;            // Admin notes (max 256 chars, never sent to peers)

    template <typename Stream>
    void Serialize(Stream& s) const {
        s << address << kyc_id << display_name << status
          << registered_at << approved_at << expires_at
          << suspended_until << notes;
    }

    template <typename Stream>
    void Unserialize(Stream& s) {
        s >> address >> kyc_id >> display_name >> status
          >> registered_at >> approved_at >> expires_at
          >> suspended_until >> notes;
    }

    // Returns the effective status evaluated at Unix time `now`.
    // A SUSPENDED record whose suspended_until has passed is treated as APPROVED.
    // An APPROVED record whose expires_at has passed is treated as REVOKED.
    uint8_t EffectiveStatus(int64_t now) const;
};

// ---------------------------------------------------------------------------
// CMinerRegistryDB — LevelDB-backed registry
// ---------------------------------------------------------------------------
class CMinerRegistryDB : public CDBWrapper
{
public:
    // Opens (or creates) the registry LevelDB at <datadir>/minerregistry/.
    explicit CMinerRegistryDB(const fs::path& path,
                              size_t cache_size_bytes = 1 << 20,
                              bool in_memory = false);

    // Insert a brand-new record (must not already exist).
    bool StoreMiner(const CMinerRecord& record);

    // Overwrite an existing record (used for approvals, revocations, etc.).
    bool UpdateMiner(const CMinerRecord& record);

    // Retrieve by address. Returns std::nullopt if not found.
    std::optional<CMinerRecord> GetMiner(const std::string& address) const;

    // List all records. Pass -1 for all, or a MINER_STATUS_* constant to filter.
    std::vector<CMinerRecord> ListMiners(int status_filter = -1);

    // Delete a record entirely. Returns true if it existed.
    bool RemoveMiner(const std::string& address);

    // Fast path used by the consensus check: returns true only if the address
    // has effective status APPROVED at the given Unix time.
    bool IsMinerApproved(const std::string& address, int64_t now) const;

private:
    static constexpr uint8_t KEY_PREFIX = 'M';
};

// ---------------------------------------------------------------------------
// Authority-signature helpers
// ---------------------------------------------------------------------------

// Build the canonical message the admin must sign for an approval/revocation.
// `action`  — "APPROVE" or "REVOKE" or "SUSPEND" or "RENEW"
// `address` — the miner's Glcoin address
// `hour`    — current Unix time divided by 3600 (caller computes this)
std::string MakeAuthorityMessage(const std::string& action,
                                 const std::string& address,
                                 int64_t hour);

// Verify a base64 authority signature produced by `signmessage`.
// Returns true only if the signature is valid AND was made by authority_address.
bool VerifyAuthoritySignature(const std::string& authority_address,
                              const std::string& message,
                              const std::string& sig_base64);
