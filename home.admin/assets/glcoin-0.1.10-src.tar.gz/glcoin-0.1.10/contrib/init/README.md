Sample configuration files for:
```
systemd: glcoind.service
Upstart: glcoind.conf
OpenRC:  glcoind.openrc
         glcoind.openrcconf
CentOS:  glcoind.init
macOS:   org.glcoin.glcoind.plist
```
have been made available to assist packagers in creating node packages here.

See [doc/init.md](../../doc/init.md) for more information.
