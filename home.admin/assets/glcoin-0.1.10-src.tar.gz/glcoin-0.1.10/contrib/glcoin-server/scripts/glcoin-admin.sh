#!/usr/bin/env bash
# Glcoin Miner Registry Admin CLI
# Usage: glcoin-admin.sh <command> [args...]
#
# Commands:
#   status                          Node and registry overview
#   list [pending|approved|revoked|suspended|all]
#   info <address>
#   stats
#   register <address> <kyc_id> <name>
#   approve <address>               (prompts for authority key)
#   revoke  <address> [reason]
#   suspend <address> <until_date>  (date as YYYY-MM-DD or unix ts)
#   renew   <address> <until_date>
#   sign-approve <address>          Print signmessage command only
#   sign-revoke  <address>
#   sign-suspend <address>
#   sign-renew   <address>
#
set -euo pipefail

# ── Configuration ────────────────────────────────────────────────────────────
GLCOIN_CLI="${GLCOIN_CLI:-/usr/local/bin/glcoin-cli}"
CONF="${GLCOIN_CONF:-/etc/glcoin/glcoin.conf}"
DATADIR="${GLCOIN_DATADIR:-/var/lib/glcoin/.glcoin}"

CLI="${GLCOIN_CLI} -conf=${CONF} -datadir=${DATADIR}"

# Colour output
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; RESET='\033[0m'

err()  { echo -e "${RED}ERROR:${RESET} $*" >&2; exit 1; }
info() { echo -e "${BLUE}INFO:${RESET} $*"; }
ok()   { echo -e "${GREEN}OK:${RESET} $*"; }
warn() { echo -e "${YELLOW}WARN:${RESET} $*"; }

require_cli() {
    [[ -x "${GLCOIN_CLI}" ]] || err "glcoin-cli not found at ${GLCOIN_CLI}. Set GLCOIN_CLI env var."
    ${CLI} getblockchaininfo > /dev/null 2>&1 || err "Cannot connect to glcoind. Is it running?"
}

current_hour() {
    echo $(( $(date +%s) / 3600 ))
}

# ── Sign-only helpers (no key on server needed) ───────────────────────────────
sign_message_cmd() {
    local action="$1" address="$2"
    local hour; hour=$(current_hour)
    local msg="GLCOIN-MINER-${action}:${address}:${hour}"
    echo ""
    echo -e "${BOLD}Run this on your authority key machine (air-gapped):${RESET}"
    echo ""
    echo "  glcoin-cli signmessage <AUTHORITY_ADDRESS> \"${msg}\""
    echo ""
    echo -e "${YELLOW}Note:${RESET} The signature is valid for this hour and the next."
    echo "  Hour: ${hour} | Expires: $(date -d "@$(( (hour+1)*3600 ))" 2>/dev/null || date -r "$(( (hour+1)*3600 ))" 2>/dev/null || echo "in ~60 minutes")"
    echo ""
}

# ── Commands ─────────────────────────────────────────────────────────────────
cmd_status() {
    require_cli
    echo -e "${BOLD}── Glcoin Node ────────────────────────────────${RESET}"
    ${CLI} getblockchaininfo | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(f\"  Chain:   {d['chain']}\")
print(f\"  Blocks:  {d['blocks']}\")
print(f\"  Headers: {d['headers']}\")
print(f\"  IBD:     {d['initialblockdownload']}\")
"
    echo ""
    echo -e "${BOLD}── Miner Registry ─────────────────────────────${RESET}"
    ${CLI} getminerregistrystats | python3 -c "
import sys, json
d = json.load(sys.stdin)
print(f\"  Total:      {d['total']}\")
print(f\"  Approved:   {d['approved']}\")
print(f\"  Pending:    {d['pending']}\")
print(f\"  Revoked:    {d['revoked']}\")
print(f\"  Suspended:  {d['suspended']}\")
print(f\"  Enforcement height: {d['enforcement_height']}\")
print(f\"  Authority:  {d['authority_address']}\")
"
}

cmd_list() {
    require_cli
    local filter="${1:-all}"
    echo -e "${BOLD}── Miners (${filter}) ──────────────────────────────${RESET}"
    ${CLI} listminers "${filter}" | python3 -c "
import sys, json, datetime
miners = json.load(sys.stdin)
if not miners:
    print('  (none)')
    sys.exit(0)
for m in miners:
    ts = m.get('registered_at', 0)
    date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d') if ts else '-'
    exp = m.get('expires_at', 0)
    exp_str = datetime.datetime.fromtimestamp(exp).strftime('%Y-%m-%d') if exp else 'never'
    status_color = {
        'approved': '\033[0;32m',
        'pending':  '\033[1;33m',
        'revoked':  '\033[0;31m',
        'suspended':'\033[0;34m',
    }.get(m['status'], '')
    reset = '\033[0m'
    print(f\"  {status_color}{m['status'].upper():12}{reset} {m['address']}\")
    print(f\"    KYC: {m['kyc_id']}  Name: {m['display_name']}\")
    print(f\"    Registered: {date}  Expires: {exp_str}\")
    print()
"
}

cmd_info() {
    require_cli
    [[ $# -ge 1 ]] || err "Usage: info <address>"
    ${CLI} getminerinfo "$1" | python3 -c "
import sys, json, datetime
m = json.load(sys.stdin)
def ts(t): return datetime.datetime.fromtimestamp(t).strftime('%Y-%m-%d %H:%M UTC') if t else 'none'
print(f\"Address:    {m['address']}\")
print(f\"Name:       {m['display_name']}\")
print(f\"KYC ID:     {m['kyc_id']}\")
print(f\"Status:     {m['status'].upper()}\")
print(f\"Registered: {ts(m.get('registered_at',0))}\")
print(f\"Approved:   {ts(m.get('approved_at',0))}\")
print(f\"Expires:    {ts(m.get('expires_at',0))}\")
print(f\"Susp until: {ts(m.get('suspended_until',0))}\")
"
}

cmd_stats() {
    require_cli
    ${CLI} getminerregistrystats
}

cmd_register() {
    require_cli
    [[ $# -ge 3 ]] || err "Usage: register <address> <kyc_id> <display_name>"
    local address="$1" kyc_id="$2"
    shift 2
    local name="$*"
    ${CLI} registerminer "${address}" "${kyc_id}" "${name}"
    ok "Registered miner ${address} (status: pending)"
}

cmd_sign_approve() {
    [[ $# -ge 1 ]] || err "Usage: sign-approve <address>"
    sign_message_cmd "APPROVE" "$1"
    echo "Then run:  glcoin-admin.sh approve ${1} <base64_signature>"
}

cmd_approve() {
    require_cli
    [[ $# -ge 2 ]] || {
        warn "No signature provided. Getting signing command instead..."
        cmd_sign_approve "$1"
        return
    }
    local address="$1" sig="$2"
    ${CLI} approveminer "${address}" "${sig}"
    ok "Approved miner ${address}"
}

cmd_sign_revoke() {
    [[ $# -ge 1 ]] || err "Usage: sign-revoke <address>"
    sign_message_cmd "REVOKE" "$1"
    echo "Then run:  glcoin-admin.sh revoke ${1} <base64_signature> [reason]"
}

cmd_revoke() {
    require_cli
    [[ $# -ge 2 ]] || {
        warn "No signature provided. Getting signing command instead..."
        cmd_sign_revoke "$1"
        return
    }
    local address="$1" sig="$2"
    shift 2
    local reason="${*:-}"
    ${CLI} revokeminer "${address}" "${sig}" "${reason}"
    ok "Revoked miner ${address}"
}

cmd_sign_suspend() {
    [[ $# -ge 1 ]] || err "Usage: sign-suspend <address>"
    sign_message_cmd "SUSPEND" "$1"
    echo "Then run:  glcoin-admin.sh suspend ${1} <base64_signature> <until_date>"
}

cmd_suspend() {
    require_cli
    [[ $# -ge 3 ]] || {
        warn "Usage: suspend <address> <signature> <until_date_or_timestamp>"
        cmd_sign_suspend "$1"
        return
    }
    local address="$1" sig="$2" until_input="$3"
    local until_ts
    if [[ "${until_input}" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
        until_ts=$(date -d "${until_input} 00:00:00 UTC" +%s 2>/dev/null || \
                   date -j -f "%Y-%m-%d %H:%M:%S" "${until_input} 00:00:00" +%s 2>/dev/null)
    else
        until_ts="${until_input}"
    fi
    ${CLI} suspendminer "${address}" "${sig}" "${until_ts}"
    ok "Suspended miner ${address} until $(date -d "@${until_ts}" 2>/dev/null || date -r "${until_ts}")"
}

cmd_sign_renew() {
    [[ $# -ge 1 ]] || err "Usage: sign-renew <address>"
    sign_message_cmd "RENEW" "$1"
    echo "Then run:  glcoin-admin.sh renew ${1} <base64_signature> <new_expiry_date>"
}

cmd_renew() {
    require_cli
    [[ $# -ge 3 ]] || {
        warn "Usage: renew <address> <signature> <new_expiry_date_or_timestamp>"
        cmd_sign_renew "$1"
        return
    }
    local address="$1" sig="$2" expiry_input="$3"
    local expiry_ts
    if [[ "${expiry_input}" == "0" ]]; then
        expiry_ts=0
    elif [[ "${expiry_input}" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
        expiry_ts=$(date -d "${expiry_input} 00:00:00 UTC" +%s 2>/dev/null || \
                    date -j -f "%Y-%m-%d %H:%M:%S" "${expiry_input} 00:00:00" +%s 2>/dev/null)
    else
        expiry_ts="${expiry_input}"
    fi
    ${CLI} renewminer "${address}" "${sig}" "${expiry_ts}"
    ok "Renewed miner ${address} expiry to ${expiry_input}"
}

# ── Main dispatcher ───────────────────────────────────────────────────────────
COMMAND="${1:-help}"
shift || true

case "${COMMAND}" in
    status)         cmd_status ;;
    list)           cmd_list "$@" ;;
    info)           cmd_info "$@" ;;
    stats)          cmd_stats ;;
    register)       cmd_register "$@" ;;
    sign-approve)   cmd_sign_approve "$@" ;;
    approve)        cmd_approve "$@" ;;
    sign-revoke)    cmd_sign_revoke "$@" ;;
    revoke)         cmd_revoke "$@" ;;
    sign-suspend)   cmd_sign_suspend "$@" ;;
    suspend)        cmd_suspend "$@" ;;
    sign-renew)     cmd_sign_renew "$@" ;;
    renew)          cmd_renew "$@" ;;
    help|--help|-h)
        echo "Glcoin Miner Registry Admin"
        echo ""
        echo "Usage: glcoin-admin.sh <command> [args]"
        echo ""
        echo "Information:"
        echo "  status                         Node + registry overview"
        echo "  list [pending|approved|all]    List miners by status"
        echo "  info <address>                 Show miner record"
        echo "  stats                          Registry statistics"
        echo ""
        echo "Registration (no authority key needed):"
        echo "  register <address> <kyc_id> <name>   Submit application"
        echo ""
        echo "Approval workflow (two-step: sign on air-gapped, apply here):"
        echo "  sign-approve <address>         Print signmessage command"
        echo "  approve <address> <sig>        Apply authority approval"
        echo "  sign-revoke  <address>         Print signmessage command"
        echo "  revoke  <address> <sig> [reason]"
        echo "  sign-suspend <address>         Print signmessage command"
        echo "  suspend <address> <sig> <date> (date: YYYY-MM-DD or unix ts)"
        echo "  sign-renew  <address>          Print signmessage command"
        echo "  renew   <address> <sig> <date> (0 = no expiry)"
        echo ""
        echo "Environment variables:"
        echo "  GLCOIN_CLI     Path to glcoin-cli  (default: /usr/local/bin/glcoin-cli)"
        echo "  GLCOIN_CONF    Path to glcoin.conf (default: /etc/glcoin/glcoin.conf)"
        echo "  GLCOIN_DATADIR Data directory      (default: /var/lib/glcoin/.glcoin)"
        ;;
    *)
        err "Unknown command: ${COMMAND}. Run 'glcoin-admin.sh help'."
        ;;
esac
