#!/usr/bin/env bash
# Glcoin — WireGuard VPN Setup for glcoin.org
#
# Run as root on the Debian Bookworm server:
#   sudo bash setup-wireguard.sh [--add-peer <peer_name>]
#
# What this does:
#   - Installs WireGuard
#   - Generates server keypair
#   - Creates /etc/wireguard/wg0.conf (server listens on UDP 51820)
#   - Enables IP forwarding for the VPN subnet
#   - Starts and enables wg-quick@wg0
#   - Adds first admin peer (interactive)
#   - Locks RPC (1617) and web admin (9090) to WireGuard subnet only
#
# Network layout:
#   Server (glcoin.org)  wg0: 10.99.0.1/24
#   Admin peer 1         wg0: 10.99.0.2/24
#   Admin peer 2         wg0: 10.99.0.3/24   (add with --add-peer)
#   ...
#
# After setup, admins connect via:
#   wg-quick up /etc/wireguard/glcoin-admin.conf
#   Then access http://10.99.0.1:9090  (web admin)
#         or   http://10.99.0.1:1617   (RPC, if needed directly)
#
set -euo pipefail

[[ $EUID -eq 0 ]] || { echo "Run as root."; exit 1; }

WG_IFACE="wg0"
WG_PORT="51820"
SERVER_VPN_IP="10.99.0.1"
VPN_SUBNET="10.99.0.0/24"
PEERS_DIR="/etc/wireguard/peers"
WG_CONF="/etc/wireguard/${WG_IFACE}.conf"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; RESET='\033[0m'

info()  { echo -e "${BLUE}[WG]${RESET} $*"; }
ok()    { echo -e "${GREEN}[OK]${RESET} $*"; }
warn()  { echo -e "${YELLOW}[!!]${RESET} $*"; }
err()   { echo -e "${RED}[ERR]${RESET} $*"; exit 1; }

detect_public_iface() {
    ip route show default | awk '/default via/ {print $5; exit}'
}

detect_public_ip() {
    curl -sf4 https://ifconfig.me || ip route get 1 | awk '{print $7; exit}'
}

# ── Install WireGuard ─────────────────────────────────────────────────────────
install_wireguard() {
    info "Installing WireGuard..."
    apt-get update -qq
    apt-get install -y --quiet wireguard wireguard-tools qrencode
    ok "WireGuard installed."
}

# ── Enable IP forwarding (for VPN routing) ────────────────────────────────────
enable_forwarding() {
    info "Enabling IP forwarding..."
    if ! grep -q "^net.ipv4.ip_forward=1" /etc/sysctl.conf 2>/dev/null; then
        echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf
    fi
    sysctl -qw net.ipv4.ip_forward=1
    ok "IP forwarding enabled."
}

# ── Generate server keypair ───────────────────────────────────────────────────
generate_server_keys() {
    mkdir -p /etc/wireguard
    chmod 700 /etc/wireguard

    if [[ -f /etc/wireguard/server.key ]]; then
        warn "Server key already exists — skipping key generation."
        SERVER_PRIVKEY=$(cat /etc/wireguard/server.key)
        SERVER_PUBKEY=$(cat /etc/wireguard/server.pub)
        return
    fi

    info "Generating server keypair..."
    SERVER_PRIVKEY=$(wg genkey)
    SERVER_PUBKEY=$(echo "${SERVER_PRIVKEY}" | wg pubkey)
    echo "${SERVER_PRIVKEY}" > /etc/wireguard/server.key
    echo "${SERVER_PUBKEY}"  > /etc/wireguard/server.pub
    chmod 600 /etc/wireguard/server.key
    ok "Server keys generated."
    ok "Server public key: ${SERVER_PUBKEY}"
}

# ── Write server wg0.conf ─────────────────────────────────────────────────────
write_server_conf() {
    local pub_iface; pub_iface=$(detect_public_iface)

    info "Writing ${WG_CONF}..."
    mkdir -p "${PEERS_DIR}"

    cat > "${WG_CONF}" <<EOF
# Glcoin WireGuard VPN — Server configuration
# Generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
# DO NOT share this file — it contains the server private key.

[Interface]
Address    = ${SERVER_VPN_IP}/24
ListenPort = ${WG_PORT}
PrivateKey = ${SERVER_PRIVKEY}

# NAT: route VPN traffic through the public interface
PostUp   = iptables -A FORWARD -i ${WG_IFACE} -j ACCEPT; \\
           iptables -A FORWARD -o ${WG_IFACE} -j ACCEPT; \\
           iptables -t nat -A POSTROUTING -s ${VPN_SUBNET} -o ${pub_iface} -j MASQUERADE
PostDown = iptables -D FORWARD -i ${WG_IFACE} -j ACCEPT; \\
           iptables -D FORWARD -o ${WG_IFACE} -j ACCEPT; \\
           iptables -t nat -D POSTROUTING -s ${VPN_SUBNET} -o ${pub_iface} -j MASQUERADE

# Peers are appended below by setup-wireguard.sh --add-peer
# ── PEERS ──────────────────────────────────────────────────────────────────────
EOF
    chmod 600 "${WG_CONF}"
    ok "Server config written to ${WG_CONF}"
}

# ── Add a peer ────────────────────────────────────────────────────────────────
add_peer() {
    local peer_name="${1:-}"
    local server_pubip; server_pubip=$(detect_public_ip)

    [[ -n "${peer_name}" ]] || {
        read -rp "Peer name (e.g. admin-laptop): " peer_name
    }
    [[ -n "${peer_name}" ]] || err "Peer name cannot be empty."

    # Find next available IP in 10.99.0.x range
    local next_ip=2
    while grep -q "10\.99\.0\.${next_ip}" "${WG_CONF}" 2>/dev/null; do
        next_ip=$(( next_ip + 1 ))
        [[ ${next_ip} -lt 254 ]] || err "VPN subnet full."
    done
    local PEER_VPN_IP="10.99.0.${next_ip}"

    # Generate peer keypair
    info "Generating keypair for peer '${peer_name}' (${PEER_VPN_IP})..."
    local PEER_PRIVKEY PEER_PUBKEY PEER_PSK
    PEER_PRIVKEY=$(wg genkey)
    PEER_PUBKEY=$(echo "${PEER_PRIVKEY}" | wg pubkey)
    PEER_PSK=$(wg genpsk)

    # Save peer keys
    local peer_dir="${PEERS_DIR}/${peer_name}"
    mkdir -p "${peer_dir}"
    chmod 700 "${peer_dir}"
    echo "${PEER_PRIVKEY}" > "${peer_dir}/client.key"
    echo "${PEER_PUBKEY}"  > "${peer_dir}/client.pub"
    echo "${PEER_PSK}"     > "${peer_dir}/psk"
    chmod 600 "${peer_dir}/client.key" "${peer_dir}/psk"

    # Append peer to server config
    cat >> "${WG_CONF}" <<EOF

# Peer: ${peer_name} — added $(date -u +"%Y-%m-%dT%H:%M:%SZ")
[Peer]
PublicKey    = ${PEER_PUBKEY}
PresharedKey = ${PEER_PSK}
AllowedIPs   = ${PEER_VPN_IP}/32
EOF

    # Write client config
    local CLIENT_CONF="${peer_dir}/${peer_name}.conf"
    cat > "${CLIENT_CONF}" <<EOF
# Glcoin Admin VPN — Client config for '${peer_name}'
# Import this into WireGuard on your admin device.
# DO NOT share this file.

[Interface]
Address    = ${PEER_VPN_IP}/24
PrivateKey = ${PEER_PRIVKEY}
DNS        = 1.1.1.1, 9.9.9.9

[Peer]
# glcoin.org server
PublicKey    = ${SERVER_PUBKEY}
PresharedKey = ${PEER_PSK}
Endpoint     = ${server_pubip}:${WG_PORT}
# Route only Glcoin VPN subnet through the tunnel (split tunnel)
AllowedIPs   = ${VPN_SUBNET}
PersistentKeepalive = 25
EOF
    chmod 600 "${CLIENT_CONF}"

    ok "Peer '${peer_name}' added:"
    ok "  VPN IP:      ${PEER_VPN_IP}"
    ok "  Config:      ${CLIENT_CONF}"
    echo ""

    # Reload WireGuard if already running
    if systemctl is-active --quiet "wg-quick@${WG_IFACE}" 2>/dev/null; then
        wg addconf "${WG_IFACE}" <(
            echo "[Peer]"
            echo "PublicKey    = ${PEER_PUBKEY}"
            echo "PresharedKey = ${PEER_PSK}"
            echo "AllowedIPs   = ${PEER_VPN_IP}/32"
        )
        ok "Peer added to running WireGuard interface (hot-reload)."
    fi

    # Show QR code if qrencode is available
    if command -v qrencode &>/dev/null; then
        echo ""
        echo -e "${BOLD}Scan this QR code with the WireGuard mobile app:${RESET}"
        qrencode -t ansiutf8 < "${CLIENT_CONF}"
    fi

    echo ""
    echo -e "${BOLD}Copy config to admin device:${RESET}"
    echo "  scp root@glcoin.org:${CLIENT_CONF} ~/glcoin-admin.conf"
    echo "  wg-quick up ~/glcoin-admin.conf"
    echo ""
    echo -e "${BOLD}Admin access after connecting:${RESET}"
    echo "  Web admin:  http://${SERVER_VPN_IP}:9090"
    echo "  RPC direct: http://${SERVER_VPN_IP}:1617  (with rpcuser/rpcpassword)"
    echo "  Admin CLI:  ssh user@${SERVER_VPN_IP}  (if SSH is bound to VPN IP)"
}

# ── Update UFW for WireGuard ──────────────────────────────────────────────────
configure_ufw_wireguard() {
    info "Configuring UFW for WireGuard..."
    if ! command -v ufw &>/dev/null; then
        warn "ufw not found — install with: apt-get install ufw"
        return
    fi

    ufw --force reset
    ufw default deny incoming
    ufw default allow outgoing

    # Public: SSH and P2P only
    ufw allow 22/tcp     comment 'SSH'
    ufw allow 1618/tcp   comment 'Glcoin P2P mainnet'
    ufw allow "${WG_PORT}/udp" comment 'WireGuard VPN'

    # VPN-only: RPC and web admin (accessible only through WireGuard tunnel)
    ufw allow in on "${WG_IFACE}" to "${SERVER_VPN_IP}" port 1617 proto tcp \
        comment 'Glcoin RPC (WireGuard only)'
    ufw allow in on "${WG_IFACE}" to "${SERVER_VPN_IP}" port 9090 proto tcp \
        comment 'Glcoin web admin (WireGuard only)'

    ufw --force enable
    ok "UFW configured. Public ports: 22/tcp, 1618/tcp, ${WG_PORT}/udp"
    ok "VPN-only ports: 1617/tcp, 9090/tcp (on ${WG_IFACE} only)"
}

# ── Enable and start WireGuard ────────────────────────────────────────────────
start_wireguard() {
    info "Enabling wg-quick@${WG_IFACE}..."
    systemctl enable "wg-quick@${WG_IFACE}"
    systemctl start  "wg-quick@${WG_IFACE}"
    ok "WireGuard started on ${WG_IFACE} (${SERVER_VPN_IP}, port ${WG_PORT}/udp)"
}

# ── Update glcoin-admin web panel to bind to WireGuard IP ────────────────────
update_admin_env() {
    local env_file="/etc/glcoin/admin.env"
    if [[ -f "${env_file}" ]]; then
        info "Updating admin env: GLCOIN_ADMIN_HOST → ${SERVER_VPN_IP}"
        sed -i "s|^GLCOIN_ADMIN_HOST=.*|GLCOIN_ADMIN_HOST=${SERVER_VPN_IP}|" "${env_file}"
        ok "Web admin will bind to ${SERVER_VPN_IP}:9090 (WireGuard interface)"
    fi
}

# ── Update glcoin.conf: RPC bind to WireGuard + localhost ────────────────────
update_glcoin_conf() {
    local conf="/etc/glcoin/glcoin.conf"
    if [[ -f "${conf}" ]]; then
        info "Updating glcoin.conf: rpcbind → 127.0.0.1 + ${SERVER_VPN_IP}"
        # Replace rpcbind line; add both localhost and WireGuard IP
        sed -i "s|^rpcbind=.*|rpcbind=127.0.0.1\nrpcbind=${SERVER_VPN_IP}|" "${conf}"
        # Add rpcallowip for WireGuard subnet if not already present
        if ! grep -q "rpcallowip=${VPN_SUBNET}" "${conf}"; then
            echo "rpcallowip=${VPN_SUBNET}" >> "${conf}"
        fi
        ok "RPC will accept connections from localhost and ${VPN_SUBNET}"
    fi
}

# ── Print status ──────────────────────────────────────────────────────────────
print_status() {
    echo ""
    echo -e "${BOLD}── WireGuard Status ──────────────────────────────────${RESET}"
    wg show "${WG_IFACE}" 2>/dev/null || true
}

# ── Main ──────────────────────────────────────────────────────────────────────
MODE="${1:-install}"

case "${MODE}" in
    install)
        install_wireguard
        enable_forwarding
        generate_server_keys
        write_server_conf
        configure_ufw_wireguard
        start_wireguard
        update_admin_env
        update_glcoin_conf

        echo ""
        echo -e "${BOLD}WireGuard server is ready. Add your first admin peer:${RESET}"
        echo "  sudo bash setup-wireguard.sh --add-peer admin-laptop"
        ;;

    --add-peer|-a)
        [[ -f "${WG_CONF}" ]] || err "WireGuard not configured. Run: sudo bash setup-wireguard.sh install"
        SERVER_PRIVKEY=$(cat /etc/wireguard/server.key)
        SERVER_PUBKEY=$(cat /etc/wireguard/server.pub)
        add_peer "${2:-}"
        ;;

    --status|-s)
        print_status
        ;;

    --list-peers|-l)
        echo -e "${BOLD}Configured peers:${RESET}"
        ls -1 "${PEERS_DIR}" 2>/dev/null | while read -r p; do
            ip=$(grep -oP '10\.99\.0\.\d+' "${PEERS_DIR}/${p}/${p}.conf" 2>/dev/null | head -1)
            echo "  ${p}  (${ip})"
        done
        ;;

    --remove-peer|-r)
        peer="${2:-}"
        [[ -n "${peer}" ]] || err "Usage: --remove-peer <peer_name>"
        PEER_PUBKEY=$(cat "${PEERS_DIR}/${peer}/client.pub" 2>/dev/null) \
            || err "Peer '${peer}' not found."
        wg set "${WG_IFACE}" peer "${PEER_PUBKEY}" remove 2>/dev/null || true
        # Remove from config file
        python3 - "${WG_CONF}" "${PEER_PUBKEY}" <<'PYEOF'
import sys, re
conf_path, pubkey = sys.argv[1], sys.argv[2]
with open(conf_path) as f:
    content = f.read()
# Remove the [Peer] block that contains this pubkey
pattern = r'# Peer:.*?(?=# Peer:|\Z)'
def keep(m):
    return '' if pubkey in m.group() else m.group()
content = re.sub(pattern, keep, content, flags=re.DOTALL)
with open(conf_path, 'w') as f:
    f.write(content)
PYEOF
        rm -rf "${PEERS_DIR}/${peer}"
        ok "Peer '${peer}' removed from WireGuard and config."
        ;;

    --help|-h)
        echo "Glcoin WireGuard Setup"
        echo ""
        echo "Usage: setup-wireguard.sh [command] [args]"
        echo ""
        echo "Commands:"
        echo "  install              Full WireGuard server setup"
        echo "  --add-peer [name]    Add new admin peer (generates keys + client config)"
        echo "  --list-peers         List configured peers"
        echo "  --remove-peer <n>    Remove a peer"
        echo "  --status             Show wg interface status"
        ;;

    *)
        err "Unknown command: ${MODE}. Run --help."
        ;;
esac
