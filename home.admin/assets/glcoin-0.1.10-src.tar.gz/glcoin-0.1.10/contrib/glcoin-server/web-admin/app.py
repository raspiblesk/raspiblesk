#!/usr/bin/env python3
"""
Glcoin Miner Registry Web Admin
A minimal Flask web interface for the Glcoin miner permission registry.
Runs on localhost only — proxy through nginx with TLS for production.

Dependencies: flask (pip install flask)
"""

import json
import os
import subprocess
import secrets
import time
from functools import wraps
from datetime import datetime

from flask import (Flask, render_template, request, redirect,
                   url_for, session, flash, jsonify)

app = Flask(__name__)
app.secret_key = os.environ.get("GLCOIN_ADMIN_SECRET", secrets.token_hex(32))

# ── Configuration ─────────────────────────────────────────────────────────────
CLI = os.environ.get("GLCOIN_CLI", "/usr/local/bin/glcoin-cli")
CONF = os.environ.get("GLCOIN_CONF", "/etc/glcoin/glcoin.conf")
DATADIR = os.environ.get("GLCOIN_DATADIR", "/var/lib/glcoin/.glcoin")
ADMIN_PASSWORD = os.environ.get("GLCOIN_ADMIN_PASSWORD", "")

if not ADMIN_PASSWORD:
    print("WARNING: GLCOIN_ADMIN_PASSWORD not set. Web admin is disabled.")
    print("Set it with: export GLCOIN_ADMIN_PASSWORD='your_strong_password'")


def cli(*args):
    """Run glcoin-cli command, return parsed JSON or raise."""
    cmd = [CLI, f"-conf={CONF}", f"-datadir={DATADIR}"] + list(args)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"glcoin-cli error (exit {result.returncode})")
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return result.stdout.strip()


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


def format_ts(ts):
    if not ts:
        return "—"
    return datetime.utcfromtimestamp(ts).strftime("%Y-%m-%d %H:%M UTC")


def current_hour():
    return int(time.time()) // 3600


# ── Auth ──────────────────────────────────────────────────────────────────────
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if not ADMIN_PASSWORD:
            flash("Admin password not configured on server.", "danger")
        elif secrets.compare_digest(request.form.get("password", ""), ADMIN_PASSWORD):
            session["logged_in"] = True
            session.permanent = False
            return redirect(url_for("dashboard"))
        else:
            flash("Incorrect password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.route("/")
@login_required
def dashboard():
    try:
        chain = cli("getblockchaininfo")
        stats = cli("getminerregistrystats")
        pending = cli("listminers", "pending")
    except Exception as e:
        flash(f"Node error: {e}", "danger")
        chain = stats = None
        pending = []
    return render_template("dashboard.html",
                           chain=chain, stats=stats, pending=pending,
                           format_ts=format_ts)


# ── Miners list ───────────────────────────────────────────────────────────────
@app.route("/miners")
@login_required
def miners():
    status_filter = request.args.get("status", "all")
    try:
        miners_list = cli("listminers", status_filter)
    except Exception as e:
        flash(f"Error fetching miners: {e}", "danger")
        miners_list = []
    return render_template("miners.html",
                           miners=miners_list, status_filter=status_filter,
                           format_ts=format_ts)


@app.route("/miners/<address>")
@login_required
def miner_detail(address):
    try:
        miner = cli("getminerinfo", address)
    except Exception as e:
        flash(f"Miner not found: {e}", "danger")
        return redirect(url_for("miners"))
    hour = current_hour()
    approve_msg = f"GLCOIN-MINER-APPROVE:{address}:{hour}"
    revoke_msg  = f"GLCOIN-MINER-REVOKE:{address}:{hour}"
    return render_template("miner_detail.html", miner=miner, format_ts=format_ts,
                           approve_msg=approve_msg, revoke_msg=revoke_msg,
                           current_hour=hour)


# ── Registration ──────────────────────────────────────────────────────────────
@app.route("/miners/register", methods=["GET", "POST"])
@login_required
def register_miner():
    if request.method == "POST":
        address = request.form.get("address", "").strip()
        kyc_id  = request.form.get("kyc_id", "").strip()
        name    = request.form.get("display_name", "").strip()
        try:
            cli("registerminer", address, kyc_id, name)
            flash(f"Registered miner {address} (pending approval).", "success")
            return redirect(url_for("miner_detail", address=address))
        except Exception as e:
            flash(f"Registration failed: {e}", "danger")
    return render_template("register.html")


# ── Actions (apply authority signature) ───────────────────────────────────────
@app.route("/miners/<address>/approve", methods=["POST"])
@login_required
def approve_miner(address):
    sig = request.form.get("signature", "").strip()
    if not sig:
        flash("Signature is required to approve.", "danger")
        return redirect(url_for("miner_detail", address=address))
    try:
        cli("approveminer", address, sig)
        flash(f"Miner {address} approved.", "success")
    except Exception as e:
        flash(f"Approval failed: {e}", "danger")
    return redirect(url_for("miner_detail", address=address))


@app.route("/miners/<address>/revoke", methods=["POST"])
@login_required
def revoke_miner(address):
    sig    = request.form.get("signature", "").strip()
    reason = request.form.get("reason", "").strip()
    if not sig:
        flash("Signature is required to revoke.", "danger")
        return redirect(url_for("miner_detail", address=address))
    try:
        cli("revokeminer", address, sig, reason)
        flash(f"Miner {address} revoked.", "success")
    except Exception as e:
        flash(f"Revocation failed: {e}", "danger")
    return redirect(url_for("miner_detail", address=address))


@app.route("/miners/<address>/suspend", methods=["POST"])
@login_required
def suspend_miner(address):
    sig         = request.form.get("signature", "").strip()
    until_input = request.form.get("until_date", "").strip()
    if not sig or not until_input:
        flash("Signature and until_date are required.", "danger")
        return redirect(url_for("miner_detail", address=address))
    try:
        from datetime import datetime, timezone
        until_ts = int(datetime.strptime(until_input, "%Y-%m-%d")
                       .replace(tzinfo=timezone.utc).timestamp())
        cli("suspendminer", address, sig, str(until_ts))
        flash(f"Miner {address} suspended until {until_input}.", "success")
    except Exception as e:
        flash(f"Suspension failed: {e}", "danger")
    return redirect(url_for("miner_detail", address=address))


@app.route("/miners/<address>/renew", methods=["POST"])
@login_required
def renew_miner(address):
    sig          = request.form.get("signature", "").strip()
    expiry_input = request.form.get("expiry_date", "").strip()
    if not sig:
        flash("Signature is required.", "danger")
        return redirect(url_for("miner_detail", address=address))
    try:
        if expiry_input in ("0", ""):
            expiry_ts = 0
        else:
            from datetime import datetime, timezone
            expiry_ts = int(datetime.strptime(expiry_input, "%Y-%m-%d")
                            .replace(tzinfo=timezone.utc).timestamp())
        cli("renewminer", address, sig, str(expiry_ts))
        flash(f"Miner {address} expiry updated.", "success")
    except Exception as e:
        flash(f"Renewal failed: {e}", "danger")
    return redirect(url_for("miner_detail", address=address))


# ── API (for monitoring scripts) ──────────────────────────────────────────────
@app.route("/api/stats")
@login_required
def api_stats():
    try:
        return jsonify(cli("getminerregistrystats"))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    host = os.environ.get("GLCOIN_ADMIN_HOST", "127.0.0.1")
    port = int(os.environ.get("GLCOIN_ADMIN_PORT", "9090"))
    debug = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host=host, port=port, debug=debug)
