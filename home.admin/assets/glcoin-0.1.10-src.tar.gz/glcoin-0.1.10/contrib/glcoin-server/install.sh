#!/usr/bin/env bash
# Glcoin Server Permission System — Debian Bookworm Setup
#
# Run as root on a fresh Debian 12 (Bookworm) server:
#   sudo bash install.sh /path/to/built/glcoin/binaries
#
# What this does:
#   1. Creates the 'glcoin' system user with minimal permissions
#   2. Creates /etc/glcoin/ and /var/lib/glcoin/ with correct ownership
#   3. Installs glcoin binaries to /usr/local/bin/
#   4. Installs the admin CLI to /usr/local/bin/glcoin-admin
#   5. Deploys the systemd service
#   6. Installs the web admin panel under /opt/glcoin-admin/
#   7. Sets up WireGuard VPN (admin access tunnel — interactive: adds first peer)
#   8. Configures UFW firewall (locks RPC + web admin to WireGuard subnet)
#   9. Sets up logrotate for glcoin debug.log
#
set -euo pipefail

[[ $EUID -eq 0 ]] || { echo "Run as root."; exit 1; }

BINDIR="${1:-/home/vboxuser/porubing/glcoin/build/bin}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "──────────────────────────────────────────────"
echo " Glcoin Server Permission System — Installer"
echo " Binaries: ${BINDIR}"
echo " Steps: 9 (WireGuard VPN included)"
echo "──────────────────────────────────────────────"
echo ""

# ── 1. System user ────────────────────────────────────────────────────────────
echo "[1/9] Creating glcoin system user..."
if id glcoin &>/dev/null; then
    echo "      User 'glcoin' already exists — skipping."
else
    adduser --system --group --home /var/lib/glcoin --shell /usr/sbin/nologin \
            --gecos "Glcoin daemon" glcoin
fi

# ── 2. Directories ────────────────────────────────────────────────────────────
echo "[2/9] Creating directories..."
mkdir -p /etc/glcoin /var/lib/glcoin/.glcoin /var/log/glcoin

chown -R glcoin:glcoin /var/lib/glcoin /var/log/glcoin
chmod 750 /etc/glcoin /var/lib/glcoin /var/log/glcoin

# Deploy config template if no config exists
if [[ ! -f /etc/glcoin/glcoin.conf ]]; then
    cp "${SCRIPT_DIR}/etc/glcoin.conf.template" /etc/glcoin/glcoin.conf
    chown glcoin:glcoin /etc/glcoin/glcoin.conf
    chmod 600 /etc/glcoin/glcoin.conf
    echo "      Deployed /etc/glcoin/glcoin.conf — EDIT BEFORE STARTING NODE!"
else
    echo "      /etc/glcoin/glcoin.conf already exists — keeping existing."
fi

# ── 3. Binaries ───────────────────────────────────────────────────────────────
echo "[3/9] Installing binaries to /usr/local/bin/..."
for bin in glcoind glcoin-cli glcoin-tx glcoin-util glcoin-wallet; do
    src="${BINDIR}/${bin}"
    if [[ -f "${src}" ]]; then
        install -o root -g root -m 755 "${src}" "/usr/local/bin/${bin}"
        echo "      Installed ${bin}"
    else
        echo "      WARNING: ${src} not found — skipping."
    fi
done

# ── 4. Admin CLI ──────────────────────────────────────────────────────────────
echo "[4/9] Installing glcoin-admin CLI..."
install -o root -g root -m 755 \
    "${SCRIPT_DIR}/scripts/glcoin-admin.sh" /usr/local/bin/glcoin-admin
echo "      Installed /usr/local/bin/glcoin-admin"

# ── 5. Systemd service ────────────────────────────────────────────────────────
echo "[5/9] Installing systemd service..."
install -o root -g root -m 644 \
    "${SCRIPT_DIR}/systemd/glcoind.service" /etc/systemd/system/glcoind.service
systemctl daemon-reload
systemctl enable glcoind.service
echo "      Service installed and enabled (NOT started — edit config first)."

# ── 6. Web admin panel ────────────────────────────────────────────────────────
echo "[6/9] Installing web admin panel..."
apt-get install -y --quiet python3 python3-pip python3-venv 2>/dev/null || true

mkdir -p /opt/glcoin-admin
cp -r "${SCRIPT_DIR}/web-admin/." /opt/glcoin-admin/
chown -R root:glcoin /opt/glcoin-admin
chmod 750 /opt/glcoin-admin

python3 -m venv /opt/glcoin-admin/venv
/opt/glcoin-admin/venv/bin/pip install -q -r /opt/glcoin-admin/requirements.txt

# Web admin systemd service
cat > /etc/systemd/system/glcoin-admin.service <<'EOF'
[Unit]
Description=Glcoin Miner Registry Web Admin
After=glcoind.service
Requires=glcoind.service

[Service]
User=glcoin
Group=glcoin
WorkingDirectory=/opt/glcoin-admin
EnvironmentFile=-/etc/glcoin/admin.env
ExecStart=/opt/glcoin-admin/venv/bin/python app.py
Restart=on-failure
RestartSec=10s
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=/var/lib/glcoin

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable glcoin-admin.service

# Create environment file template if it doesn't exist
if [[ ! -f /etc/glcoin/admin.env ]]; then
    cat > /etc/glcoin/admin.env <<'ENVEOF'
# Glcoin Web Admin Environment
# chmod 600 /etc/glcoin/admin.env after editing

GLCOIN_CLI=/usr/local/bin/glcoin-cli
GLCOIN_CONF=/etc/glcoin/glcoin.conf
GLCOIN_DATADIR=/var/lib/glcoin/.glcoin
GLCOIN_ADMIN_HOST=127.0.0.1
GLCOIN_ADMIN_PORT=9090

# REQUIRED: Set a strong password before starting
GLCOIN_ADMIN_PASSWORD=CHANGE_ME_NOW

# REQUIRED: Set a random secret key
GLCOIN_ADMIN_SECRET=CHANGE_ME_RANDOM_32_CHARS
ENVEOF
    chown glcoin:glcoin /etc/glcoin/admin.env
    chmod 600 /etc/glcoin/admin.env
    echo "      Created /etc/glcoin/admin.env — SET PASSWORD BEFORE STARTING!"
fi

# ── 7. WireGuard VPN ─────────────────────────────────────────────────────────
echo "[7/9] Setting up WireGuard VPN..."
WG_SETUP="${SCRIPT_DIR}/wireguard/setup-wireguard.sh"
if [[ -f "${WG_SETUP}" ]]; then
    bash "${WG_SETUP}" install
    echo ""
    echo "      WireGuard installed. Add your first admin peer now:"
    echo "      bash ${WG_SETUP} --add-peer admin-laptop"
    echo ""
    echo "      (You can skip this and run --add-peer later.)"
    echo ""
    read -rp "      Add a peer now? [Y/n]: " ADD_PEER_NOW
    if [[ "${ADD_PEER_NOW,,}" != "n" ]]; then
        bash "${WG_SETUP}" --add-peer
    fi
else
    echo "      wireguard/setup-wireguard.sh not found — skipping WireGuard setup."
    echo "      Run manually: bash contrib/glcoin-server/wireguard/setup-wireguard.sh install"
fi

# ── 8. Firewall ───────────────────────────────────────────────────────────────
# WireGuard setup handles full UFW config if it ran above.
# This step is a safety net for deployments without WireGuard.
echo "[8/9] Verifying UFW firewall..."
if command -v ufw &>/dev/null; then
    if ! ufw status | grep -q "Status: active"; then
        echo "      UFW not active — enabling with basic rules..."
        ufw --force reset
        ufw default deny incoming
        ufw default allow outgoing
        ufw allow 22/tcp    comment 'SSH'
        ufw allow 1618/tcp  comment 'Glcoin P2P mainnet'
        ufw --force enable
        echo "      WARNING: WireGuard was not set up. RPC and web admin are blocked."
        echo "               Run setup-wireguard.sh to enable VPN-secured admin access."
    else
        ufw status verbose
    fi
else
    echo "      ufw not installed — install with: apt-get install ufw"
fi

# ── 9. Logrotate ──────────────────────────────────────────────────────────────
echo "[9/9] Configuring logrotate..."
cat > /etc/logrotate.d/glcoin <<'EOF'
/var/lib/glcoin/.glcoin/debug.log {
    weekly
    rotate 8
    compress
    delaycompress
    missingok
    notifempty
    create 640 glcoin glcoin
}
EOF

echo ""
echo "──────────────────────────────────────────────"
echo " Installation complete."
echo ""
echo " NEXT STEPS:"
echo ""
echo " 1. Edit /etc/glcoin/glcoin.conf:"
echo "    - Set rpcuser, rpcpassword"
echo "    - After generating authority key: set minerauthorityaddress"
echo ""
echo " 2. Edit /etc/glcoin/admin.env:"
echo "    - Set GLCOIN_ADMIN_PASSWORD to a strong password"
echo "    - Set GLCOIN_ADMIN_SECRET to 32 random chars"
echo ""
echo " 3. Start the node:"
echo "    systemctl start glcoind"
echo "    systemctl status glcoind"
echo ""
echo " 4. Connect via WireGuard VPN (from your admin device):"
echo "    # Copy the peer config generated in step 7:"
echo "    scp root@glcoin.org:/etc/wireguard/peers/<name>/<name>.conf ~/glcoin-admin.conf"
echo "    wg-quick up ~/glcoin-admin.conf"
echo "    # Then access:"
echo "    #   http://10.99.0.1:9090   (web admin)"
echo "    #   http://10.99.0.1:1617   (RPC direct, if needed)"
echo ""
echo " 5. Start the web admin:"
echo "    systemctl start glcoin-admin"
echo ""
echo " 6. Generate authority key (on air-gapped machine):"
echo "    glcoin-cli getnewaddress '' bech32"
echo "    glcoin-cli dumpprivkey <address>  # Store offline"
echo ""
echo " 7. Register first miner:"
echo "    glcoin-admin register <address> <kyc_id> <name>"
echo "    glcoin-admin sign-approve <address>"
echo "    # sign on air-gapped machine, then:"
echo "    glcoin-admin approve <address> <sig>"
echo ""
echo " 8. Add more admin peers:"
echo "    bash contrib/glcoin-server/wireguard/setup-wireguard.sh --add-peer <name>"
echo ""
echo "──────────────────────────────────────────────"
