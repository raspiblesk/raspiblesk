# Safe Installation of a Glcoin Seed Node on Debian Bookworm

This guide describes how to securely install and configure a Glcoin seed node on Debian Bookworm (12.x). A seed node helps new nodes discover peers in the Glcoin network.

## ⚠️ Security Considerations

Before proceeding, understand that running a seed node exposes your server to the internet. Follow these security principles:
- Run as a non-root user with minimal privileges
- Keep the system updated
- Configure a firewall to limit exposed ports
- Monitor logs regularly
- Use SSH key authentication (disable password login)
- Consider using fail2ban for brute-force protection

## System Preparation

### 1. Update System and Install Basic Tools

```bash
# Update package lists
sudo apt-get update
sudo apt-get upgrade -y

# Install essential tools
sudo apt-get install -y git build-essential cmake pkg-config \
                        libevent-dev libboost-dev libsqlite3-dev \
                        libcapnp-dev capnproto libzmq3-dev \
                        systemtap-sdt-dev libssl-dev \
                        ufw fail2ban
```

### 2. Handle Existing glcoin User (If Any)

If there is already a glcoin user on the system that you need to replace or if you're unsure about existing configurations, follow these steps to safely remove it:

```bash
# Stop any running glcoin services first
sudo systemctl stop glcoin-seed 2>/dev/null || true
sudo systemctl disable glcoin-seed 2>/dev/null || true

# Remove the glcoin user and its home directory
sudo deluser --remove-home glcoin 2>/dev/null || true

# Remove the glcoin group if it exists
sudo delgroup glcoin 2>/dev/null || true

# Remove any remaining configuration or data directories (back up first if needed!)
sudo rm -rf /etc/glcoin /var/lib/glcoin 2>/dev/null || true
```

> **Warning**: The above commands will permanently remove the glcoin user, its home directory, and any configuration/data. Only run these if you are sure you want to remove an existing glcoin installation. If you want to keep an existing glcoin installation, skip this step and proceed with caution.

### 3. Create a Dedicated User

```bash
# Create a system user for glcoin
sudo adduser --system --group --home /var/lib/glcoin glcoin

# Switch to the glcoin user for subsequent steps
sudo -u glcoin -H bash
```

### 4. Configure SSH Security (Recommended)

On your local machine, copy your SSH key:
```bash
ssh-copy-id glcoin@your-server-ip
```

Then on the server, disable password authentication:
```bash
sudo nano /etc/ssh/sshd_config
```
Set:
```
PasswordAuthentication no
PermitRootLogin no
```
Then restart SSH:
```bash
sudo systemctl restart ssh
```

## Installing Glcoin

### 5. Download and Verify Source Code

```bash
# As the glcoin user
cd /var/lib/glcoin
git clone https://github.com/your-repo/glcoin.git
cd glcoin

# Optional: Verify git tag or commit
git tag  # List available tags
git checkout v1.0.0  # Or appropriate version tag
```

### 6. Install Dependencies

```bash
# Install build dependencies
sudo apt-get install -y qt6-base-dev qt6-tools-dev qt6-l10n-tools \
                        qt6-tools-dev-tools libgl-dev libqrencode-dev \
                        qt6-wayland

# For command-line only seed node (no GUI), you can skip Qt dependencies
# but we'll install them for completeness
```

### 7. Compile Glcoin

```bash
# Create build directory
mkdir -p build && cd build

# Configure build (disable GUI for pure seed node if preferred)
# For a seed node, GUI is not necessary
cmake .. -DBUILD_GUI=OFF -DENABLE_WALLET=OFF

# Alternative: Build with full functionality
# cmake ..

# Compile using all available CPU cores
make -j$(nproc)

# Install binaries to /usr/local/bin
sudo make install
```

## Configuring as a Seed Node

### 8. Create Configuration Directory

```bash
# Create configuration directory
sudo mkdir -p /etc/glcoin
sudo chown glcoin:glcoin /etc/glcoin

# Create data directory
sudo mkdir -p /var/lib/glcoin/.glcoin
sudo chown glcoin:glcoin /var/lib/glcoin/.glcoin
```

### 9. Create Configuration File

Create `/etc/glcoin/glcoin.conf` with the following content:

```ini
# Glcoin Seed Node Configuration
# Only modify values if you understand the implications

# Network settings
server=1
daemon=1
listen=1
port=1618

# Seed node specific settings
# These help the node function as a good peer discovery source
maxconnections=125
maxuploadtarget=10000  # MB per day, adjust based on your bandwidth
blocksonly=1  # Reduces bandwidth by not relaying transactions
peerbloomfilters=0  # Disable bloom filters to save bandwidth

# Logging and debugging
debug=net
logtimestamps=1
shrinkdebugfile=1

# RPC settings (disable if not needed for monitoring)
rpcbind=127.0.0.1  # Listen only on localhost
rpcport=1617
rpcallowip=127.0.0.1
# rpcuser=yourusername  # Uncomment and set if using RPC
# rpcpassword=yourpassword  # Uncomment and set if using RPC

# Disable unnecessary features for a seed node
disablewallet=1
```

Set proper permissions:
```bash
sudo chmod 600 /etc/glcoin/glcoin.conf
sudo chown glcoin:glcoin /etc/glcoin/glcoin.conf
```

### 10. Configure Firewall

```bash
# Allow SSH (if not already configured)
sudo ufw allow ssh

# Allow Glcoin P2P port
sudo ufw allow 1618/tcp

# Optional: Allow RPC port only from localhost (more secure)
# sudo ufw allow 1617/tcp comment 'Glcoin RPC (localhost only)'

# Enable firewall
sudo ufw enable

# Verify status
sudo ufw status verbose
```

### 11. Create Systemd Service

Create `/etc/systemd/system/glcoin-seed.service`:

```ini
[Unit]
Description=Glcoin Seed Node
After=network.target

[Service]
User=glcoin
Group=glcoin
Type=forking
PIDFile=/var/lib/glcoin/.glcoin/glcoind.pid
ExecStart=/usr/local/bin/glcoind -conf=/etc/glcoin/glcoin.conf -datadir=/var/lib/glcoin/.glcoin
ExecStop=/usr/local/bin/glcoin-cli -conf=/etc/glcoin/glcoin.conf -datadir=/var/lib/glcoin/.glcoin stop
Restart=on-failure
RestartSec=30s
TimeoutStartSec=5min
TimeoutStopSec=5min

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
PrivateDevices=true
OwnCloudDevices=false
MachineIdLockbox=false

[Install]
WantedBy=multi-user.target
```

Enable and start the service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable glcoin-seed
sudo systemctl start glcoin-seed
```

Check status:
```bash
sudo systemctl status glcoin-seed
```

## Verification and Monitoring

### 12. Verify Node is Running

```bash
# Check if process is running
pgrep -u glcoin glcoind

# Check connection count (after node has synchronized)
sudo -u glcoin glcoin-cli -conf=/etc/glcoin/glcoin.conf -datadir=/var/lib/glcoin/.glcoin getnetworkinfo

# Check logs
sudo journalctl -u glcoin-seed -f
```

### 13. Monitor Performance

Set up basic monitoring:
```bash
# Check installed packages for monitoring
sudo apt-get install -y htop iotop net-tools

# Basic checks
htop  # Process and resource monitoring
netstat -tulpn | grep glcoin  # Check listening ports
```

## Maintenance

### 14. Regular Updates

```bash
# Update system packages weekly
sudo apt-get update && sudo apt-get upgrade -y

# Periodically check for Glcoin updates
cd /var/lib/glcoin/glcoin
git fetch origin
git log HEAD..origin/main  # See if there are new commits
# If updates exist, review them then:
# git pull
# cd build && make clean && cmake .. && make -j$(nproc)
# sudo systemctl restart glcoin-seed
```

### 15. Log Rotation

Ensure logs are rotated properly:
```bash
# Check if logrotate config exists for glcoin
sudo nano /etc/logrotate.d/glcoin

# Add if not present:
/var/lib/glcoin/.glcoin/debug.log {
    weekly
    rotate 4
    compress
    delaycompress
    missingok
    notifempty
    create 640 glcoin adm
    sharedscripts
    postrotate
        # Restart glcoin to reopen log files (optional)
        # systemctl reload glcoin-seed >/dev/null 2>&1 || true
    endscript
}
```

## Troubleshooting

### Common Issues

1. **Node not accepting connections**:
   - Check firewall: `sudo ufw status`
   - Verify port is listening: `netstat -tulpn | grep 1618`
   - Check logs for binding errors

2. **High CPU/memory usage**:
   - Check if node is still syncing: `getinfo` or `getblockchaininfo`
   - Consider increasing swap if RAM is limited
   - Verify no other resource-heavy processes running

3. **DNS seed not working**:
   - Verify DNS records are correctly configured
   - Check that seeder.py or equivalent is running (if using DNS seeds)
   - Test with: `dig @your-server dnsseed.glcoin.org.`

## Advanced Configuration

### Running as a DNS Seed

If you want to run a proper DNS seed (not just a node that accepts connections), you'll need to:

1. Set up a domain with DNS records pointing to your server
2. Install and run the DNS seed software from `contrib/seeds/`
3. Configure your nameserver to use the seeder for your subdomain

Refer to `dns.glcoin.org.md` for details on required DNS records.

### Bandwidth Limiting

For VPS with limited bandwidth, adjust in `glcoin.conf`:
```ini
maxuploadtarget=5000  # Limit to 5GB per day
maxconnections=50     # Reduce simultaneous connections
```

## Security Hardening Checklist

- [ ] Running as non-root user (glcoin)
- [ ] SSH key authentication enabled, password login disabled
- [ ] Firewall configured (only necessary ports open)
- [ ] Fail2ban installed and configured
- [ ] Automatic security updates enabled
- [ ] Regular log monitoring
- [ ] Minimal services running (only glcoin and essential system services)
- [ ] File permissions set correctly (600 for config, 700 for directories)
- [ ] Systemd service with security restrictions (PrivateTmp, ProtectSystem, etc.)

## References

- Glcoin Documentation: `/doc/` directory in source
- Build Instructions: `doc/build-unix.md`
- Dependency Information: `doc/dependencies.md`
- Seed Node Concept: Glcoin BIP155 and DNS seeds

---
*Last updated: $(date +%Y-%m-%d)*
*For Debian Bookworm (12.x) with Glcoin v1.0.0*