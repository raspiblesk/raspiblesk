# Glcoin-Qt Build Dependencies

## apt install (eine Zeile)

```
sudo apt-get install -y build-essential cmake pkg-config libevent-dev libboost-dev libsqlite3-dev libzmq3-dev libcapnp-dev capnproto systemtap-sdt-dev qt6-base-dev qt6-tools-dev qt6-l10n-tools qt6-tools-dev-tools libgl-dev libqrencode-dev qt6-wayland libxkbcommon-dev libxkbcommon-x11-dev libxcb-xkb-dev
```

## CMake konfigurieren

```bash
mkdir -p build && cd build
cmake .. -DBUILD_GUI=ON
```

## Bauen (nur glcoin-qt)

```bash
cmake --build . --target glcoin-qt -j2
```

## Alle Binaries bauen

```bash
cmake --build . -j2
```

## Hinweise

- `-j2` statt `-j$(nproc)` verwenden — bei parallelem Build crasht MOC (Qt meta-object compiler) mit Signal 11
- Mindestanforderungen: GCC 14+, CMake 3.22+, Qt 6.2+, Boost 1.74+, libevent 2.1.8+, SQLite 3.7.17+
- Binary nach dem Build: `build/bin/glcoin-qt`
