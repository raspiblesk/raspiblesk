# Glcoin Mining Setup Guide

This guide covers setting up a Glcoin mining environment on Debian Trixie (Linux) and Windows 10/11.

## Prerequisites

- **Glcoin Node**: Running `glcoind` or `glcoin-qt` daemon
- **Wallet**: A Glcoin address to receive block rewards
- **Python 3.8+**: For the glcoin-miner.py script
- **Sufficient RAM**: At least 4GB recommended for mining operations

---

## Part 1: Debian Trixie Setup

### 1.1 Install Dependencies

```bash
# Update package list
sudo apt update

# Install required packages
sudo apt install -y python3 python3-pip git build-essential

# Verify Python version
python3 --version
```

### 1.2 Clone or Access Glcoin Miner

```bash
# Navigate to your Glcoin directory
cd /home/vboxuser/porubing/glcoin-miner

# Verify the miner script exists
ls -la glcoin_miner.py
```

### 1.3 Configure glcoind

Create a configuration file for your node:

```bash
mkdir -p ~/.glcoin
cat > ~/.glcoin/glcoin.conf << 'EOF'
# Glcoin Configuration

# RPC settings
rpcuser=glcoinuser
rpcpassword=glcoinpassword
rpcbind=127.0.0.1
rpcport=1617

# Network settings
port=1618
bind=127.0.0.1

# Mining settings
gen=1
mine-to=YOUR_GLCOIN_ADDRESS
EOF
```

Replace `YOUR_GLCOIN_ADDRESS` with your actual Glcoin address (see §1.4).

### 1.4 Create or Import Wallet

```bash
# Start glcoind
/home/vboxuser/porubing/glcoin/build/bin/glcoind -daemon

# Wait for startup
sleep 5

# Create new wallet
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli createwallet my_mining_wallet

# Get mining address
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -rpcwallet=my_mining_wallet getnewaddress
```

Copy this address to your `glcoin.conf` as `mine-to`.

### 1.5 Start Mining

**Option A: Using Built-in RPC Miner (CPU Mining)**

```bash
# Generate blocks using RPC (for testing)
ADDRESS=$(/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli -rpcwallet=my_mining_wallet getnewaddress)
/home/vboxuser/porubing/glcoin/build/bin/glcoin-cli generatetoaddress 10 "$ADDRESS"
```

**Option B: Using Python Miner**

```bash
# Run the Python miner (mine-plain mode)
cd /home/vboxuser/porubing/glcoin-miner
python3 glcoin_miner.py mine-plain --rpc-url http://127.0.0.1:1617 --address "$ADDRESS"
```

The miner will:
1. Connect to glcoind via JSON-RPC
2. Fetch block templates
3. Solve PoW (header hashing)
4. Submit blocks via `submitblock`

### 1.6 Useful Commands

```bash
# Check chain height
glcoin-cli getblockchaininfo | grep blocks

# Check wallet balance
glcoin-cli -rpcwallet=my_mining_wallet getbalance

# List recent transactions
glcoin-cli -rpcwallet=my_mining_wallet listtransactions

# Stop the node
glcoin-cli stop
```

---

## Part 2: Windows 10/11 Setup

### 2.1 Install Glcoin

1. Copy the built binaries from your build directory:
   ```
   build-win64/bin/
   ├── glcoind.exe
   ├── glcoin-cli.exe
   ├── glcoin-qt.exe
   └── glcoin-wallet.exe
   ```

2. Create a folder (e.g., `C:\Glcoin`) and place the .exe files there.

### 2.2 Configure glcoind

Create `C:\Users\<YourUser>\AppData\Roaming\Glcoin\glcoin.conf`:

```ini
# Glcoin Configuration

rpcuser=glcoinuser
rpcpassword=glcoinpassword
rpcbind=127.0.0.1
rpcport=1617

port=1618
bind=127.0.0.1

gen=1
mine-to=YOUR_GLCOIN_ADDRESS
```

### 2.3 Start Glcoin Node

Open Command Prompt or PowerShell:

```cmd
cd C:\Glcoin
glcoind.exe -daemon
```

Or run with GUI:

```cmd
glcoin-qt.exe
```

### 2.4 Create Wallet

```cmd
# In a new command prompt
glcoin-cli.exe createwallet mining_wallet

# Get mining address
glcoin-cli.exe -rpcwallet=mining_wallet getnewaddress
```

### 2.5 Start Mining (PowerShell/CMD)

**Option A: Built-in RPC**

```cmd
set ADDRESS=C:\Glcoin\your_address_here
glcoin-cli.exe generatetoaddress 10 %ADDRESS%
```

**Option B: Python Miner**

Python must be installed on Windows. Download from python.org or via winget:

```cmd
winget install Python.Python.3.11
```

Then run:

```cmd
cd C:\Glcoin\glcoin-miner
python.exe glcoin_miner.py mine-plain --rpc-url http://127.0.0.1:1617 --address YOUR_ADDRESS
```

---

## Part 3: Mining on Different Chains

Glcoin supports multiple chain configurations. Use the appropriate RPC port:

| Chain    | RPC Port | P2P Port |
|----------|---------|----------|
| mainnet  | 1617    | 1618     |
| testnet  | 11617   | 11618    |
| testnet4 | 21617   | 21618    |
| signet   | 31617   | 31618    |
| regtest  | 41617   | 41618    |

### 3.1 Testnet/Regtest Mining

```bash
# For regtest (easiest for testing)
glcoind.exe -regtest -daemon
glcoin-cli.exe -regtest createwallet test_wallet
ADDRESS=$(glcoin-cli.exe -regtest -rpcwallet=test_wallet getnewaddress)
glcoin-cli.exe -regtest generatetoaddress 100 "$ADDRESS"
```

Note: Regtest and testnet have lower difficulty, making CPU mining feasible for testing.

---

## Part 4: Troubleshooting

### glcoind Won't Start

- Check port availability: `netstat -an | grep 1617`
- Delete lock files: `rm ~/.glcoin/glcoind.pid`

### Python Miner Errors

- Ensure Python 3.8+: `python3 --version`
- Install dependencies: No external dependencies required
- Check RPC credentials match: Verify `rpcuser`/`rpcpassword` in config

### Wallet Not Found

- Load wallet explicitly: `glcoin-cli loadwallet my_wallet`
- Use `-rpcwallet=WALLET_NAME` flag

### Connection Refused

- Verify glcoind is running: `pgrep glcoind` (Linux) or `tasklist | findstr glcoind` (Windows)
- Check firewall: Allow port 1617 (RPC) through any firewall

### Low Difficulty / No Blocks

- Use regtest for fastest results: `glcoind -regtest`
- Testnet/testnet4 have higher difficulty than regtest but lower than mainnet

---

## Part 5: Performance Notes

### Mainnet Mining

- **Solo CPU mining on mainnet is NOT practical** due to difficulty
- The `1d00ffff` target requires ~10^15 hashes per block on average
- GPU/ASIC mining hardware is required for real mainnet rewards
- Consider pool mining instead

### Regtest Mining

- Low difficulty (`0x207fffff`) — blocks can be found in seconds
- Ideal for: development, testing, learning
- No real value — only for development purposes

### Testnet/Testnet4

- Medium difficulty — suitable for testing mining software
- Test coins have no real value
- Good for: testing wallet integration, pool software

---

## Quick Reference

| Task | Linux Command | Windows Command |
|------|--------------|-----------------|
| Start node | `glcoind -daemon` | `glcoind.exe -daemon` |
| Create wallet | `glcoin-cli createwallet w` | `glcoin-cli.exe createwallet w` |
| Get address | `glcoin-cli -rpcwallet=w getnewaddress` | `glcoin-cli.exe -rpcwallet=w getnewaddress` |
| Mine blocks | `glcoin-cli generatetoaddress N ADDRESS` | `glcoin-cli.exe generatetoaddress N ADDRESS` |
| Check balance | `glcoin-cli -rpcwallet=w getbalance` | `glcoin-cli.exe -rpcwallet=w getbalance` |
| Check chain | `glcoin-cli getblockchaininfo` | `glcoin-cli.exe getblockchaininfo` |
| Stop node | `glcoin-cli stop` | `glcoin-cli.exe stop` |

---

## Security Notes

1. **Never expose RPC to public internet** — Use localhost only or VPN tunneling
2. **Use strong RPC passwords** — Generate random passwords
3. **Wallet encryption** — Use `encryptwallet` RPC for encrypted wallets
4. **Backup wallet.dat** — Regular backups recommended
5. **Mainnet involves real funds** — Use hardware wallets for production

---

End of Mining Setup Guide