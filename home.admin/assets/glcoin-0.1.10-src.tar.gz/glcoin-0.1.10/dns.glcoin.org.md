# DNS Records for Glcoin Seed Nodes

This document provides the DNS records needed to set up DNS seed nodes for Glcoin.
DNS seeds allow Glcoin nodes to discover peers automatically via DNS lookup.

## Overview

Glcoin uses DNS seeds for peer discovery. The following DNS records should be configured:

- **A records** (IPv4) - optional, for IPv4 reachable seed nodes
- **AAAA records** (IPv6) - required for IPv6 seed nodes
- **TXT records** - optional, for additional metadata

## Required DNS Records

Based on the Glcoin source code configuration in `src/kernel/chainparams.cpp`:

### Mainnet
- `dnsseed.glcoin.org.` - Primary DNS seed for mainnet
- `seed.glcoin.org.` - Alternative/fallback DNS seed for mainnet
- `dnsseed.glcoin.ch.` - Primary DNS seed for mainnet (alternative domain)
- `seed.glcoin.ch.` - Alternative/fallback DNS seed for mainnet (alternative domain)

### Testnet
- `dnsseed.testnet.glcoin.org.` - Primary DNS seed for testnet
- `seed.testnet.glcoin.org.` - Alternative DNS seed for testnet
- `dnsseed.testnet.glcoin.ch.` - Primary DNS seed for testnet (alternative domain)
- `seed.testnet.glcoin.ch.` - Alternative DNS seed for testnet (alternative domain)

### Testnet4
- `dnsseed.testnet4.glcoin.org.` - Primary DNS seed for testnet4
- `seed.testnet4.glcoin.org.` - Alternative DNS seed for testnet4
- `dnsseed.testnet4.glcoin.ch.` - Primary DNS seed for testnet4 (alternative domain)
- `seed.testnet4.glcoin.ch.` - Alternative DNS seed for testnet4 (alternative domain)

### Signet
- `dnsseed.signet.glcoin.org.` - Primary DNS seed for signet
- `seed.signet.glcoin.org.` - Alternative DNS seed for signet
- `dnsseed.signet.glcoin.ch.` - Primary DNS seed for signet (alternative domain)
- `seed.signet.glcoin.ch.` - Alternative DNS seed for signet (alternative domain)

## Example Zone File

Below is an example DNS zone file snippet for BIND/named:

```
; Glcoin DNS Seed Records
; Mainnet
dnsseed.glcoin.org.    IN  AAAA  2a0e:f0c1:0:1870::100
seed.glcoin.org.       IN  AAAA  2a0e:f0c1:0:1870::100
dnsseed.glcoin.ch.     IN  AAAA  2a0e:f0c1:0:1870::100
seed.glcoin.ch.        IN  AAAA  2a0e:f0c1:0:1870::100

; Testnet
dnsseed.testnet.glcoin.org.    IN  AAAA  2a0e:f0c1:0:1870::100
seed.testnet.glcoin.org.       IN  AAAA  2a0e:f0c1:0:1870::100
dnsseed.testnet.glcoin.ch.     IN  AAAA  2a0e:f0c1:0:1870::100
seed.testnet.glcoin.ch.        IN  AAAA  2a0e:f0c1:0:1870::100

; Testnet4
dnsseed.testnet4.glcoin.org.   IN  AAAA  2a0e:f0c1:0:1870::100
seed.testnet4.glcoin.org.      IN  AAAA  2a0e:f0c1:0:1870::100
dnsseed.testnet4.glcoin.ch.    IN  AAAA  2a0e:f0c1:0:1870::100
seed.testnet4.glcoin.ch.       IN  AAAA  2a0e:f0c1:0:1870::100

; Signet
dnsseed.signet.glcoin.org.     IN  AAAA  2a0e:f0c1:0:1870::100
seed.signet.glcoin.org.        IN  AAAA  2a0e:f0c1:0:1870::100
dnsseed.signet.glcoin.ch.      IN  AAAA  2a0e:f0c1:0:1870::100
seed.signet.glcoin.ch.         IN  AAAA  2a0e:f0c1:0:1870::100
```

## Additional Configuration

### TXT Records (Optional)

You can add TXT records to provide version or implementation information:

```
dnsseed.glcoin.org.    IN  TXT  "Glcoin DNS Seed v1.0"
seed.glcoin.org.       IN  TXT  "Glcoin DNS Seed v1.0"
dnsseed.glcoin.ch.     IN  TXT  "Glcoin DNS Seed v1.0 (ch domain)"
seed.glcoin.ch.        IN  TXT  "Glcoin DNS Seed v1.0 (ch domain)"
```

### Multiple Seed Nodes

For redundancy, you can configure multiple seed nodes by creating additional A/AAAA records with the same hostname pointing to different IP addresses:

```
dnsseed.glcoin.org.    IN  AAAA  2a0e:f0c1:0:1870::100
dnsseed.glcoin.org.    IN  AAAA  2001:db8::1          ; Second seed node
seed.glcoin.org.       IN  AAAA  2a0e:f0c1:0:1870::100
seed.glcoin.org.       IN  AAAA  2001:db8::1          ; Second seed node
```

## TTL Settings

Recommended TTL values:
- **A/AAAA records**: 3600 seconds (1 hour) - balances update frequency with DNS load
- **TXT records**: 3600 seconds (1 hour)

## Verification

After configuring DNS, verify with:

```bash
# Check mainnet DNS seed
dig AAAA dnsseed.glcoin.org. +short
dig AAAA seed.glcoin.org. +short
dig AAAA dnsseed.glcoin.ch. +short
dig AAAA seed.glcoin.ch. +short

# Check testnet DNS seed
dig AAAA dnsseed.testnet.glcoin.org. +short
dig AAAA seed.testnet.glcoin.org. +short
dig AAAA dnsseed.testnet.glcoin.ch. +short
dig AAAA seed.testnet.glcoin.ch. +short

# Check testnet4 DNS seed
dig AAAA dnsseed.testnet4.glcoin.org. +short
dig AAAA seed.testnet4.glcoin.org. +short
dig AAAA dnsseed.testnet4.glcoin.ch. +short
dig AAAA seed.testnet4.glcoin.ch. +short

# Check signet DNS seed
dig AAAA dnsseed.signet.glcoin.org. +short
dig AAAA seed.signet.glcoin.org. +short
dig AAAA dnsseed.signet.glcoin.ch. +short
dig AAAA seed.signet.glcoin.ch. +short
```

## Notes

1. **IP Address**: Replace `2a0e:f0c1:0:1870::100` with your actual seed node's IPv6 address.
2. **IPv4 Support**: If your seed node has IPv4 connectivity, add corresponding A records.
3. **Firewall**: Ensure your seed node allows incoming TCP connections on:
   - Mainnet: 1618
   - Testnet: 11618
   - Testnet4: 11618
   - Signet: 31618
4. **Software**: You'll need to run a DNS seed crawler/server (like Glcoin's `dnsseed.py`) on your seed node to provide dynamic peer lists.
5. **See `contrib/seeds/`**: Refer to the seeds directory in the Glcoin source for tools to generate dynamic seed responses.
6. **Domains**: This configuration covers both `glcoin.org` and `glcoin.ch` domains as mentioned by the user.

## References

- BIP155: DNS seeds for Glcoin-based networks
- Glcoin chainparams: `/src/kernel/chainparams.cpp`
- DNS seed generator: `contrib/seeds/generate-seeds.py`