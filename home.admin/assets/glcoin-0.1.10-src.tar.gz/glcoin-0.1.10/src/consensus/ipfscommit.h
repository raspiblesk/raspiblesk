// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// ============================================================
// Glcoin — Consensus-level IPFS commitment
//
// An optional, per-block coinbase commitment that anchors one
// transaction in the block to a binary-encoded IPFS CID.
//
// OP_RETURN payload layout (≤ 80 bytes):
//
//    +---------+---------------+----------------------+
//    | "glc1"  | txid_anchor   | cid_bytes            |
//    | 4 bytes | 32 bytes      | 34..44 bytes         |
//    +---------+---------------+----------------------+
//
// txid_anchor MUST reference a non-coinbase transaction in the
// same block.  cid_bytes MUST parse as CIDv0 (0x12 0x20 <32B>)
// or CIDv1 with a recognised codec + multihash function.
//
// The commitment is:
//   • optional (a block without it is valid)
//   • unique   (at most one "glc1" output may appear in a block)
//   • enforced from params.IPFSCommitHeight onwards
// ============================================================

#ifndef GLCOIN_CONSENSUS_IPFSCOMMIT_H
#define GLCOIN_CONSENSUS_IPFSCOMMIT_H

#include <consensus/amount.h>
#include <primitives/block.h>
#include <primitives/transaction.h>
#include <uint256.h>

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace Consensus { struct Params; }

/** 4-byte magic that marks a coinbase OP_RETURN as an IPFS commitment. */
inline constexpr unsigned char IPFS_COMMIT_MAGIC[4] = {'g', 'l', 'c', '1'};

/** OP_RETURN standardness cap: magic(4) + txid(32) + CID(≤44). */
static constexpr size_t IPFS_COMMIT_MAX_PAYLOAD  = 80;
static constexpr size_t IPFS_COMMIT_MIN_PAYLOAD  = 4 + 32 + 34;   // magic + txid + CIDv0
static constexpr size_t IPFS_COMMIT_MAX_CID_SIZE = IPFS_COMMIT_MAX_PAYLOAD - 4 - 32;

/** A parsed commitment payload extracted from a coinbase output. */
struct IPFSCommitment {
    uint256               txid_anchor;
    std::vector<uint8_t>  cid_bytes;   // raw multihash/CID bytes (no multibase)
    unsigned int          version;     // 0 = CIDv0, 1 = CIDv1
    uint64_t              codec;       // multicodec (CIDv0 ⇒ dag-pb = 0x70)
    uint64_t              hash_fn;     // multihash function code
    unsigned int          hash_len;    // multihash digest length
};

/** Parse a raw CID byte string (no multibase prefix).  Returns an
 *  IPFSCommitment whose txid_anchor field is left at the caller's
 *  default — only the CID-related fields are populated here. */
std::optional<IPFSCommitment> ParseCIDBytes(const std::vector<uint8_t>& cid);

/** Serialise the OP_RETURN scriptPubKey for a commitment.
 *  Returns the full scriptPubKey (OP_RETURN + pushdata + payload). */
std::vector<uint8_t> BuildIPFSCommitScript(const uint256& txid_anchor,
                                           const std::vector<uint8_t>& cid_bytes);

/** Extract the commitment from a coinbase transaction.
 *  Returns nullopt if no glc1-prefixed OP_RETURN is present.
 *  Returns a commitment (possibly with bad fields) when present.
 *  The caller must still call IsCoinbaseCommitmentStructurallyValid()
 *  to decide whether it satisfies the consensus rules. */
std::optional<IPFSCommitment> ExtractCoinbaseIPFSCommitment(const CTransaction& coinbase,
                                                            std::string& parse_error);

/** Consensus gate used by ContextualCheckBlock.
 *  Returns true when the block satisfies the commitment rules at the
 *  given height (= height of the block being validated).  When it
 *  returns false the reason string is populated. */
bool CheckBlockIPFSCommitment(const CBlock& block,
                              int nHeight,
                              const Consensus::Params& params,
                              std::string& reason);

#endif // GLCOIN_CONSENSUS_IPFSCOMMIT_H
