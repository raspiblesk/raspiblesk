// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <consensus/ipfscommit.h>

#include <consensus/amount.h>
#include <consensus/params.h>
#include <script/script.h>
#include <uint256.h>
#include <util/cid.h>

#include <algorithm>
#include <cstring>

// ---------------------------------------------------------------------------
// ParseCIDBytes
//
// Public API maintained for ipfscommit_tests.cpp and any future caller that
// needs an IPFSCommitment from raw bytes.  Delegates validation entirely to
// the shared cid::ParseBytes so the two IPFS subsystems can never diverge.
// ---------------------------------------------------------------------------
std::optional<IPFSCommitment> ParseCIDBytes(const std::vector<uint8_t>& cid)
{
    auto parsed = cid::ParseBytes(cid);
    if (!parsed) return std::nullopt;

    IPFSCommitment c{};
    c.cid_bytes = cid;
    c.version   = parsed->version;
    c.codec     = parsed->codec;
    c.hash_fn   = parsed->hash_fn;
    c.hash_len  = parsed->hash_len;
    // txid_anchor is left as zero — callers that need it populate it themselves
    return c;
}

// ---------------------------------------------------------------------------
// Script helpers
// ---------------------------------------------------------------------------
static std::vector<uint8_t> EncodeMinimalPush(const std::vector<uint8_t>& data)
{
    std::vector<uint8_t> out;
    const size_t n = data.size();
    if (n < OP_PUSHDATA1) {
        out.push_back(static_cast<uint8_t>(n));
    } else if (n <= 0xFF) {
        out.push_back(OP_PUSHDATA1);
        out.push_back(static_cast<uint8_t>(n));
    } else if (n <= 0xFFFF) {
        out.push_back(OP_PUSHDATA2);
        out.push_back(static_cast<uint8_t>(n & 0xFF));
        out.push_back(static_cast<uint8_t>((n >> 8) & 0xFF));
    } else {
        out.push_back(OP_PUSHDATA4);
        for (int i = 0; i < 4; ++i)
            out.push_back(static_cast<uint8_t>((n >> (8 * i)) & 0xFF));
    }
    out.insert(out.end(), data.begin(), data.end());
    return out;
}

std::vector<uint8_t> BuildIPFSCommitScript(const uint256& txid_anchor,
                                           const std::vector<uint8_t>& cid_bytes)
{
    std::vector<uint8_t> payload;
    payload.reserve(4 + 32 + cid_bytes.size());
    payload.insert(payload.end(), std::begin(IPFS_COMMIT_MAGIC), std::end(IPFS_COMMIT_MAGIC));
    payload.insert(payload.end(), txid_anchor.begin(), txid_anchor.end());
    payload.insert(payload.end(), cid_bytes.begin(), cid_bytes.end());

    std::vector<uint8_t> spk;
    spk.push_back(OP_RETURN);
    const auto pushed = EncodeMinimalPush(payload);
    spk.insert(spk.end(), pushed.begin(), pushed.end());
    return spk;
}

// ---------------------------------------------------------------------------
// Extract a commitment payload from a single OP_RETURN output
// ---------------------------------------------------------------------------
static std::optional<std::vector<uint8_t>> ReadOpReturnPayload(const CScript& script)
{
    if (script.size() < 2 || script[0] != OP_RETURN) return std::nullopt;

    CScript::const_iterator it = script.begin() + 1;
    std::vector<uint8_t> data;
    opcodetype op{};
    if (!script.GetOp(it, op, data)) return std::nullopt;
    if (it != script.end()) return std::nullopt; // trailing bytes — not a pure push
    return data;
}

std::optional<IPFSCommitment> ExtractCoinbaseIPFSCommitment(const CTransaction& coinbase,
                                                            std::string& parse_error)
{
    parse_error.clear();
    std::optional<IPFSCommitment> found;
    int found_count = 0;

    for (const CTxOut& out : coinbase.vout) {
        const auto payload = ReadOpReturnPayload(out.scriptPubKey);
        if (!payload) continue;
        if (payload->size() < 4) continue;
        if (!std::equal(std::begin(IPFS_COMMIT_MAGIC), std::end(IPFS_COMMIT_MAGIC),
                        payload->begin())) {
            continue;
        }

        ++found_count;

        if (payload->size() > IPFS_COMMIT_MAX_PAYLOAD) {
            parse_error = "ipfs-commit-too-large";
            return std::nullopt;
        }
        if (payload->size() < IPFS_COMMIT_MIN_PAYLOAD) {
            parse_error = "ipfs-commit-too-small";
            return std::nullopt;
        }

        uint256 anchor{};
        std::memcpy(anchor.begin(), payload->data() + 4, 32);
        std::vector<uint8_t> cid_bytes(payload->begin() + 4 + 32, payload->end());

        auto parsed = ParseCIDBytes(cid_bytes);
        if (!parsed) {
            parse_error = "ipfs-commit-bad-cid";
            return std::nullopt;
        }
        parsed->txid_anchor = anchor;
        found = std::move(parsed);
        // Keep scanning to detect duplicate commitments
    }

    if (found_count > 1) {
        parse_error = "ipfs-commit-duplicate";
        return std::nullopt;
    }
    return found;
}

// ---------------------------------------------------------------------------
// Consensus gate
// ---------------------------------------------------------------------------
bool CheckBlockIPFSCommitment(const CBlock& block,
                              int nHeight,
                              const Consensus::Params& params,
                              std::string& reason)
{
    reason.clear();
    if (block.vtx.empty()) {
        reason = "bad-block-empty";
        return false;
    }

    const CTransaction& cb = *block.vtx[0];
    std::string extract_err;
    auto commit = ExtractCoinbaseIPFSCommitment(cb, extract_err);

    if (!commit) {
        if (extract_err.empty()) {
            // No commitment present — always valid (feature is optional)
            return true;
        }
        // Malformed commitment: rejected only after activation height.
        // Before activation it is treated as an ordinary (ignored) OP_RETURN.
        if (nHeight < params.IPFSCommitHeight) return true;
        reason = extract_err;
        return false;
    }

    // Anchor txid must exist as a non-coinbase transaction in this block.
    // Enforced unconditionally — even pre-activation voluntary commitments
    // must be semantically valid.
    const CTransaction* anchor_tx = nullptr;
    for (size_t i = 1; i < block.vtx.size(); ++i) {
        if (block.vtx[i]->GetHash().ToUint256() == commit->txid_anchor) {
            anchor_tx = block.vtx[i].get();
            break;
        }
    }
    if (!anchor_tx) {
        reason = "ipfs-commit-anchor-missing";
        return false;
    }

    // Anti-spam burn rule (post-activation, rate configurable per network).
    // Anchor tx must burn at least cid_bytes.size() * IPFSCommitBurnPerByte satoshis
    // via OP_RETURN outputs.  Rate = 0 disables the requirement (regtest default).
    if (nHeight >= params.IPFSCommitHeight && params.IPFSCommitBurnPerByte > 0) {
        CAmount burned = 0;
        for (const CTxOut& out : anchor_tx->vout) {
            if (out.scriptPubKey.IsUnspendable()) burned += out.nValue;
        }
        const CAmount required =
            static_cast<CAmount>(commit->cid_bytes.size()) * params.IPFSCommitBurnPerByte;
        if (burned < required) {
            reason = "ipfs-commit-anchor-underpaid";
            return false;
        }
    }

    return true;
}
