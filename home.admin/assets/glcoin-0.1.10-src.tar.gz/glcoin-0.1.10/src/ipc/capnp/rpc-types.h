// Copyright (c) 2025 The Glcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef BITCOIN_IPC_CAPNP_RPC_TYPES_H
#define BITCOIN_IPC_CAPNP_RPC_TYPES_H

#include <ipc/capnp/common.capnp.proxy-types.h>
#include <ipc/capnp/common-types.h>
#include <ipc/capnp/rpc.capnp.proxy.h>

#endif // BITCOIN_IPC_CAPNP_RPC_TYPES_H
