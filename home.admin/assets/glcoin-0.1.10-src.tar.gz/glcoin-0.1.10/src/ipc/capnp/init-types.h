// Copyright (c) 2021-present The Glcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef BITCOIN_IPC_CAPNP_INIT_TYPES_H
#define BITCOIN_IPC_CAPNP_INIT_TYPES_H

#include <ipc/capnp/echo.capnp.proxy-types.h>
#include <ipc/capnp/mining.capnp.proxy-types.h>
#include <ipc/capnp/rpc.capnp.proxy-types.h>

#endif // BITCOIN_IPC_CAPNP_INIT_TYPES_H
