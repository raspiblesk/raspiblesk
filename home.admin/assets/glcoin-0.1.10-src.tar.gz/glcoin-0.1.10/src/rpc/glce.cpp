// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <rpc/glce.h>

#include <common/args.h>
#include <crypto/glce.h>
#include <key.h>
#include <pubkey.h>
#include <random.h>
#include <rpc/server.h>
#include <rpc/server_util.h>
#include <rpc/util.h>
#include <support/allocators/secure.h>
#include <univalue.h>
#include <util/fs.h>
#include <util/strencodings.h>

#include <array>
#include <cstdio>
#include <cstring>
#include <string>
#include <variant>
#include <vector>

// ---------------------------------------------------------------------------
// Encryption key management — <datadir>/glce.key (32 raw bytes)
//
// Independent of the spending wallet.  Generated once on first use.
// Back up this file or the full datadir to preserve your encryption identity.
// ---------------------------------------------------------------------------

static CKey LoadOrCreateEncryptionKey()
{
    const fs::path key_path = gArgs.GetDataDirNet() / "glce.key";

    if (fs::exists(key_path)) {
        FILE* f = fsbridge::fopen(key_path, "rb");
        if (!f) throw JSONRPCError(RPC_INTERNAL_ERROR, "Cannot open glce.key");
        std::array<uint8_t, 32> raw{};
        const size_t n = std::fread(raw.data(), 1, 32, f);
        std::fclose(f);
        if (n != 32) throw JSONRPCError(RPC_INTERNAL_ERROR, "glce.key is corrupt (expected 32 bytes)");
        CKey key;
        key.Set(raw.begin(), raw.end(), /*compressed=*/true);
        memory_cleanse(raw.data(), raw.size());
        if (!key.IsValid()) throw JSONRPCError(RPC_INTERNAL_ERROR, "glce.key contains an invalid key");
        return key;
    }

    CKey key;
    key.MakeNewKey(/*compressed=*/true);

    FILE* f = fsbridge::fopen(key_path, "wb");
    if (!f) throw JSONRPCError(RPC_INTERNAL_ERROR, "Cannot create glce.key");
    const size_t n = std::fwrite(key.begin(), 1, 32, f);
    std::fclose(f);
    if (n != 32) throw JSONRPCError(RPC_INTERNAL_ERROR, "Failed to write glce.key");

#ifndef WIN32
    fs::permissions(key_path,
                    fs::perms::owner_read | fs::perms::owner_write,
                    fs::perm_options::replace);
#endif

    return key;
}

// ---------------------------------------------------------------------------
// getencryptionpubkey
// ---------------------------------------------------------------------------
static RPCMethod getencryptionpubkey()
{
    return RPCMethod{
        "getencryptionpubkey",
        "Return this node's secp256k1 encryption public key (compressed, hex).\n"
        "The key lives in <datadir>/glce.key and is created on first call if absent.\n"
        "Share this pubkey with senders so they can encrypt content for this node.\n",
        {},
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR_HEX, "pubkey",  "33-byte compressed secp256k1 encryption pubkey"},
                {RPCResult::Type::STR,     "keyfile", "Absolute path to the key file"},
            }
        },
        RPCExamples{
            HelpExampleCli("getencryptionpubkey", "")
            + HelpExampleRpc("getencryptionpubkey", "")
        },
        [](const RPCMethod& /*self*/, const JSONRPCRequest& /*request*/) -> UniValue
        {
            CKey key = LoadOrCreateEncryptionKey();
            UniValue obj(UniValue::VOBJ);
            obj.pushKV("pubkey",  HexStr(key.GetPubKey()));
            obj.pushKV("keyfile", PathToString(gArgs.GetDataDirNet() / "glce.key"));
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// encryptcontent
// ---------------------------------------------------------------------------
static RPCMethod encryptcontent()
{
    return RPCMethod{
        "encryptcontent",
        "Encrypt hex-encoded content for a recipient's encryption pubkey.\n"
        "Returns the GLCE blob as hex.  Only the holder of the matching private key\n"
        "can decrypt it.  Pin the blob to IPFS with `ipfs add` to get a CID.\n",
        {
            {"content_hex",      RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "Plaintext bytes to encrypt, hex-encoded."},
            {"recipient_pubkey", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "Recipient's 33-byte compressed secp256k1 encryption pubkey (hex)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR_HEX, "blob",        "Encrypted GLCE blob (hex)"},
                {RPCResult::Type::NUM,     "blob_bytes",  "Blob size in bytes"},
                {RPCResult::Type::NUM,     "plain_bytes", "Original plaintext size in bytes"},
            }
        },
        RPCExamples{
            HelpExampleCli("encryptcontent", "\"48656c6c6f\" \"02a1b2...\"")
            + HelpExampleRpc("encryptcontent", "\"48656c6c6f\", \"02a1b2...\"")
        },
        [](const RPCMethod& /*self*/, const JSONRPCRequest& request) -> UniValue
        {
            const auto plain   = ParseHex<std::byte>(request.params[0].get_str());
            const auto pk_hex  = ParseHex<uint8_t>(request.params[1].get_str());

            if (pk_hex.size() != 33)
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "recipient_pubkey must be 33 bytes (66 hex chars)");

            CPubKey recip(pk_hex);
            if (!recip.IsFullyValid())
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid recipient pubkey");

            auto result = glce::Encrypt(plain, {recip});
            if (std::holds_alternative<std::string>(result))
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Encryption failed: " + std::get<std::string>(result));

            const auto& blob = std::get<glce::Blob>(result);
            UniValue obj(UniValue::VOBJ);
            obj.pushKV("blob",        HexStr(blob));
            obj.pushKV("blob_bytes",  static_cast<int>(blob.size()));
            obj.pushKV("plain_bytes", static_cast<int>(plain.size()));
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// decryptcontent
// ---------------------------------------------------------------------------
static RPCMethod decryptcontent()
{
    return RPCMethod{
        "decryptcontent",
        "Decrypt a GLCE blob (hex) using this node's encryption private key.\n"
        "The node must have been one of the recipients when the blob was created.\n",
        {
            {"blob_hex", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "GLCE encrypted blob, hex-encoded."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR_HEX, "content",       "Decrypted plaintext (hex)"},
                {RPCResult::Type::NUM,     "content_bytes",  "Plaintext size in bytes"},
            }
        },
        RPCExamples{
            HelpExampleCli("decryptcontent", "\"474c4345...\"")
            + HelpExampleRpc("decryptcontent", "\"474c4345...\"")
        },
        [](const RPCMethod& /*self*/, const JSONRPCRequest& request) -> UniValue
        {
            const auto blob = ParseHex<std::byte>(request.params[0].get_str());
            if (!glce::IsGLCEBlob(blob))
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Input is not a valid GLCE blob");

            CKey privkey = LoadOrCreateEncryptionKey();
            auto result  = glce::Decrypt(blob, privkey);
            if (std::holds_alternative<std::string>(result))
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Decryption failed: " + std::get<std::string>(result));

            const auto& plain = std::get<glce::Blob>(result);
            UniValue obj(UniValue::VOBJ);
            obj.pushKV("content",      HexStr(plain));
            obj.pushKV("content_bytes", static_cast<int>(plain.size()));
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------
void RegisterGLCERPCCommands(CRPCTable& t)
{
    static const CRPCCommand commands[]{
        {"glce", &getencryptionpubkey},
        {"glce", &encryptcontent},
        {"glce", &decryptcontent},
    };
    for (const auto& c : commands) t.appendCommand(c.name, &c);
}
