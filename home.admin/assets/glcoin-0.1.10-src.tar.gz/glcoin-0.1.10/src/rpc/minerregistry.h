// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#pragma once

#include <util/fs.h>

class CRPCTable;

// Opens (or creates) the miner registry LevelDB.
// Call from AppInitMain() before RegisterMinerRegistryRPCCommands().
void InitMinerRegistryDB(const fs::path& datadir, bool in_memory = false);

// Returns the global registry DB pointer (may be nullptr if not initialised).
class CMinerRegistryDB;
CMinerRegistryDB* GetMinerRegistryDB();

// Register all miner-registry RPC commands with the RPC table.
void RegisterMinerRegistryRPCCommands(CRPCTable& t);
