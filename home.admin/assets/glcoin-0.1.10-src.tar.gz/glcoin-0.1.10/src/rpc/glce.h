// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#pragma once

class CRPCTable;

void RegisterGLCERPCCommands(CRPCTable& tableRPC);
