// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// ============================================================
// Glcoin RPC commands for IPFS link storage
//
// storeipfslink  <txid> <cid> [description]
//   Store an IPFS CID anchored to a transaction ID.
//   Returns the stored record as JSON.
//
// getipfslink  <txid>
//   Retrieve the IPFS link record for a given txid.
//
// listipfslinks
//   List all stored IPFS link records, newest first.
//
// removeipfslink  <txid>
//   Delete the IPFS link record for a given txid.
// ============================================================

#include <rpc/ipfslink.h>

#include <consensus/ipfscommit.h>
#include <ipfsclient.h>
#include <ipfslink.h>
#include <util/cid.h>
#include <node/context.h>
#include <rpc/server.h>
#include <rpc/server_util.h>
#include <rpc/util.h>
#include <univalue.h>
#include <util/strencodings.h>

#include <memory>
#include <stdexcept>

// Global DB instance — initialised by AppInitMain() via InitIPFSLinkDB()
static std::unique_ptr<CIPFSLinkDB> g_ipfslink_db;

void InitIPFSLinkDB(const fs::path& datadir, bool in_memory)
{
    g_ipfslink_db = std::make_unique<CIPFSLinkDB>(
        datadir / "ipfslinks", 1 << 20, in_memory);
}

CIPFSLinkDB* GetIPFSLinkDB()
{
    return g_ipfslink_db.get();
}

// ---------------------------------------------------------------------------
// Helper — serialise a CIPFSLink to UniValue JSON
// ---------------------------------------------------------------------------
static UniValue LinkToJSON(const CIPFSLink& link)
{
    UniValue obj(UniValue::VOBJ);
    obj.pushKV("txid",        link.txid.ToString());
    obj.pushKV("cid",         link.cid);
    obj.pushKV("description", link.description);
    obj.pushKV("timestamp",   link.timestamp);
    return obj;
}

// ---------------------------------------------------------------------------
// storeipfslink
// ---------------------------------------------------------------------------
static RPCMethod storeipfslink()
{
    return RPCMethod{
        "storeipfslink",
        "Store an IPFS Content Identifier (CID) anchored to a Glcoin transaction.\n"
        "The record is kept in a local LevelDB database and is NOT broadcast to peers.",
        {
            {"txid",        RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The transaction ID to anchor the IPFS link to."},
            {"cid",         RPCArg::Type::STR,     RPCArg::Optional::NO,
             "IPFS Content Identifier (CIDv0 starting with Qm, or CIDv1 starting with bafy/b)."},
            {"description", RPCArg::Type::STR,     RPCArg::Default{std::string{}},
             "Optional human-readable label (max 256 characters)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,     "txid",        "Transaction ID"},
                {RPCResult::Type::STR,     "cid",         "IPFS CID"},
                {RPCResult::Type::STR,     "description", "Label"},
                {RPCResult::Type::NUM,     "timestamp",   "Unix timestamp of storage"},
            },
        },
        RPCExamples{
            HelpExampleCli("storeipfslink",
                "\"<txid>\" "
                "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\" "
                "\"My document\"")
            + HelpExampleRpc("storeipfslink",
                "\"<txid>\", "
                "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\", "
                "\"My document\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }

            const uint256 txid = ParseHashV(request.params[0], "txid");
            const std::string cid = request.params[1].get_str();
            const std::string desc = request.params.size() > 2
                ? request.params[2].get_str() : "";

            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Invalid IPFS CID. Must be a well-formed CIDv0 (Qm…, 46 base58btc chars) "
                    "or CIDv1 (multibase-prefixed: b/B=base32, z=base58btc, f=base16) "
                    "with a recognised codec and multihash function.");
            }
            if (!IsValidIPFSDescription(desc)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Invalid description: must be valid UTF-8, max 256 bytes, "
                    "no control characters (tab allowed).");
            }

            if (!g_ipfslink_db->StoreLinkForTx(txid, cid, desc)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Failed to store link — record may already exist for this txid.");
            }

            const auto stored = g_ipfslink_db->GetLinkForTx(txid);
            if (!stored) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "Store succeeded but read-back failed.");
            }
            return LinkToJSON(*stored);
        },
    };
}

// ---------------------------------------------------------------------------
// getipfslink
// ---------------------------------------------------------------------------
static RPCMethod getipfslink()
{
    return RPCMethod{
        "getipfslink",
        "Retrieve the IPFS link record associated with a transaction ID.",
        {
            {"txid", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The transaction ID to look up."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "txid",        "Transaction ID"},
                {RPCResult::Type::STR, "cid",         "IPFS CID"},
                {RPCResult::Type::STR, "description", "Label"},
                {RPCResult::Type::NUM, "timestamp",   "Unix timestamp of storage"},
            },
        },
        RPCExamples{
            HelpExampleCli("getipfslink", "\"<txid>\"")
            + HelpExampleRpc("getipfslink", "\"<txid>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }

            const uint256 txid = ParseHashV(request.params[0], "txid");
            const auto link = g_ipfslink_db->GetLinkForTx(txid);
            if (!link) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "No IPFS link found for txid " + txid.ToString());
            }
            return LinkToJSON(*link);
        },
    };
}

// ---------------------------------------------------------------------------
// listipfslinks
// ---------------------------------------------------------------------------
static RPCMethod listipfslinks()
{
    return RPCMethod{
        "listipfslinks",
        "List stored IPFS link records, newest first.\n"
        "Supports pagination via limit and offset.",
        {
            {"limit",  RPCArg::Type::NUM, RPCArg::Default{0},
             "Maximum number of records to return (0 = all)."},
            {"offset", RPCArg::Type::NUM, RPCArg::Default{0},
             "Number of records to skip from the newest end."},
        },
        RPCResult{
            RPCResult::Type::ARR, "", "",
            {
                {RPCResult::Type::OBJ, "", "",
                 {
                     {RPCResult::Type::STR, "txid",        "Transaction ID"},
                     {RPCResult::Type::STR, "cid",         "IPFS CID"},
                     {RPCResult::Type::STR, "description", "Label"},
                     {RPCResult::Type::NUM, "timestamp",   "Unix timestamp"},
                 }},
            },
        },
        RPCExamples{
            HelpExampleCli("listipfslinks", "")
            + HelpExampleCli("listipfslinks", "10 0")
            + HelpExampleCli("listipfslinks", "10 20")
            + HelpExampleRpc("listipfslinks", "10, 0")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }

            const size_t limit  = request.params.size() > 0 && !request.params[0].isNull()
                ? static_cast<size_t>(request.params[0].getInt<int>()) : 0;
            const size_t offset = request.params.size() > 1 && !request.params[1].isNull()
                ? static_cast<size_t>(request.params[1].getInt<int>()) : 0;

            UniValue arr(UniValue::VARR);
            for (const auto& link : g_ipfslink_db->ListLinks(limit, offset)) {
                arr.push_back(LinkToJSON(link));
            }
            return arr;
        },
    };
}

// ---------------------------------------------------------------------------
// removeipfslink
// ---------------------------------------------------------------------------
static RPCMethod removeipfslink()
{
    return RPCMethod{
        "removeipfslink",
        "Delete the IPFS link record for a given transaction ID.",
        {
            {"txid", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The transaction ID whose link should be removed."},
        },
        RPCResult{
            RPCResult::Type::BOOL, "", "true if the record was found and deleted"
        },
        RPCExamples{
            HelpExampleCli("removeipfslink", "\"<txid>\"")
            + HelpExampleRpc("removeipfslink", "\"<txid>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }

            const uint256 txid = ParseHashV(request.params[0], "txid");
            const bool removed = g_ipfslink_db->RemoveLinkForTx(txid);
            if (!removed) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "No IPFS link found for txid " + txid.ToString());
            }
            return UniValue{removed};
        },
    };
}

// ---------------------------------------------------------------------------
// getipfsstatus
// ---------------------------------------------------------------------------
static RPCMethod getipfsstatus()
{
    return RPCMethod{
        "getipfsstatus",
        "Return the connection status of the local IPFS daemon.\n"
        "Requires -ipfsapi=<host>:<port> to be configured.",
        {},
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::BOOL, "connected",  "True if the IPFS daemon responded"},
                {RPCResult::Type::STR,  "host",       "IPFS API host"},
                {RPCResult::Type::NUM,  "port",       "IPFS API port"},
                {RPCResult::Type::STR,  "version",    "IPFS daemon version string (if connected)"},
                {RPCResult::Type::STR,  "error",      "Error message (if not connected)"},
            },
        },
        RPCExamples{
            HelpExampleCli("getipfsstatus", "")
            + HelpExampleRpc("getipfsstatus", "")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            UniValue obj(UniValue::VOBJ);
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                obj.pushKV("connected", false);
                obj.pushKV("host",      "");
                obj.pushKV("port",      0);
                obj.pushKV("version",   "");
                obj.pushKV("error",     "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
                return obj;
            }
            obj.pushKV("host", client->GetHost());
            obj.pushKV("port", static_cast<int>(client->GetPort()));
            auto resp = client->Version();
            obj.pushKV("connected", resp.ok);
            obj.pushKV("version",   resp.ok ? resp.body : "");
            obj.pushKV("error",     resp.ok ? "" : resp.error);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// verifyipfscontent
// ---------------------------------------------------------------------------
static RPCMethod verifyipfscontent()
{
    return RPCMethod{
        "verifyipfscontent",
        "Check whether an IPFS CID is available on the network.\n"
        "First checks local availability (fast), then queries the DHT for providers.\n"
        "Requires -ipfsapi to be configured.",
        {
            {"cid", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The IPFS CID to check."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,  "cid",           "The CID that was checked"},
                {RPCResult::Type::BOOL, "local",         "True if the CID is available locally"},
                {RPCResult::Type::BOOL, "network",       "True if at least one provider was found on the network"},
                {RPCResult::Type::STR,  "error",         "Error detail if unavailable"},
            },
        },
        RPCExamples{
            HelpExampleCli("verifyipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleRpc("verifyipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
            }

            const std::string cid = request.params[0].get_str();
            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("cid", cid);

            auto local_resp = client->BlockStat(cid);
            obj.pushKV("local", local_resp.ok);

            auto net_resp = client->FindProviders(cid, 1);
            obj.pushKV("network", net_resp.ok);

            std::string err;
            if (!local_resp.ok) err += "local: " + local_resp.error + "; ";
            if (!net_resp.ok)   err += "network: " + net_resp.error;
            obj.pushKV("error", err);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// pinipfscontent
// ---------------------------------------------------------------------------
static RPCMethod pinipfscontent()
{
    return RPCMethod{
        "pinipfscontent",
        "Pin an IPFS CID on the local IPFS node.\n"
        "Requires -ipfsapi to be configured.",
        {
            {"cid", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The IPFS CID to pin."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,  "cid",    "The CID that was pinned"},
                {RPCResult::Type::BOOL, "pinned", "True if pinning succeeded"},
                {RPCResult::Type::STR,  "error",  "Error detail on failure"},
            },
        },
        RPCExamples{
            HelpExampleCli("pinipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleRpc("pinipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
            }

            const std::string cid = request.params[0].get_str();
            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }

            auto resp = client->Pin(cid);
            UniValue obj(UniValue::VOBJ);
            obj.pushKV("cid",    cid);
            obj.pushKV("pinned", resp.ok);
            obj.pushKV("error",  resp.ok ? "" : resp.error);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// unpinipfscontent
// ---------------------------------------------------------------------------
static RPCMethod unpinipfscontent()
{
    return RPCMethod{
        "unpinipfscontent",
        "Unpin an IPFS CID from the local IPFS node.\n"
        "Requires -ipfsapi to be configured.",
        {
            {"cid", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The IPFS CID to unpin."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,  "cid",      "The CID that was unpinned"},
                {RPCResult::Type::BOOL, "unpinned", "True if unpinning succeeded"},
                {RPCResult::Type::STR,  "error",    "Error detail on failure"},
            },
        },
        RPCExamples{
            HelpExampleCli("unpinipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleRpc("unpinipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
            }

            const std::string cid = request.params[0].get_str();
            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }

            auto resp = client->Unpin(cid);
            UniValue obj(UniValue::VOBJ);
            obj.pushKV("cid",      cid);
            obj.pushKV("unpinned", resp.ok);
            obj.pushKV("error",    resp.ok ? "" : resp.error);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// buildipfscommit
// ---------------------------------------------------------------------------
static RPCMethod buildipfscommit()
{
    return RPCMethod{
        "buildipfscommit",
        "Build the OP_RETURN scriptPubKey for a coinbase IPFS commitment.\n"
        "Returns the hex-encoded script that a miner places in the coinbase output.\n"
        "The anchor txid must refer to a non-coinbase transaction in the same block.\n"
        "That transaction must satisfy the IPFSCommitBurnPerByte anti-spam rule.",
        {
            {"txid", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The anchor transaction ID (must be in the same block as the coinbase)."},
            {"cid",  RPCArg::Type::STR,     RPCArg::Optional::NO,
             "The IPFS CID to commit (CIDv0 or CIDv1 multibase string)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "script_hex",    "Hex-encoded OP_RETURN scriptPubKey"},
                {RPCResult::Type::NUM, "payload_bytes", "Total payload size in bytes (magic+txid+CID)"},
            },
        },
        RPCExamples{
            HelpExampleCli("buildipfscommit",
                "\"<txid>\" \"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleRpc("buildipfscommit",
                "\"<txid>\", \"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            const uint256 txid = ParseHashV(request.params[0], "txid");
            const std::string cid_str = request.params[1].get_str();

            if (!IsValidIPFSCID(cid_str)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }

            auto parsed = cid::ParseString(cid_str);
            if (!parsed) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "CID parse failed.");
            }

            if (parsed->bytes.size() > IPFS_COMMIT_MAX_CID_SIZE) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    strprintf("CID too large: %d bytes (max %d).",
                              parsed->bytes.size(), IPFS_COMMIT_MAX_CID_SIZE));
            }

            const auto script = BuildIPFSCommitScript(txid, parsed->bytes);
            const size_t payload_bytes = 4 + 32 + parsed->bytes.size(); // magic + txid + CID

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("script_hex",    HexStr(script));
            obj.pushKV("payload_bytes", static_cast<int>(payload_bytes));
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------
void RegisterIPFSLinkRPCCommands(CRPCTable& t)
{
    static const CRPCCommand commands[]{
        {"ipfs", &storeipfslink},
        {"ipfs", &getipfslink},
        {"ipfs", &listipfslinks},
        {"ipfs", &removeipfslink},
        {"ipfs", &getipfsstatus},
        {"ipfs", &verifyipfscontent},
        {"ipfs", &pinipfscontent},
        {"ipfs", &unpinipfscontent},
        {"ipfs", &buildipfscommit},
    };
    for (const auto& c : commands) t.appendCommand(c.name, &c);
}
