// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// ============================================================
// Glcoin RPC commands for the Miner Permission Registry
//
// registerminer   <address> <kyc_id> <display_name>
//   Submit a mining application (no authority sig required).
//
// approveminer    <address>
//   Approve a pending miner. Signs internally using the authority key
//   from the loaded wallet (bech32 address supported).
//
// revokeminer     <address> [reason]
//   Permanently revoke a miner. Signs internally via wallet.
//
// suspendminer    <address> <until_timestamp>
//   Temporarily suspend a miner until a given Unix timestamp.
//
// renewminer      <address> <new_expires_at>
//   Update the expiry date for an approved miner (0 = no expiry).
//
// listminers      [status]
//   List miners filtered by status: pending|approved|revoked|suspended|all
//
// getminerinfo    <address>
//   Return the full record for a specific miner address.
//
// getminerregistrystats
//   Return aggregate counts and configuration.
// ============================================================

#include <rpc/minerregistry.h>

#include <chainparams.h>
#include <common/signmessage.h>
#include <consensus/params.h>
#include <interfaces/wallet.h>
#include <kernel/chainparams.h>
#include <key_io.h>
#include <minerregistry.h>
#include <node/context.h>
#include <rpc/server.h>
#include <rpc/server_util.h>
#include <rpc/util.h>
#include <script/script.h>
#include <univalue.h>
#include <util/strencodings.h>
#include <util/time.h>
#include <wallet/coincontrol.h>
#include <wallet/spend.h>
#include <wallet/wallet.h>

#include <memory>
#include <string>

// Global DB instance — initialised by AppInitMain() via InitMinerRegistryDB()
static std::unique_ptr<CMinerRegistryDB> g_miner_registry_db;

void InitMinerRegistryDB(const fs::path& datadir, bool in_memory)
{
    g_miner_registry_db = std::make_unique<CMinerRegistryDB>(
        datadir / "minerregistry", 1 << 20, in_memory);
}

CMinerRegistryDB* GetMinerRegistryDB()
{
    return g_miner_registry_db.get();
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
static std::string StatusString(uint8_t status)
{
    switch (status) {
    case MINER_STATUS_PENDING:   return "pending";
    case MINER_STATUS_APPROVED:  return "approved";
    case MINER_STATUS_REVOKED:   return "revoked";
    case MINER_STATUS_SUSPENDED: return "suspended";
    default:                     return "unknown";
    }
}

static UniValue RecordToJSON(const CMinerRecord& rec, bool include_notes = false)
{
    const int64_t now = GetTime<std::chrono::seconds>().count();
    UniValue obj(UniValue::VOBJ);
    obj.pushKV("address",          rec.address);
    obj.pushKV("kyc_id",           rec.kyc_id);
    obj.pushKV("display_name",     rec.display_name);
    obj.pushKV("status",           StatusString(rec.EffectiveStatus(now)));
    obj.pushKV("registered_at",    rec.registered_at);
    obj.pushKV("approved_at",      rec.approved_at);
    obj.pushKV("expires_at",       rec.expires_at);
    obj.pushKV("suspended_until",  rec.suspended_until);
    if (include_notes) obj.pushKV("notes", rec.notes);
    return obj;
}

// Build an OP_RETURN script with GLCM payload for on-chain registry actions.
static CScript BuildGLCMScript(uint8_t action, const CKeyID& miner_keyid, int64_t extra = 0)
{
    std::vector<uint8_t> payload;
    payload.push_back('G'); payload.push_back('L');
    payload.push_back('C'); payload.push_back('M');
    payload.push_back(action);
    payload.insert(payload.end(), miner_keyid.begin(), miner_keyid.end());
    if (action == GLCM_SUSPEND || action == GLCM_RENEW) {
        for (int b = 0; b < 8; ++b)
            payload.push_back((extra >> (8*b)) & 0xff);
    }
    CScript script;
    script << OP_RETURN << payload;
    return script;
}

// Create and broadcast a GLCM on-chain registry transaction.
// The authority proof is implicit: the tx spends from the authority wallet.
// Returns the txid hex string.
static std::string CreateAndBroadcastGLCMTx(const JSONRPCRequest& request,
                                             uint8_t action,
                                             const std::string& miner_address,
                                             int64_t extra = 0)
{
    // Parse miner address → key ID
    CTxDestination miner_dest = DecodeDestination(miner_address);
    if (!IsValidDestination(miner_dest)) {
        throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY, "Invalid miner address");
    }
    CKeyID miner_keyid;
    if (const PKHash* p = std::get_if<PKHash>(&miner_dest)) {
        miner_keyid = ToKeyID(*p);
    } else if (const WitnessV0KeyHash* w = std::get_if<WitnessV0KeyHash>(&miner_dest)) {
        miner_keyid = ToKeyID(*w);
    } else {
        throw JSONRPCError(RPC_TYPE_ERROR,
            "Miner address must be P2PKH or P2WPKH (bech32)");
    }

    // Build OP_RETURN script
    const CScript glcm_script = BuildGLCMScript(action, miner_keyid, extra);

    // Get wallet context
    const node::NodeContext& node = EnsureAnyNodeContext(request.context);
    if (!node.wallet_loader) {
        throw JSONRPCError(RPC_WALLET_ERROR,
            "No wallet loader — start glcoin-qt with wallet support");
    }
    wallet::WalletContext* wctx = node.wallet_loader->context();
    if (!wctx) {
        throw JSONRPCError(RPC_WALLET_ERROR, "Wallet context not available");
    }

    // Derive authority scriptPubKey (both P2PKH and P2WPKH forms)
    const std::string& auth_addr_str = Params().GetConsensus().minerAuthorityAddress;
    CScript auth_script_pkh, auth_script_wpkh;
    if (!auth_addr_str.empty()) {
        CTxDestination auth_dest = DecodeDestination(auth_addr_str);
        if (const PKHash* p = std::get_if<PKHash>(&auth_dest)) {
            auth_script_pkh  = GetScriptForDestination(*p);
            auth_script_wpkh = GetScriptForDestination(WitnessV0KeyHash(ToKeyID(*p)));
        } else if (const WitnessV0KeyHash* w = std::get_if<WitnessV0KeyHash>(&auth_dest)) {
            auth_script_pkh  = GetScriptForDestination(PKHash(ToKeyID(*w)));
            auth_script_wpkh = GetScriptForDestination(*w);
        }
    }

    for (const auto& pwallet : wallet::GetWallets(*wctx)) {
        if (pwallet->IsLocked()) continue;

        wallet::CRecipient recipient;
        recipient.dest                   = CNoDestination{glcm_script};
        recipient.nAmount                = 0;
        recipient.fSubtractFeeFromAmount = false;

        // Build coin control: select only UTXOs belonging to the authority address
        wallet::CCoinControl coin_control;
        if (!auth_script_pkh.empty() || !auth_script_wpkh.empty()) {
            LOCK(pwallet->cs_wallet);
            bool has_authority_utxo = false;
            for (const auto& [outpoint, wtx] : pwallet->mapWallet) {
                for (unsigned int i = 0; i < wtx.tx->vout.size(); ++i) {
                    const CScript& s = wtx.tx->vout[i].scriptPubKey;
                    if (s == auth_script_pkh || s == auth_script_wpkh) {
                        coin_control.Select(COutPoint(outpoint, i));
                        has_authority_utxo = true;
                    }
                }
            }
            if (!has_authority_utxo) continue; // wallet has no authority UTXOs
        }

        auto res = wallet::CreateTransaction(*pwallet, {recipient},
                                             std::nullopt, coin_control, true);
        if (!res) continue;

        pwallet->CommitTransaction(res->tx, {}, {});
        return res->tx->GetHash().GetHex();
    }

    throw JSONRPCError(RPC_WALLET_ERROR,
        "No unlocked wallet with authority address UTXOs found. "
        "Load the authority wallet (with private key for " + auth_addr_str + ") and ensure it has GLC for fees.");
}

// Sign the authority message internally using the authority key from the loaded wallet.
// Supports both legacy P2PKH and native segwit bech32 (P2WPKH) authority addresses.
// Returns the base64 signature or throws a JSONRPCError.
// ---------------------------------------------------------------------------
// registerminer
// ---------------------------------------------------------------------------
static RPCMethod registerminer()
{
    return RPCMethod{
        "registerminer",
        "Submit a miner registration application.\n"
        "The record is created with status 'pending' and must be approved by the "
        "administrator using approveminer before the address can produce blocks.\n"
        "No authority signature is required — this is the public application step.",
        {
            {"address",      RPCArg::Type::STR, RPCArg::Optional::NO,
             "The Glcoin address that will appear in coinbase outputs."},
            {"kyc_id",       RPCArg::Type::STR, RPCArg::Optional::NO,
             "KYC reference identifier assigned by the administrator (max 64 chars)."},
            {"display_name", RPCArg::Type::STR, RPCArg::Optional::NO,
             "Human-readable name for this miner (max 128 chars)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",       "Miner address"},
                {RPCResult::Type::STR, "kyc_id",        "KYC reference"},
                {RPCResult::Type::STR, "display_name",  "Display name"},
                {RPCResult::Type::STR, "status",        "Always 'pending' on registration"},
                {RPCResult::Type::NUM, "registered_at", "Unix timestamp of registration"},
            },
        },
        RPCExamples{
            HelpExampleCli("registerminer",
                "\"gc1qmineraddress\" "
                "\"KYC-2026-001\" "
                "\"Alice Mining Ltd\"")
            + HelpExampleRpc("registerminer",
                "\"gc1qmineraddress\", "
                "\"KYC-2026-001\", "
                "\"Alice Mining Ltd\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address      = request.params[0].get_str();
            const std::string kyc_id       = request.params[1].get_str();
            const std::string display_name = request.params[2].get_str();

            if (address.empty())
                throw JSONRPCError(RPC_INVALID_PARAMETER, "address must not be empty");
            if (kyc_id.empty() || kyc_id.size() > 64)
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "kyc_id must be 1-64 characters");
            if (display_name.empty() || display_name.size() > 128)
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "display_name must be 1-128 characters");

            if (g_miner_registry_db->GetMiner(address)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Address is already registered");
            }

            CMinerRecord rec;
            rec.address       = address;
            rec.kyc_id        = kyc_id;
            rec.display_name  = display_name;
            rec.status        = MINER_STATUS_PENDING;
            rec.registered_at = GetTime<std::chrono::seconds>().count();

            if (!g_miner_registry_db->StoreMiner(rec)) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Failed to store registration record");
            }
            return RecordToJSON(rec);
        },
    };
}

// ---------------------------------------------------------------------------
// approveminer
// ---------------------------------------------------------------------------
static RPCMethod approveminer()
{
    return RPCMethod{
        "approveminer",
        "Approve a miner by broadcasting a GLCM on-chain transaction.\n"
        "All nodes automatically update their registry when the tx is mined.\n"
        "The authority wallet must be loaded and unlocked (needs GLC for tx fee).",
        {
            {"address", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address to approve."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",        "Miner address"},
                {RPCResult::Type::STR, "status",         "pending_onchain"},
                {RPCResult::Type::STR, "txid",           "Transaction ID of the GLCM approval tx"},
                {RPCResult::Type::STR, "note",           "Registry updates on all nodes when tx is mined"},
            },
        },
        RPCExamples{
            HelpExampleCli("approveminer", "\"gc1qmineraddress\"")
            + HelpExampleRpc("approveminer", "\"gc1qmineraddress\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address = request.params[0].get_str();

            // Broadcast GLCM on-chain transaction — all nodes update registry on block connect
            const std::string txid = CreateAndBroadcastGLCMTx(request, GLCM_APPROVE, address);

            UniValue result(UniValue::VOBJ);
            result.pushKV("address", address);
            result.pushKV("status",  std::string{"pending_onchain"});
            result.pushKV("txid",    txid);
            result.pushKV("note",    "Registry will be updated on all nodes when this tx is mined in a block.");
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// revokeminer
// ---------------------------------------------------------------------------
static RPCMethod revokeminer()
{
    return RPCMethod{
        "revokeminer",
        "Revoke a miner by broadcasting a GLCM on-chain transaction.\n"
        "All nodes reject blocks from this miner once the tx is mined.",
        {
            {"address", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address to revoke."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address", "Miner address"},
                {RPCResult::Type::STR, "status",  "Always 'revoked' on success"},
            },
        },
        RPCExamples{
            HelpExampleCli("revokeminer",
                "\"gc1qmineraddress\" \"Violated terms of service\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address = request.params[0].get_str();

            const std::string txid = CreateAndBroadcastGLCMTx(request, GLCM_REVOKE, address);

            UniValue result(UniValue::VOBJ);
            result.pushKV("address", address);
            result.pushKV("status",  std::string{"pending_onchain"});
            result.pushKV("txid",    txid);
            result.pushKV("note",    "Revocation will take effect on all nodes when this tx is mined.");
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// suspendminer
// ---------------------------------------------------------------------------
static RPCMethod suspendminer()
{
    return RPCMethod{
        "suspendminer",
        "Suspend a miner via GLCM on-chain transaction until a given Unix timestamp.",
        {
            {"address",         RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address to suspend."},
            {"until_timestamp", RPCArg::Type::NUM, RPCArg::Optional::NO,
             "Unix timestamp at which the suspension is automatically lifted."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",         "Miner address"},
                {RPCResult::Type::STR, "status",          "Always 'suspended' on success"},
                {RPCResult::Type::NUM, "suspended_until", "Unix timestamp of auto-reinstatement"},
            },
        },
        RPCExamples{
            HelpExampleCli("suspendminer", "\"gc1qmineraddress\" 1800000000")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address  = request.params[0].get_str();
            const int64_t     until_ts = request.params[1].getInt<int64_t>();

            if (until_ts <= GetTime<std::chrono::seconds>().count()) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "until_timestamp must be in the future");
            }

            const std::string txid = CreateAndBroadcastGLCMTx(request, GLCM_SUSPEND, address, until_ts);

            UniValue result(UniValue::VOBJ);
            result.pushKV("address",         address);
            result.pushKV("status",          std::string{"pending_onchain"});
            result.pushKV("suspended_until", until_ts);
            result.pushKV("txid",            txid);
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// renewminer
// ---------------------------------------------------------------------------
static RPCMethod renewminer()
{
    return RPCMethod{
        "renewminer",
        "Renew a miner's registration via GLCM on-chain transaction.\n"
        "Pass 0 as new_expires_at to remove the expiry (no expiry).",
        {
            {"address",        RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address."},
            {"new_expires_at", RPCArg::Type::NUM, RPCArg::Optional::NO,
             "New expiry as Unix timestamp, or 0 to remove expiry."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",    "Miner address"},
                {RPCResult::Type::NUM, "expires_at", "New expiry timestamp (0 = never)"},
            },
        },
        RPCExamples{
            HelpExampleCli("renewminer", "\"gc1qmineraddress\" 1900000000")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address    = request.params[0].get_str();
            const int64_t     new_expiry = request.params[1].getInt<int64_t>();

            const std::string txid = CreateAndBroadcastGLCMTx(request, GLCM_RENEW, address, new_expiry);

            UniValue result(UniValue::VOBJ);
            result.pushKV("address",    address);
            result.pushKV("expires_at", new_expiry);
            result.pushKV("txid",       txid);
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// listminers
// ---------------------------------------------------------------------------
static RPCMethod listminers()
{
    return RPCMethod{
        "listminers",
        "List all miners in the registry.\n"
        "Optional status filter: pending, approved, revoked, suspended, all (default: all).",
        {
            {"status", RPCArg::Type::STR, RPCArg::Default{std::string{"all"}},
             "Filter by status: pending|approved|revoked|suspended|all"},
        },
        RPCResult{
            RPCResult::Type::ARR, "", "",
            {
                {RPCResult::Type::OBJ, "", "",
                 {
                     {RPCResult::Type::STR, "address",        "Miner address"},
                     {RPCResult::Type::STR, "kyc_id",         "KYC reference"},
                     {RPCResult::Type::STR, "display_name",   "Display name"},
                     {RPCResult::Type::STR, "status",         "Effective status"},
                     {RPCResult::Type::NUM, "registered_at",  "Unix timestamp"},
                     {RPCResult::Type::NUM, "approved_at",    "Unix timestamp (0 if not approved)"},
                     {RPCResult::Type::NUM, "expires_at",     "Unix timestamp (0 = never)"},
                     {RPCResult::Type::NUM, "suspended_until","Unix timestamp (0 if not suspended)"},
                 }},
            },
        },
        RPCExamples{
            HelpExampleCli("listminers", "")
            + HelpExampleCli("listminers", "\"approved\"")
            + HelpExampleRpc("listminers", "\"pending\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string filter_str = request.params.empty()
                ? "all" : request.params[0].get_str();

            int filter = -1;
            if      (filter_str == "pending")   filter = MINER_STATUS_PENDING;
            else if (filter_str == "approved")  filter = MINER_STATUS_APPROVED;
            else if (filter_str == "revoked")   filter = MINER_STATUS_REVOKED;
            else if (filter_str == "suspended") filter = MINER_STATUS_SUSPENDED;
            else if (filter_str != "all") {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "status must be: pending|approved|revoked|suspended|all");
            }

            UniValue arr(UniValue::VARR);
            for (const auto& rec : g_miner_registry_db->ListMiners(filter)) {
                arr.push_back(RecordToJSON(rec, false));
            }
            return arr;
        },
    };
}

// ---------------------------------------------------------------------------
// getminerinfo
// ---------------------------------------------------------------------------
static RPCMethod getminerinfo()
{
    return RPCMethod{
        "getminerinfo",
        "Return the full registry record for a miner address.",
        {
            {"address", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The miner's Glcoin address."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "address",        "Miner address"},
                {RPCResult::Type::STR, "kyc_id",         "KYC reference"},
                {RPCResult::Type::STR, "display_name",   "Display name"},
                {RPCResult::Type::STR, "status",         "Effective status"},
                {RPCResult::Type::NUM, "registered_at",  "Unix timestamp of registration"},
                {RPCResult::Type::NUM, "approved_at",    "Unix timestamp of approval"},
                {RPCResult::Type::NUM, "expires_at",     "Unix timestamp of expiry (0=never)"},
                {RPCResult::Type::NUM, "suspended_until","Unix timestamp of suspension end"},
            },
        },
        RPCExamples{
            HelpExampleCli("getminerinfo", "\"gc1qmineraddress\"")
            + HelpExampleRpc("getminerinfo", "\"gc1qmineraddress\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const std::string address = request.params[0].get_str();
            const auto rec = g_miner_registry_db->GetMiner(address);
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "Address not found in registry: " + address);
            }
            return RecordToJSON(*rec, false);
        },
    };
}

// ---------------------------------------------------------------------------
// getminerregistrystats
// ---------------------------------------------------------------------------
static RPCMethod getminerregistrystats()
{
    return RPCMethod{
        "getminerregistrystats",
        "Return aggregate statistics about the miner registry.",
        {},
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::NUM, "total",               "Total records"},
                {RPCResult::Type::NUM, "approved",            "Approved miners"},
                {RPCResult::Type::NUM, "pending",             "Pending applications"},
                {RPCResult::Type::NUM, "revoked",             "Revoked miners"},
                {RPCResult::Type::NUM, "suspended",           "Suspended miners"},
                {RPCResult::Type::NUM, "enforcement_height",  "Block height enforcement begins"},
                {RPCResult::Type::STR, "authority_address",   "Administrator authority address"},
            },
        },
        RPCExamples{
            HelpExampleCli("getminerregistrystats", "")
            + HelpExampleRpc("getminerregistrystats", "")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_miner_registry_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "Miner registry database not initialised");
            }

            const auto& consensus = Params().GetConsensus();
            const auto all = g_miner_registry_db->ListMiners(-1);
            const int64_t now = GetTime<std::chrono::seconds>().count();

            int n_approved = 0, n_pending = 0, n_revoked = 0, n_suspended = 0;
            for (const auto& rec : all) {
                switch (rec.EffectiveStatus(now)) {
                case MINER_STATUS_APPROVED:  ++n_approved;  break;
                case MINER_STATUS_PENDING:   ++n_pending;   break;
                case MINER_STATUS_REVOKED:   ++n_revoked;   break;
                case MINER_STATUS_SUSPENDED: ++n_suspended; break;
                default: break;
                }
            }

            UniValue result(UniValue::VOBJ);
            result.pushKV("total",              static_cast<int>(all.size()));
            result.pushKV("approved",           n_approved);
            result.pushKV("pending",            n_pending);
            result.pushKV("revoked",            n_revoked);
            result.pushKV("suspended",          n_suspended);
            result.pushKV("enforcement_height", consensus.MinerRegistryHeight);
            result.pushKV("authority_address",  consensus.minerAuthorityAddress.empty()
                                                ? std::string{"(not configured - dev mode)"}
                                                : consensus.minerAuthorityAddress);
            return result;
        },
    };
}

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------
void RegisterMinerRegistryRPCCommands(CRPCTable& t)
{
    static const CRPCCommand commands[]{
        {"mining", &registerminer},
        {"mining", &approveminer},
        {"mining", &revokeminer},
        {"mining", &suspendminer},
        {"mining", &renewminer},
        {"mining", &listminers},
        {"mining", &getminerinfo},
        {"mining", &getminerregistrystats},
    };
    for (const auto& c : commands) t.appendCommand(c.name, &c);
}
