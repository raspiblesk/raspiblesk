// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <crypto/glce.h>

#include <crypto/chacha20poly1305.h>
#include <crypto/common.h>
#include <crypto/hkdf_sha256_32.h>
#include <crypto/sha256.h>
#include <key.h>
#include <pubkey.h>
#include <random.h>
#include <secp256k1.h>
#include <secp256k1_ecdh.h>
#include <span.h>
#include <support/allocators/secure.h>

#include <algorithm>
#include <array>
#include <cassert>
#include <cstring>

namespace glce {

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

static constexpr std::array<uint8_t, 4> MAGIC{0x47, 0x4C, 0x43, 0x45}; // "GLCE"

// ECDH hash function: return the x-coordinate only (32 bytes).
// The raw shared secret is then fed into HKDF, which provides proper key derivation.
static int ecdh_xonly(unsigned char* output, const unsigned char* x32,
                      const unsigned char* /*y32*/, void* /*data*/) noexcept
{
    std::memcpy(output, x32, 32);
    return 1;
}

// Compute secp256k1 ECDH shared secret (x-coordinate of scalar×point).
// Returns false if either key is invalid.
static bool ComputeECDH(const CKey& privkey, const CPubKey& pubkey,
                        std::array<uint8_t, 32>& shared_out) noexcept
{
    secp256k1_pubkey pk;
    if (!secp256k1_ec_pubkey_parse(secp256k1_context_static,
                                   &pk, pubkey.data(), pubkey.size())) {
        return false;
    }
    return secp256k1_ecdh(secp256k1_context_static,
                          shared_out.data(),
                          &pk,
                          UCharCast(privkey.begin()),
                          ecdh_xonly,
                          nullptr) == 1;
}

// SHA256(compressed_pubkey) — used as the blinded recipient identifier.
static std::array<uint8_t, 32> RecipientID(const CPubKey& pubkey)
{
    std::array<uint8_t, 32> id{};
    CSHA256().Write(pubkey.data(), pubkey.size()).Finalize(id.data());
    return id;
}

// Build the HKDF info string for a given (pubE, recipient_id) pair.
// info = pubE_33_bytes || recipient_id_32_bytes
static std::string MakeInfo(const CPubKey& pubE, const std::array<uint8_t, 32>& recip_id)
{
    std::string info;
    info.resize(33 + 32);
    std::memcpy(info.data(), pubE.data(), 33);
    std::memcpy(info.data() + 33, recip_id.data(), 32);
    return info;
}

// Derive wrap_key and wrap_nonce from the ECDH shared secret.
static void DeriveWrapMaterial(const std::array<uint8_t, 32>& shared,
                               const std::string& info,
                               std::array<uint8_t, 32>& wrap_key_out,
                               AEADChaCha20Poly1305::Nonce96& wrap_nonce_out)
{
    CHKDF_HMAC_SHA256_L32(shared.data(), 32, "glcoin-ipfs-wrap-v1")
        .Expand32(info, wrap_key_out.data());

    std::array<uint8_t, 32> nonce_buf{};
    CHKDF_HMAC_SHA256_L32(shared.data(), 32, "glcoin-ipfs-nonce-v1")
        .Expand32(info, nonce_buf.data());
    wrap_nonce_out = {ReadLE32(nonce_buf.data()), ReadLE64(nonce_buf.data() + 4)};
}

// Bytes-to-Nonce96 from a 12-byte buffer.
static AEADChaCha20Poly1305::Nonce96 BytesToNonce96(const uint8_t* buf12) noexcept
{
    return {ReadLE32(buf12), ReadLE64(buf12 + 4)};
}

// ---------------------------------------------------------------------------
// Encrypt
// ---------------------------------------------------------------------------
Result Encrypt(std::span<const std::byte> plaintext,
               const std::vector<CPubKey>& recipient_pubkeys)
{
    if (recipient_pubkeys.empty()) return std::string{"no recipients specified"};
    if (recipient_pubkeys.size() > 255) return std::string{"too many recipients (max 255)"};
    for (const auto& pk : recipient_pubkeys) {
        if (!pk.IsFullyValid()) return std::string{"invalid recipient pubkey"};
    }

    const uint8_t N = static_cast<uint8_t>(recipient_pubkeys.size());

    // --- Ephemeral sender keypair ---
    CKey privE;
    privE.MakeNewKey(/*compressed=*/true);
    CPubKey pubE = privE.GetPubKey();

    // --- Random DEK ---
    std::array<uint8_t, 32> dek{};
    GetStrongRandBytes(dek);

    // --- Random content nonce ---
    std::array<uint8_t, 12> content_nonce_bytes{};
    GetRandBytes(content_nonce_bytes);
    AEADChaCha20Poly1305::Nonce96 content_nonce96 = BytesToNonce96(content_nonce_bytes.data());

    // --- Build envelopes ---
    // Each envelope: 32 (recipient_id) + 12 (wrap_nonce) + 48 (wrapped DEK)
    const size_t blob_size = HEADER_FIXED
                           + ENVELOPE_SIZE * N
                           + PUBE_SIZE
                           + CONTENT_NONCE_SIZE
                           + plaintext.size()
                           + AEAD_TAG_SIZE;

    Blob blob(blob_size);
    uint8_t* p = reinterpret_cast<uint8_t*>(blob.data());

    // Write header
    std::memcpy(p, MAGIC.data(), 4); p += 4;
    *p++ = VERSION;
    *p++ = N;

    // Write envelopes
    for (const CPubKey& recip : recipient_pubkeys) {
        auto recip_id = RecipientID(recip);
        std::string info = MakeInfo(pubE, recip_id);

        std::array<uint8_t, 32> shared{};
        if (!ComputeECDH(privE, recip, shared)) {
            memory_cleanse(dek.data(), dek.size());
            return std::string{"ECDH failed for recipient"};
        }

        std::array<uint8_t, 32> wrap_key{};
        AEADChaCha20Poly1305::Nonce96 wrap_nonce{};
        DeriveWrapMaterial(shared, info, wrap_key, wrap_nonce);
        memory_cleanse(shared.data(), shared.size());

        // Write recipient_id
        std::memcpy(p, recip_id.data(), 32); p += 32;

        // Write wrap_nonce (12 bytes, LE)
        WriteLE32(p,     std::get<0>(wrap_nonce)); p += 4;
        WriteLE64(p + 0, std::get<1>(wrap_nonce)); p += 8;

        // Wrap DEK: AEADChaCha20Poly1305(DEK[32]) → 48 bytes
        {
            auto key_span = std::span<const std::byte>(
                reinterpret_cast<const std::byte*>(wrap_key.data()), 32);
            AEADChaCha20Poly1305 aead(key_span);
            auto dek_span = std::span<const std::byte>(
                reinterpret_cast<const std::byte*>(dek.data()), 32);
            auto out_span = std::span<std::byte>(
                reinterpret_cast<std::byte*>(p), 48);
            aead.Encrypt(dek_span, {}, wrap_nonce, out_span);
            memory_cleanse(wrap_key.data(), wrap_key.size());
        }
        p += 48;
    }

    // Write pubE (33 bytes)
    std::memcpy(p, pubE.data(), 33); p += 33;

    // Write content_nonce (12 bytes, LE)
    WriteLE32(p,     std::get<0>(content_nonce96)); p += 4;
    WriteLE64(p + 0, std::get<1>(content_nonce96)); p += 8;

    // Encrypt content
    {
        auto key_span = std::span<const std::byte>(
            reinterpret_cast<const std::byte*>(dek.data()), 32);
        AEADChaCha20Poly1305 aead(key_span);
        auto out_span = std::span<std::byte>(
            reinterpret_cast<std::byte*>(p), plaintext.size() + AEAD_TAG_SIZE);
        aead.Encrypt(plaintext, {}, content_nonce96, out_span);
        memory_cleanse(dek.data(), dek.size());
    }

    return blob;
}

// ---------------------------------------------------------------------------
// Decrypt
// ---------------------------------------------------------------------------
Result Decrypt(std::span<const std::byte> blob, const CKey& recipient_privkey)
{
    if (!recipient_privkey.IsValid()) return std::string{"invalid private key"};
    if (blob.size() < MIN_BLOB_SIZE)  return std::string{"blob too short"};

    const uint8_t* p = reinterpret_cast<const uint8_t*>(blob.data());
    const uint8_t* const end = p + blob.size();

    // Check magic
    if (std::memcmp(p, MAGIC.data(), 4) != 0) return std::string{"not a GLCE blob"};
    p += 4;
    if (*p++ != VERSION) return std::string{"unsupported GLCE version"};
    const uint8_t N = *p++;

    if (blob.size() < HEADER_FIXED + ENVELOPE_SIZE * N + PUBE_SIZE
                    + CONTENT_NONCE_SIZE + AEAD_TAG_SIZE) {
        return std::string{"blob truncated"};
    }

    // Compute our recipient ID
    CPubKey our_pubkey = recipient_privkey.GetPubKey();
    auto our_id = RecipientID(our_pubkey);

    // Scan envelopes for our ID
    const uint8_t* envelope_start = p;
    std::array<uint8_t, 32> dek{};
    bool found = false;

    // Read pubE first (located right after all envelopes)
    const uint8_t* pube_ptr = envelope_start + ENVELOPE_SIZE * N;
    CPubKey pubE;
    {
        std::vector<uint8_t> pube_bytes(pube_ptr, pube_ptr + 33);
        pubE = CPubKey(pube_bytes);
        if (!pubE.IsFullyValid()) return std::string{"invalid pubE"};
    }

    for (uint8_t i = 0; i < N && !found; ++i) {
        const uint8_t* env = envelope_start + ENVELOPE_SIZE * i;

        if (std::memcmp(env, our_id.data(), 32) != 0) continue;

        // This envelope is ours — derive wrap material
        std::string info = MakeInfo(pubE, our_id);
        std::array<uint8_t, 32> shared{};
        if (!ComputeECDH(recipient_privkey, pubE, shared)) {
            return std::string{"ECDH failed"};
        }

        std::array<uint8_t, 32> wrap_key{};
        AEADChaCha20Poly1305::Nonce96 wrap_nonce{};
        DeriveWrapMaterial(shared, info, wrap_key, wrap_nonce);
        memory_cleanse(shared.data(), shared.size());

        // Reconstruct wrap_nonce from stored bytes (must match what we derived)
        // The stored nonce in the envelope is what we wrote during Encrypt,
        // derived identically — no need to read it back; just verify it matches.
        // (Both sides derive from the same HKDF, so they are identical.)
        const uint8_t* stored_nonce = env + 32;
        AEADChaCha20Poly1305::Nonce96 stored_nonce96 = BytesToNonce96(stored_nonce);
        // Use stored nonce as authoritative (handles future key rotation edge cases)
        (void)wrap_nonce;

        // Unwrap DEK
        {
            auto key_span = std::span<const std::byte>(
                reinterpret_cast<const std::byte*>(wrap_key.data()), 32);
            AEADChaCha20Poly1305 aead(key_span);
            auto wrapped = std::span<const std::byte>(
                reinterpret_cast<const std::byte*>(env + 44), 48);
            auto dek_span = std::span<std::byte>(
                reinterpret_cast<std::byte*>(dek.data()), 32);
            if (!aead.Decrypt(wrapped, {}, stored_nonce96, dek_span)) {
                memory_cleanse(wrap_key.data(), wrap_key.size());
                return std::string{"DEK authentication failed"};
            }
            memory_cleanse(wrap_key.data(), wrap_key.size());
        }
        found = true;
    }

    if (!found) return std::string{"not a recipient of this blob"};

    // Read content nonce
    const uint8_t* cnonce_ptr = pube_ptr + 33;
    AEADChaCha20Poly1305::Nonce96 content_nonce96 = BytesToNonce96(cnonce_ptr);

    // Decrypt content
    const uint8_t* ciphertext_ptr = cnonce_ptr + 12;
    const size_t ciphertext_len = static_cast<size_t>(end - ciphertext_ptr);
    if (ciphertext_len < AEAD_TAG_SIZE) {
        memory_cleanse(dek.data(), dek.size());
        return std::string{"ciphertext too short"};
    }

    Blob plaintext(ciphertext_len - AEAD_TAG_SIZE);
    {
        auto key_span = std::span<const std::byte>(
            reinterpret_cast<const std::byte*>(dek.data()), 32);
        AEADChaCha20Poly1305 aead(key_span);
        auto cipher_span = std::span<const std::byte>(
            reinterpret_cast<const std::byte*>(ciphertext_ptr), ciphertext_len);
        auto plain_span = std::span<std::byte>(plaintext.data(), plaintext.size());
        bool ok = aead.Decrypt(cipher_span, {}, content_nonce96, plain_span);
        memory_cleanse(dek.data(), dek.size());
        if (!ok) return std::string{"content authentication failed"};
    }

    return plaintext;
}

// ---------------------------------------------------------------------------
// IsGLCEBlob
// ---------------------------------------------------------------------------
bool IsGLCEBlob(std::span<const std::byte> data)
{
    if (data.size() < 5) return false;
    const uint8_t* p = reinterpret_cast<const uint8_t*>(data.data());
    return std::memcmp(p, MAGIC.data(), 4) == 0 && p[4] == VERSION;
}

} // namespace glce
