// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// ============================================================
// GLCE — Glcoin Content Encryption
//
// Blob format (version 1):
//   [4]      Magic 0x474C4345 ("GLCE")
//   [1]      Version 0x01
//   [1]      N: recipient count (1..255)
//   [92×N]   Key envelopes (per recipient):
//              [32]  SHA256(compressed_recipient_pubkey)
//              [12]  HKDF-derived wrap nonce
//              [48]  ChaCha20Poly1305(DEK, wrap_key, wrap_nonce)
//   [33]     pubE: compressed ephemeral secp256k1 pubkey
//   [12]     content nonce (random)
//   [var]    ChaCha20Poly1305(content, DEK, content_nonce)
//            — final 16 bytes are the Poly1305 tag
//
// Primitives:
//   ECDH:   secp256k1_ecdh, x-coordinate only → HKDF input
//   KDF:    HKDF-SHA256 (RFC 5869), 32-byte output
//   AEAD:   ChaCha20Poly1305 (AEADChaCha20Poly1305)
//   ID:     SHA256(recipient_compressed_pubkey) — blinded
// ============================================================

#pragma once

#include <key.h>
#include <pubkey.h>
#include <span.h>

#include <cstdint>
#include <string>
#include <variant>
#include <vector>

namespace glce {

static constexpr uint8_t VERSION{1};
static constexpr size_t MAGIC_SIZE{4};
static constexpr size_t ENVELOPE_SIZE{92};  // 32+12+48
static constexpr size_t HEADER_FIXED{6};    // magic(4)+version(1)+N(1)
static constexpr size_t PUBE_SIZE{33};
static constexpr size_t CONTENT_NONCE_SIZE{12};
static constexpr size_t AEAD_TAG_SIZE{16};

// Minimum blob size: 1 recipient, 0-byte plaintext
static constexpr size_t MIN_BLOB_SIZE =
    HEADER_FIXED + ENVELOPE_SIZE + PUBE_SIZE + CONTENT_NONCE_SIZE + AEAD_TAG_SIZE;

using Blob   = std::vector<std::byte>;
using Result = std::variant<Blob, std::string>;  // ok=Blob, err=string

// ---------------------------------------------------------------------------
// Encrypt plaintext for one or more recipients.
//
// recipient_pubkeys: compressed 33-byte secp256k1 pubkeys.
// Returns encrypted blob on success, error string on failure.
// ---------------------------------------------------------------------------
Result Encrypt(std::span<const std::byte> plaintext,
               const std::vector<CPubKey>& recipient_pubkeys);

// ---------------------------------------------------------------------------
// Decrypt a GLCE blob using the given private key.
//
// The private key must correspond to one of the recipient pubkeys the blob
// was encrypted for (identified by SHA256 of its compressed form).
// Returns decrypted plaintext on success, error string on failure.
// ---------------------------------------------------------------------------
Result Decrypt(std::span<const std::byte> blob,
               const CKey& recipient_privkey);

// ---------------------------------------------------------------------------
// IsGLCEBlob — quick magic/version check (does not validate the full blob).
// ---------------------------------------------------------------------------
bool IsGLCEBlob(std::span<const std::byte> data);

} // namespace glce
