// Copyright (c) 2009-2010 Satoshi Nakamoto
// Copyright (c) 2009-present The Glcoin Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef BITCOIN_CONSENSUS_PARAMS_H
#define BITCOIN_CONSENSUS_PARAMS_H

#include <consensus/amount.h>
#include <script/verify_flags.h>
#include <uint256.h>

#include <array>
#include <chrono>
#include <limits>
#include <map>
#include <vector>

namespace Consensus {

/**
 * A buried deployment is one where the height of the activation has been hardcoded into
 * the client implementation long after the consensus change has activated. See BIP 90.
 * Consensus changes for which the new rules are enforced from genesis are not listed here.
 */
enum BuriedDeployment : int16_t {
    // buried deployments get negative values to avoid overlap with DeploymentPos
    DEPLOYMENT_HEIGHTINCB = std::numeric_limits<int16_t>::min(),
    DEPLOYMENT_CLTV,
    DEPLOYMENT_DERSIG,
    DEPLOYMENT_CSV,
    // SCRIPT_VERIFY_WITNESS is enforced from genesis, but the check for downloading
    // missing witness data is not. BIP 147 also relies on hardcoded activation height.
    DEPLOYMENT_SEGWIT,
    // BIP 340/341/342 — taproot. SCRIPT_VERIFY_TAPROOT is enforced from genesis
    // on Glcoin (see validation.cpp). This entry exposes the activation height
    // to RPC consumers so that getblockchaininfo / getdeploymentinfo emit a
    // softforks["taproot"] record — required for backends such as LND, which
    // refuses to start if the node reports no taproot support.
    DEPLOYMENT_TAPROOT,
};
constexpr bool ValidDeployment(BuriedDeployment dep) { return dep <= DEPLOYMENT_TAPROOT; }

enum DeploymentPos : uint16_t {
    DEPLOYMENT_TESTDUMMY,
    // NOTE: Also add new deployments to VersionBitsDeploymentInfo in deploymentinfo.cpp
    // Removing an entry may require bumping MinBIP9WarningHeight.
    MAX_VERSION_BITS_DEPLOYMENTS
};
constexpr bool ValidDeployment(DeploymentPos dep) { return dep < MAX_VERSION_BITS_DEPLOYMENTS; }

/**
 * Struct for each individual consensus rule change using BIP9.
 */
struct BIP9Deployment {
    /** Bit position to select the particular bit in nVersion. */
    int bit{28};
    /** Start MedianTime for version bits miner confirmation. Can be a date in the past */
    int64_t nStartTime{NEVER_ACTIVE};
    /** Timeout/expiry MedianTime for the deployment attempt. */
    int64_t nTimeout{NEVER_ACTIVE};
    /** If lock in occurs, delay activation until at least this block
     *  height.  Note that activation will only occur on a retarget
     *  boundary.
     */
    int min_activation_height{0};
    /** Period of blocks to check signalling in (usually retarget period, ie params.DifficultyAdjustmentInterval()) */
    uint32_t period{2016};
    /**
     * Minimum blocks including miner confirmation of the total of 2016 blocks in a retargeting period,
     * which is also used for BIP9 deployments.
     * Examples: 1916 for 95%, 1512 for testchains.
     */
    uint32_t threshold{1916};

    /** Constant for nTimeout very far in the future. */
    static constexpr int64_t NO_TIMEOUT = std::numeric_limits<int64_t>::max();

    /** Special value for nStartTime indicating that the deployment is always active.
     *  This is useful for testing, as it means tests don't need to deal with the activation
     *  process (which takes at least 3 BIP9 intervals). Only tests that specifically test the
     *  behaviour during activation cannot use this. */
    static constexpr int64_t ALWAYS_ACTIVE = -1;

    /** Special value for nStartTime indicating that the deployment is never active.
     *  This is useful for integrating the code changes for a new feature
     *  prior to deploying it on some or all networks. */
    static constexpr int64_t NEVER_ACTIVE = -2;
};

/**
 * Parameters that influence chain consensus.
 */
struct Params {
    uint256 hashGenesisBlock;
    int nSubsidyHalvingInterval;
    /**
     * Hashes of blocks that
     * - are known to be consensus valid, and
     * - buried in the chain, and
     * - fail if the default script verify flags are applied.
     */
    std::map<uint256, script_verify_flags> script_flag_exceptions;
    /** Block height and hash at which BIP34 becomes active */
    int BIP34Height;
    uint256 BIP34Hash;
    /** Block height at which BIP65 becomes active */
    int BIP65Height;
    /** Block height at which BIP66 becomes active */
    int BIP66Height;
    /** Block height at which CSV (BIP68, BIP112 and BIP113) becomes active */
    int CSVHeight;
    /** Block height at which Segwit (BIP141, BIP143 and BIP147) becomes active.
     * Note that segwit v0 script rules are enforced on all blocks except the
     * BIP 16 exception blocks. */
    int SegwitHeight;
    /** Block height at which Taproot (BIP 340/341/342) is recognised as active.
     * Glcoin enforces SCRIPT_VERIFY_TAPROOT from genesis (validation.cpp); this
     * field is the metadata that RPC consumers read to confirm taproot support
     * — notably LND's chainreg/taproot_check.go probe. */
    int TaprootHeight;
    /** Don't warn about unknown BIP 9 activations below this height.
     * This prevents us from warning about the CSV, segwit and taproot activations. */
    int MinBIP9WarningHeight;
    std::array<BIP9Deployment,MAX_VERSION_BITS_DEPLOYMENTS> vDeployments;
    /** Proof of work parameters */
    uint256 powLimit;
    bool fPowAllowMinDifficultyBlocks;
    /**
      * Enforce BIP94 timewarp attack mitigation. On testnet4 this also enforces
      * the block storm mitigation.
      */
    bool enforce_BIP94;
    bool fPowNoRetargeting;
    int64_t nPowTargetSpacing;
    int64_t nPowTargetTimespan;
    std::chrono::seconds PowTargetSpacing() const
    {
        return std::chrono::seconds{nPowTargetSpacing};
    }
    int64_t DifficultyAdjustmentInterval() const { return nPowTargetTimespan / nPowTargetSpacing; }
    /** The best chain should have at least this much work */
    uint256 nMinimumChainWork;
    /** By default assume that the signatures in ancestors of this block are valid */
    uint256 defaultAssumeValid;

    /**
     * If true, witness commitments contain a payload equal to a Glcoin Script solution
     * to the signet challenge. See BIP325.
     */
    bool signet_blocks{false};
    std::vector<uint8_t> signet_challenge;

    /**
     * Glcoin IPFS Consensus Commitment
     *
     * Block height at which IPFS coinbase commitment rules are enforced.
     * Below this height a malformed glc1 OP_RETURN is silently ignored.
     * Default: max int (disabled until explicitly configured).
     */
    int IPFSCommitHeight{std::numeric_limits<int>::max()};

    /**
     * Satoshis per CID byte that the anchor transaction must burn via
     * OP_RETURN outputs.  0 disables the burn requirement (regtest default).
     * Applies to glc1 commitments before IPFSEncryptedHeight.
     */
    CAmount IPFSCommitBurnPerByte{0};

    /**
     * Block height at which encrypted (glc2) IPFS commitments become the
     * only valid form. Pre-activation only glc1 (plaintext) is accepted as
     * a commitment; post-activation glc1 is treated as ordinary OP_RETURN
     * data and only glc2 (pad_id + ciphertext) is a consensus commitment.
     * Default: max int (disabled until explicitly configured).
     */
    int IPFSEncryptedHeight{std::numeric_limits<int>::max()};

    /**
     * Satoshis per encrypted-CID byte that the anchor transaction must
     * pay as miner fee for a glc2 commitment. The fee = Σ(vin) − Σ(vout)
     * is collected by the miner via the coinbase reward (no burn).
     * 0 disables the fee requirement (regtest default).
     */
    CAmount IPFSCommitFeePerByte{0};

    /**
     * Glcoin Miner Permission System
     *
     * Glcoin address whose private key the administrator uses to sign
     * approveminer / revokeminer operations.  Empty string disables
     * authority-signature verification (dev / regtest only).
     */
    std::string minerAuthorityAddress;

    /**
     * Block height at which miner-registry enforcement begins.
     * Blocks below this height are never checked against the registry.
     * Default: max int (disabled until explicitly configured).
     */
    int MinerRegistryHeight{std::numeric_limits<int>::max()};

    /**
     * GLCMv2: hard-fork activation height for the security-fix consensus
     * change introduced in v0149 of the chain. Below this height the
     * legacy ProcessGLCMTx logic runs (wall-clock timestamps + hard-coded
     * authority address from this struct). At and above this height the
     * v2 logic runs:
     *   - timestamps in stored CMinerRecord come from the deterministic
     *     block time, not GetTime() (fixes a non-determinism bug that
     *     could cause inter-node disagreement on registry contents)
     *   - the GLCM_ROTATE action takes effect; the active authority is
     *     looked up from the on-chain registry instead of being pinned
     *     to minerAuthorityAddress.
     * minerAuthorityAddress remains the bootstrap value used when no
     * GLCM_ROTATE has yet been applied.
     * Default: max int (legacy behaviour kept until explicitly set).
     */
    int GLCMv2Height{std::numeric_limits<int>::max()};

    int DeploymentHeight(BuriedDeployment dep) const
    {
        switch (dep) {
        case DEPLOYMENT_HEIGHTINCB:
            return BIP34Height;
        case DEPLOYMENT_CLTV:
            return BIP65Height;
        case DEPLOYMENT_DERSIG:
            return BIP66Height;
        case DEPLOYMENT_CSV:
            return CSVHeight;
        case DEPLOYMENT_SEGWIT:
            return SegwitHeight;
        case DEPLOYMENT_TAPROOT:
            return TaprootHeight;
        } // no default case, so the compiler can warn about missing cases
        return std::numeric_limits<int>::max();
    }
};

} // namespace Consensus

#endif // BITCOIN_CONSENSUS_PARAMS_H
