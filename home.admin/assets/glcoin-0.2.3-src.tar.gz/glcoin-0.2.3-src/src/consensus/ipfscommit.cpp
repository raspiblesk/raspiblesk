// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <consensus/ipfscommit.h>

#include <coins.h>
#include <consensus/amount.h>
#include <consensus/params.h>
#include <script/script.h>
#include <uint256.h>
#include <util/cid.h>

#include <algorithm>
#include <cstring>

// ---------------------------------------------------------------------------
// ParseCIDBytes
//
// Public API maintained for ipfscommit_tests.cpp and any future caller that
// needs an IPFSCommitment from raw bytes.  Delegates validation entirely to
// the shared cid::ParseBytes so the two IPFS subsystems can never diverge.
// ---------------------------------------------------------------------------
std::optional<IPFSCommitment> ParseCIDBytes(const std::vector<uint8_t>& cid)
{
    auto parsed = cid::ParseBytes(cid);
    if (!parsed) return std::nullopt;

    IPFSCommitment c{};
    c.cid_bytes = cid;
    c.version   = parsed->version;
    c.codec     = parsed->codec;
    c.hash_fn   = parsed->hash_fn;
    c.hash_len  = parsed->hash_len;
    // txid_anchor is left as zero — callers that need it populate it themselves
    return c;
}

// ---------------------------------------------------------------------------
// Script helpers
// ---------------------------------------------------------------------------
static std::vector<uint8_t> EncodeMinimalPush(const std::vector<uint8_t>& data)
{
    std::vector<uint8_t> out;
    const size_t n = data.size();
    if (n < OP_PUSHDATA1) {
        out.push_back(static_cast<uint8_t>(n));
    } else if (n <= 0xFF) {
        out.push_back(OP_PUSHDATA1);
        out.push_back(static_cast<uint8_t>(n));
    } else if (n <= 0xFFFF) {
        out.push_back(OP_PUSHDATA2);
        out.push_back(static_cast<uint8_t>(n & 0xFF));
        out.push_back(static_cast<uint8_t>((n >> 8) & 0xFF));
    } else {
        out.push_back(OP_PUSHDATA4);
        for (int i = 0; i < 4; ++i)
            out.push_back(static_cast<uint8_t>((n >> (8 * i)) & 0xFF));
    }
    out.insert(out.end(), data.begin(), data.end());
    return out;
}

std::vector<uint8_t> BuildIPFSCommitScript(const uint256& txid_anchor,
                                           const std::vector<uint8_t>& cid_bytes)
{
    std::vector<uint8_t> payload;
    payload.reserve(4 + 32 + cid_bytes.size());
    payload.insert(payload.end(), std::begin(IPFS_COMMIT_MAGIC), std::end(IPFS_COMMIT_MAGIC));
    payload.insert(payload.end(), txid_anchor.begin(), txid_anchor.end());
    payload.insert(payload.end(), cid_bytes.begin(), cid_bytes.end());

    std::vector<uint8_t> spk;
    spk.push_back(OP_RETURN);
    const auto pushed = EncodeMinimalPush(payload);
    spk.insert(spk.end(), pushed.begin(), pushed.end());
    return spk;
}

std::vector<uint8_t> BuildIPFSEncryptedCommitScript(
    const uint256& txid_anchor,
    const std::array<uint8_t, IPFS_COMMIT_PAD_ID_LEN>& pad_id,
    const std::vector<uint8_t>& encrypted_cid)
{
    std::vector<uint8_t> payload;
    payload.reserve(4 + 32 + IPFS_COMMIT_PAD_ID_LEN + encrypted_cid.size());
    payload.insert(payload.end(),
                   std::begin(IPFS_COMMIT_MAGIC_V2), std::end(IPFS_COMMIT_MAGIC_V2));
    payload.insert(payload.end(), txid_anchor.begin(), txid_anchor.end());
    payload.insert(payload.end(), pad_id.begin(), pad_id.end());
    payload.insert(payload.end(), encrypted_cid.begin(), encrypted_cid.end());

    std::vector<uint8_t> spk;
    spk.push_back(OP_RETURN);
    const auto pushed = EncodeMinimalPush(payload);
    spk.insert(spk.end(), pushed.begin(), pushed.end());
    return spk;
}

std::vector<uint8_t> BuildIPFSPerTxCommitScript(
    uint8_t flags,
    const std::array<uint8_t, IPFS_COMMIT_PAD_ID_LEN>& pad_id,
    const std::vector<uint8_t>& encrypted_cid)
{
    std::vector<uint8_t> payload;
    payload.reserve(IPFS_COMMIT_V3_HEADER_SIZE + encrypted_cid.size());
    payload.insert(payload.end(),
                   std::begin(IPFS_COMMIT_MAGIC_V3), std::end(IPFS_COMMIT_MAGIC_V3));
    payload.push_back(flags);
    payload.insert(payload.end(), pad_id.begin(), pad_id.end());
    payload.insert(payload.end(), encrypted_cid.begin(), encrypted_cid.end());

    std::vector<uint8_t> spk;
    spk.push_back(OP_RETURN);
    const auto pushed = EncodeMinimalPush(payload);
    spk.insert(spk.end(), pushed.begin(), pushed.end());
    return spk;
}

// ---------------------------------------------------------------------------
// Extract a commitment payload from a single OP_RETURN output
// ---------------------------------------------------------------------------
static std::optional<std::vector<uint8_t>> ReadOpReturnPayload(const CScript& script)
{
    if (script.size() < 2 || script[0] != OP_RETURN) return std::nullopt;

    CScript::const_iterator it = script.begin() + 1;
    std::vector<uint8_t> data;
    opcodetype op{};
    if (!script.GetOp(it, op, data)) return std::nullopt;
    if (it != script.end()) return std::nullopt; // trailing bytes — not a pure push
    return data;
}

std::optional<IPFSCommitment> ExtractCoinbaseIPFSCommitment(const CTransaction& coinbase,
                                                            std::string& parse_error)
{
    parse_error.clear();
    std::optional<IPFSCommitment> found;
    int found_count = 0;

    for (const CTxOut& out : coinbase.vout) {
        const auto payload = ReadOpReturnPayload(out.scriptPubKey);
        if (!payload) continue;
        if (payload->size() < 4) continue;
        if (!std::equal(std::begin(IPFS_COMMIT_MAGIC), std::end(IPFS_COMMIT_MAGIC),
                        payload->begin())) {
            continue;
        }

        ++found_count;

        if (payload->size() > IPFS_COMMIT_MAX_PAYLOAD) {
            parse_error = "ipfs-commit-too-large";
            return std::nullopt;
        }
        if (payload->size() < IPFS_COMMIT_MIN_PAYLOAD) {
            parse_error = "ipfs-commit-too-small";
            return std::nullopt;
        }

        uint256 anchor{};
        std::memcpy(anchor.begin(), payload->data() + 4, 32);
        std::vector<uint8_t> cid_bytes(payload->begin() + 4 + 32, payload->end());

        auto parsed = ParseCIDBytes(cid_bytes);
        if (!parsed) {
            parse_error = "ipfs-commit-bad-cid";
            return std::nullopt;
        }
        parsed->txid_anchor = anchor;
        found = std::move(parsed);
        // Keep scanning to detect duplicate commitments
    }

    if (found_count > 1) {
        parse_error = "ipfs-commit-duplicate";
        return std::nullopt;
    }
    return found;
}

std::optional<IPFSPerTxCommitment>
ExtractTxIPFSPerTxCommitment(const CTransaction& tx,
                             std::string& parse_error)
{
    parse_error.clear();
    std::optional<IPFSPerTxCommitment> found;
    int found_count = 0;

    for (const CTxOut& out : tx.vout) {
        const auto payload = ReadOpReturnPayload(out.scriptPubKey);
        if (!payload) continue;
        if (payload->size() < 4) continue;
        if (!std::equal(std::begin(IPFS_COMMIT_MAGIC_V3), std::end(IPFS_COMMIT_MAGIC_V3),
                        payload->begin())) {
            continue;
        }

        ++found_count;

        if (payload->size() > IPFS_COMMIT_MAX_PAYLOAD) {
            parse_error = "ipfs-commit-too-large";
            return std::nullopt;
        }
        if (payload->size() < IPFS_COMMIT_V3_MIN_PAYLOAD) {
            parse_error = "ipfs-commit-too-small";
            return std::nullopt;
        }

        const uint8_t flags = (*payload)[4];
        if ((flags & IPFS_FLAG_ENCRYPTED) == 0) {
            parse_error = "ipfs-commit-not-encrypted";
            return std::nullopt;
        }
        if ((flags & IPFS_FLAG_RESERVED) != 0) {
            parse_error = "ipfs-commit-reserved-flag";
            return std::nullopt;
        }

        const size_t cid_size =
            payload->size() - IPFS_COMMIT_V3_HEADER_SIZE;
        if (cid_size < IPFS_COMMIT_V3_MIN_CID_SIZE ||
            cid_size > IPFS_COMMIT_V3_HARD_CID_CAP) {
            parse_error = "ipfs-commit-bad-cid-size";
            return std::nullopt;
        }

        IPFSPerTxCommitment c{};
        c.flags = flags;
        std::memcpy(c.pad_id.data(), payload->data() + 5, IPFS_COMMIT_PAD_ID_LEN);
        c.encrypted_cid.assign(
            payload->begin() + IPFS_COMMIT_V3_HEADER_SIZE,
            payload->end());

        found = std::move(c);
    }

    if (found_count > 1) {
        parse_error = "ipfs-commit-duplicate-pertx";
        return std::nullopt;
    }
    return found;
}

std::optional<IPFSEncryptedCommitment>
ExtractCoinbaseIPFSEncryptedCommitment(const CTransaction& coinbase,
                                       std::string& parse_error)
{
    parse_error.clear();
    std::optional<IPFSEncryptedCommitment> found;
    int found_count = 0;

    for (const CTxOut& out : coinbase.vout) {
        const auto payload = ReadOpReturnPayload(out.scriptPubKey);
        if (!payload) continue;
        if (payload->size() < 4) continue;
        if (!std::equal(std::begin(IPFS_COMMIT_MAGIC_V2), std::end(IPFS_COMMIT_MAGIC_V2),
                        payload->begin())) {
            continue;
        }

        ++found_count;

        if (payload->size() > IPFS_COMMIT_MAX_PAYLOAD) {
            parse_error = "ipfs-commit-too-large";
            return std::nullopt;
        }
        if (payload->size() < IPFS_COMMIT_V2_MIN_PAYLOAD) {
            parse_error = "ipfs-commit-too-small";
            return std::nullopt;
        }

        const size_t cid_size = payload->size() - 4 - 32 - IPFS_COMMIT_PAD_ID_LEN;
        if (cid_size < IPFS_COMMIT_V2_MIN_CID_SIZE ||
            cid_size > IPFS_COMMIT_V2_MAX_CID_SIZE) {
            parse_error = "ipfs-commit-bad-cid-size";
            return std::nullopt;
        }

        IPFSEncryptedCommitment c{};
        std::memcpy(c.txid_anchor.begin(), payload->data() + 4, 32);
        std::memcpy(c.pad_id.data(), payload->data() + 4 + 32, IPFS_COMMIT_PAD_ID_LEN);
        c.encrypted_cid.assign(
            payload->begin() + 4 + 32 + IPFS_COMMIT_PAD_ID_LEN,
            payload->end());

        found = std::move(c);
        // Keep scanning to detect duplicate commitments
    }

    if (found_count > 1) {
        parse_error = "ipfs-commit-duplicate";
        return std::nullopt;
    }
    return found;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

namespace {

// Find a non-coinbase transaction in the block by txid. Returns nullptr if not present.
const CTransaction* FindAnchorTx(const CBlock& block, const uint256& txid)
{
    for (size_t i = 1; i < block.vtx.size(); ++i) {
        if (block.vtx[i]->GetHash().ToUint256() == txid) return block.vtx[i].get();
    }
    return nullptr;
}

// True if the coinbase contains any glc1 OP_RETURN at all (regardless of validity).
bool CoinbaseHasGlc1Marker(const CTransaction& cb)
{
    for (const CTxOut& out : cb.vout) {
        const auto payload = ReadOpReturnPayload(out.scriptPubKey);
        if (!payload || payload->size() < 4) continue;
        if (std::equal(std::begin(IPFS_COMMIT_MAGIC), std::end(IPFS_COMMIT_MAGIC),
                       payload->begin())) {
            return true;
        }
    }
    return false;
}

} // namespace

// ---------------------------------------------------------------------------
// Structural gate (no UTXO view)
// ---------------------------------------------------------------------------
bool CheckBlockIPFSCommitment(const CBlock& block,
                              int nHeight,
                              const Consensus::Params& params,
                              std::string& reason)
{
    reason.clear();
    if (block.vtx.empty()) {
        reason = "bad-block-empty";
        return false;
    }

    const CTransaction& cb = *block.vtx[0];
    const bool encrypted_active = nHeight >= params.IPFSEncryptedHeight;

    // -----------------------------------------------------------------------
    // glc2 (coinbase encrypted) path
    // -----------------------------------------------------------------------
    std::string err_v2;
    auto commit_v2 = ExtractCoinbaseIPFSEncryptedCommitment(cb, err_v2);
    if (encrypted_active) {
        // Post-activation, glc1 OP_RETURNs are NOT consensus commitments;
        // they are tolerated as ordinary data so historic-style scripts do
        // not break, but they may not coexist with a glc2 commitment.
        if (commit_v2 && CoinbaseHasGlc1Marker(cb)) {
            reason = "ipfs-commit-mixed-variants";
            return false;
        }
        if (!commit_v2 && !err_v2.empty()) {
            reason = err_v2;
            return false;
        }
        if (commit_v2 && !FindAnchorTx(block, commit_v2->txid_anchor)) {
            reason = "ipfs-commit-anchor-missing";
            return false;
        }

        // -------------------------------------------------------------------
        // glc3 (per-tx encrypted) path — structurally validate every regular
        // transaction. Each tx may carry at most one glc3 OP_RETURN.
        // -------------------------------------------------------------------
        for (size_t i = 1; i < block.vtx.size(); ++i) {
            std::string err_v3;
            auto commit_v3 = ExtractTxIPFSPerTxCommitment(*block.vtx[i], err_v3);
            if (!commit_v3 && !err_v3.empty()) {
                reason = err_v3;
                return false;
            }
        }
        return true;
    }

    // -----------------------------------------------------------------------
    // Pre-activation: glc1 path. glc2 / glc3 may not appear yet.
    // -----------------------------------------------------------------------
    if (commit_v2) {
        reason = "ipfs-commit-v2-premature";
        return false;
    }
    if (!err_v2.empty()) {
        // Pre-activation we still reject a malformed glc2 payload so it cannot
        // creep in undetected before its rules are in effect.
        reason = err_v2;
        return false;
    }
    for (size_t i = 1; i < block.vtx.size(); ++i) {
        std::string err_v3;
        auto commit_v3 = ExtractTxIPFSPerTxCommitment(*block.vtx[i], err_v3);
        if (commit_v3) {
            reason = "ipfs-commit-v3-premature";
            return false;
        }
        if (!err_v3.empty()) {
            reason = err_v3;
            return false;
        }
    }

    std::string extract_err;
    auto commit = ExtractCoinbaseIPFSCommitment(cb, extract_err);
    if (!commit) {
        if (extract_err.empty()) return true; // no commitment
        if (nHeight < params.IPFSCommitHeight) return true;
        reason = extract_err;
        return false;
    }
    if (!FindAnchorTx(block, commit->txid_anchor)) {
        reason = "ipfs-commit-anchor-missing";
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------
// Economic gate (needs UTXO view for input values)
// ---------------------------------------------------------------------------
bool CheckBlockIPFSCommitmentEconomic(const CBlock& block,
                                      int nHeight,
                                      const Consensus::Params& params,
                                      const CCoinsViewCache& view,
                                      std::string& reason)
{
    reason.clear();
    if (block.vtx.empty()) return true; // structural gate already handled
    const CTransaction& cb = *block.vtx[0];

    const bool encrypted_active = nHeight >= params.IPFSEncryptedHeight;

    // Helper: compute miner fee of a tx using the view (input - output sums).
    auto compute_fee = [&](const CTransaction& tx, CAmount& fee_out) -> bool {
        CAmount value_in = 0;
        for (const CTxIn& in : tx.vin) {
            const Coin& coin = view.AccessCoin(in.prevout);
            if (coin.IsSpent()) return false;
            value_in += coin.out.nValue;
        }
        CAmount value_out = 0;
        for (const CTxOut& out : tx.vout) value_out += out.nValue;
        fee_out = value_in - value_out;
        return true;
    };

    if (encrypted_active) {
        // glc2 (coinbase) fee check
        std::string err;
        auto commit_v2 = ExtractCoinbaseIPFSEncryptedCommitment(cb, err);
        if (commit_v2) {
            const CTransaction* anchor_tx = FindAnchorTx(block, commit_v2->txid_anchor);
            if (!anchor_tx) {
                reason = "ipfs-commit-anchor-missing";
                return false;
            }
            if (params.IPFSCommitFeePerByte > 0) {
                CAmount fee = 0;
                if (!compute_fee(*anchor_tx, fee)) {
                    reason = "ipfs-commit-anchor-input-missing";
                    return false;
                }
                const CAmount required =
                    static_cast<CAmount>(commit_v2->encrypted_cid.size()) *
                    params.IPFSCommitFeePerByte;
                if (fee < required) {
                    reason = "ipfs-commit-anchor-underpaid";
                    return false;
                }
            }
        }

        // glc3 (per-tx) fee check — each tx that carries a glc3 OP_RETURN
        // must pay fee ≥ ciphertext.size × IPFSCommitFeePerByte itself.
        if (params.IPFSCommitFeePerByte > 0) {
            for (size_t i = 1; i < block.vtx.size(); ++i) {
                std::string err_v3;
                auto commit_v3 = ExtractTxIPFSPerTxCommitment(*block.vtx[i], err_v3);
                if (!commit_v3) continue;

                CAmount fee = 0;
                if (!compute_fee(*block.vtx[i], fee)) {
                    reason = "ipfs-commit-pertx-input-missing";
                    return false;
                }
                const CAmount required =
                    static_cast<CAmount>(commit_v3->encrypted_cid.size()) *
                    params.IPFSCommitFeePerByte;
                if (fee < required) {
                    reason = "ipfs-commit-pertx-underpaid";
                    return false;
                }
            }
        }
        return true;
    }

    // Pre-activation: legacy burn rule on glc1 commitments.
    std::string err;
    auto commit = ExtractCoinbaseIPFSCommitment(cb, err);
    if (!commit) return true;
    if (nHeight < params.IPFSCommitHeight) return true;
    if (params.IPFSCommitBurnPerByte <= 0) return true;

    const CTransaction* anchor_tx = FindAnchorTx(block, commit->txid_anchor);
    if (!anchor_tx) {
        reason = "ipfs-commit-anchor-missing";
        return false;
    }
    CAmount burned = 0;
    for (const CTxOut& out : anchor_tx->vout) {
        if (out.scriptPubKey.IsUnspendable()) burned += out.nValue;
    }
    const CAmount required =
        static_cast<CAmount>(commit->cid_bytes.size()) * params.IPFSCommitBurnPerByte;
    if (burned < required) {
        reason = "ipfs-commit-anchor-underpaid";
        return false;
    }
    return true;
}
