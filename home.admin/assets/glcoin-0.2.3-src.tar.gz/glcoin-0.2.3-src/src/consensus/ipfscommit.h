// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// ============================================================
// Glcoin — Consensus-level IPFS commitment
//
// An optional, per-block coinbase commitment that anchors one
// transaction in the block to a binary-encoded IPFS CID.
//
// Two payload formats exist:
//
//   "glc1" (legacy, plaintext CID) — accepted at any height,
//   enforced from params.IPFSCommitHeight until
//   params.IPFSEncryptedHeight. Post IPFSEncryptedHeight a glc1
//   OP_RETURN is treated as ordinary data, not a commitment.
//
//      +---------+---------------+----------------------+
//      | "glc1"  | txid_anchor   | cid_bytes            |
//      | 4 bytes | 32 bytes      | 34..44 bytes         |
//      +---------+---------------+----------------------+
//
//   "glc2" (encrypted coinbase) — accepted from
//   params.IPFSEncryptedHeight onwards. cid_bytes are the OTP-XOR
//   ciphertext of a real CID; pad_id = SHA256(pad)[:8] is a public
//   lookup tag the recipient uses to find the matching pad in their
//   local pad store.
//
//      +---------+---------------+----------+----------+
//      | "glc2"  | txid_anchor   | pad_id   | encr_cid |
//      | 4 bytes | 32 bytes      | 8 bytes  | 34..36 b |
//      +---------+---------------+----------+----------+
//
//   "glc3" (encrypted per-transaction) — accepted from
//   params.IPFSEncryptedHeight onwards. Embedded in an OP_RETURN
//   output of any regular (non-coinbase) transaction. That same
//   transaction IS the anchor — there is no txid_anchor field.
//   A flag byte signals semantics; bit 1 (ENCRYPTED) MUST be set
//   and the remaining bits are reserved (must be 0).
//
//      +---------+--------+----------+--------------+
//      | "glc3"  | flags  | pad_id   | encrypted_cid|
//      | 4 bytes | 1 byte | 8 bytes  | 34..44 bytes |
//      +---------+--------+----------+--------------+
//
// In glc1/glc2 forms the anchor transaction must be a non-coinbase
// tx in the same block. In glc3 the carrying transaction is itself
// the anchor — at most one glc3 OP_RETURN is allowed per tx.
//
// Anti-spam rule:
//   • Pre-IPFSEncryptedHeight (legacy glc1):  anchor tx must burn
//     cid.size × IPFSCommitBurnPerByte via OP_RETURN outputs.
//   • Post-IPFSEncryptedHeight (glc2 and glc3): anchor / carrying
//     tx must pay a transaction fee ≥ encrypted_cid.size ×
//     IPFSCommitFeePerByte. The fee flows to the miner via the
//     normal coinbase reward — no burn.
// ============================================================

#ifndef GLCOIN_CONSENSUS_IPFSCOMMIT_H
#define GLCOIN_CONSENSUS_IPFSCOMMIT_H

#include <consensus/amount.h>
#include <primitives/block.h>
#include <primitives/transaction.h>
#include <uint256.h>

#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace Consensus { struct Params; }

/** 4-byte magic that marks a coinbase OP_RETURN as a plaintext IPFS commitment. */
inline constexpr unsigned char IPFS_COMMIT_MAGIC[4]     = {'g', 'l', 'c', '1'};

/** 4-byte magic that marks a coinbase OP_RETURN as an OTP-encrypted commitment. */
inline constexpr unsigned char IPFS_COMMIT_MAGIC_V2[4]  = {'g', 'l', 'c', '2'};

/** 4-byte magic that marks a regular-transaction OP_RETURN as an OTP-encrypted
 *  per-tx commitment. The carrying transaction is the anchor. */
inline constexpr unsigned char IPFS_COMMIT_MAGIC_V3[4]  = {'g', 'l', 'c', '3'};

/** Flag bits for the glc3 flag byte. */
static constexpr uint8_t IPFS_FLAG_PINNED    = 0x01;
static constexpr uint8_t IPFS_FLAG_ENCRYPTED = 0x02; // MUST be set in glc3
static constexpr uint8_t IPFS_FLAG_DIRECTORY = 0x04;
static constexpr uint8_t IPFS_FLAG_UPDATE    = 0x08;
static constexpr uint8_t IPFS_FLAG_RESERVED  = 0xF0; // bits 4..7 must be 0

/** OP_RETURN standardness cap: magic(4) + txid(32) + CID(≤44). */
static constexpr size_t IPFS_COMMIT_MAX_PAYLOAD       = 80;
static constexpr size_t IPFS_COMMIT_MIN_PAYLOAD       = 4 + 32 + 34;   // magic + txid + CIDv0
static constexpr size_t IPFS_COMMIT_MAX_CID_SIZE      = IPFS_COMMIT_MAX_PAYLOAD - 4 - 32;

/** Encrypted-commitment layout caps. */
static constexpr size_t IPFS_COMMIT_PAD_ID_LEN        = 8;
static constexpr size_t IPFS_COMMIT_V2_MIN_PAYLOAD    = 4 + 32 + IPFS_COMMIT_PAD_ID_LEN + 34;
static constexpr size_t IPFS_COMMIT_V2_MAX_CID_SIZE   =
    IPFS_COMMIT_MAX_PAYLOAD - 4 - 32 - IPFS_COMMIT_PAD_ID_LEN; // = 36
static constexpr size_t IPFS_COMMIT_V2_MIN_CID_SIZE   = 34;

/** glc3 (per-tx) layout: magic + flags + pad_id + encrypted_cid. */
static constexpr size_t IPFS_COMMIT_V3_HEADER_SIZE    = 4 + 1 + IPFS_COMMIT_PAD_ID_LEN; // = 13
static constexpr size_t IPFS_COMMIT_V3_MIN_PAYLOAD    = IPFS_COMMIT_V3_HEADER_SIZE + 34;
static constexpr size_t IPFS_COMMIT_V3_MAX_CID_SIZE   =
    IPFS_COMMIT_MAX_PAYLOAD - IPFS_COMMIT_V3_HEADER_SIZE; // = 67 — enough for any CID we accept
static constexpr size_t IPFS_COMMIT_V3_MIN_CID_SIZE   = 34;
/** We additionally cap to 44 bytes to match the off-chain CID parser's max. */
static constexpr size_t IPFS_COMMIT_V3_HARD_CID_CAP   = 44;

/** A parsed plaintext (glc1) commitment payload. */
struct IPFSCommitment {
    uint256               txid_anchor;
    std::vector<uint8_t>  cid_bytes;   // raw multihash/CID bytes (no multibase)
    unsigned int          version;     // 0 = CIDv0, 1 = CIDv1
    uint64_t              codec;       // multicodec (CIDv0 ⇒ dag-pb = 0x70)
    uint64_t              hash_fn;     // multihash function code
    unsigned int          hash_len;    // multihash digest length
};

/** A parsed encrypted (glc2) coinbase commitment payload.
 *
 *  encrypted_cid bytes are the OTP-XOR ciphertext of a real CID — their
 *  inner structure cannot be validated without the pad. Only the length
 *  range is checked here. */
struct IPFSEncryptedCommitment {
    uint256                                    txid_anchor;
    std::array<uint8_t, IPFS_COMMIT_PAD_ID_LEN> pad_id;
    std::vector<uint8_t>                       encrypted_cid;
};

/** A parsed per-tx encrypted (glc3) commitment payload.
 *
 *  The carrying transaction is the anchor — there is no txid_anchor here.
 *  flags MUST have IPFS_FLAG_ENCRYPTED set; reserved bits must be 0. */
struct IPFSPerTxCommitment {
    uint8_t                                    flags;
    std::array<uint8_t, IPFS_COMMIT_PAD_ID_LEN> pad_id;
    std::vector<uint8_t>                       encrypted_cid;
};

/** Parse a raw CID byte string (no multibase prefix).  Returns an
 *  IPFSCommitment whose txid_anchor field is left at the caller's
 *  default — only the CID-related fields are populated here. */
std::optional<IPFSCommitment> ParseCIDBytes(const std::vector<uint8_t>& cid);

/** Serialise the OP_RETURN scriptPubKey for a plaintext (glc1) commitment. */
std::vector<uint8_t> BuildIPFSCommitScript(const uint256& txid_anchor,
                                           const std::vector<uint8_t>& cid_bytes);

/** Serialise the OP_RETURN scriptPubKey for an encrypted (glc2) commitment. */
std::vector<uint8_t> BuildIPFSEncryptedCommitScript(
    const uint256& txid_anchor,
    const std::array<uint8_t, IPFS_COMMIT_PAD_ID_LEN>& pad_id,
    const std::vector<uint8_t>& encrypted_cid);

/** Extract a plaintext commitment from a coinbase transaction.
 *  Returns nullopt if no glc1-prefixed OP_RETURN is present.
 *  Sets parse_error if a glc1 payload was present but malformed. */
std::optional<IPFSCommitment> ExtractCoinbaseIPFSCommitment(const CTransaction& coinbase,
                                                            std::string& parse_error);

/** Extract an encrypted commitment from a coinbase transaction.
 *  Returns nullopt if no glc2-prefixed OP_RETURN is present.
 *  Sets parse_error if a glc2 payload was present but malformed. */
std::optional<IPFSEncryptedCommitment>
ExtractCoinbaseIPFSEncryptedCommitment(const CTransaction& coinbase,
                                       std::string& parse_error);

/** Serialise the OP_RETURN scriptPubKey for a per-tx (glc3) commitment. */
std::vector<uint8_t> BuildIPFSPerTxCommitScript(
    uint8_t flags,
    const std::array<uint8_t, IPFS_COMMIT_PAD_ID_LEN>& pad_id,
    const std::vector<uint8_t>& encrypted_cid);

/** Extract the (at most one) glc3 commitment from a regular transaction.
 *  Returns nullopt if no glc3 OP_RETURN is present.
 *  Sets parse_error if a glc3 payload was present but malformed, including
 *  the case of multiple glc3 OP_RETURNs in the same tx (which is invalid). */
std::optional<IPFSPerTxCommitment>
ExtractTxIPFSPerTxCommitment(const CTransaction& tx,
                             std::string& parse_error);

/** Structural consensus gate (no UTXO view needed) used by
 *  ContextualCheckBlock. Validates:
 *    - At most one IPFS commitment per block (glc1 OR glc2)
 *    - Payload size and format are valid for the active variant at nHeight
 *    - txid_anchor references a non-coinbase tx in this same block
 *
 *  The economic rule (burn / fee) is enforced separately by
 *  CheckBlockIPFSCommitmentEconomic once a UTXO view is available. */
bool CheckBlockIPFSCommitment(const CBlock& block,
                              int nHeight,
                              const Consensus::Params& params,
                              std::string& reason);

class CCoinsViewCache;

/** Economic consensus gate used by Chainstate::ConnectBlock once
 *  the input values of the anchor transaction are spendable from the
 *  view. Verifies the appropriate anti-spam rule:
 *
 *    - Pre-IPFSEncryptedHeight  (glc1):
 *        anchor_tx.OP_RETURN_value  ≥  cid.size × IPFSCommitBurnPerByte
 *    - Post-IPFSEncryptedHeight (glc2):
 *        anchor_tx.fee  ≥  cid.size × IPFSCommitFeePerByte
 *
 *  The fee for glc2 is naturally re-allocated to the miner via the
 *  block's coinbase reward (Bitcoin's normal fee mechanism). */
bool CheckBlockIPFSCommitmentEconomic(const CBlock& block,
                                      int nHeight,
                                      const Consensus::Params& params,
                                      const CCoinsViewCache& view,
                                      std::string& reason);

#endif // GLCOIN_CONSENSUS_IPFSCOMMIT_H
