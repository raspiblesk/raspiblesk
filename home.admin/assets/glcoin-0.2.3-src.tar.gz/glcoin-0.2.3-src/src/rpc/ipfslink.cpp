// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// ============================================================
// Glcoin RPC commands for IPFS link storage
//
// storeipfslink  <txid> <cid> [description]
//   Store an IPFS CID anchored to a transaction ID.
//   Returns the stored record as JSON.
//
// getipfslink  <txid>
//   Retrieve the IPFS link record for a given txid.
//
// listipfslinks
//   List all stored IPFS link records, newest first.
//
// removeipfslink  <txid>
//   Delete the IPFS link record for a given txid.
// ============================================================

#include <rpc/ipfslink.h>

#include <consensus/ipfscommit.h>
#include <hash.h>
#include <ipfsclient.h>
#include <ipfslink.h>
#include <ipfspadstore.h>
#include <ipfspin.h>
#include <ipfspintracker.h>
#include <streams.h>
#include <util/cid.h>
#include <util/otp.h>
#include <node/context.h>
#include <rpc/server.h>
#include <rpc/server_util.h>
#include <rpc/util.h>
#include <univalue.h>
#include <util/strencodings.h>

#include <memory>
#include <set>
#include <stdexcept>

// Global DB instance — initialised by AppInitMain() via InitIPFSLinkDB()
static std::unique_ptr<CIPFSLinkDB> g_ipfslink_db;

void InitIPFSLinkDB(const fs::path& datadir, bool in_memory)
{
    g_ipfslink_db = std::make_unique<CIPFSLinkDB>(
        datadir / "ipfslinks", 1 << 20, in_memory);
}

CIPFSLinkDB* GetIPFSLinkDB()
{
    return g_ipfslink_db.get();
}

// ---------------------------------------------------------------------------
// Helper — serialise a CIPFSLink to UniValue JSON
// ---------------------------------------------------------------------------
static UniValue LinkToJSON(const CIPFSLink& link)
{
    UniValue obj(UniValue::VOBJ);
    obj.pushKV("txid",        link.txid.ToString());
    obj.pushKV("cid",         link.cid);
    obj.pushKV("description", link.description);
    obj.pushKV("timestamp",   link.timestamp);
    return obj;
}

// ---------------------------------------------------------------------------
// storeipfslink
// ---------------------------------------------------------------------------
static RPCMethod storeipfslink()
{
    return RPCMethod{
        "storeipfslink",
        "Store an IPFS Content Identifier (CID) anchored to a Glcoin transaction.\n"
        "The record is kept in a local LevelDB database and is NOT broadcast to peers.",
        {
            {"txid",        RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The transaction ID to anchor the IPFS link to."},
            {"cid",         RPCArg::Type::STR,     RPCArg::Optional::NO,
             "IPFS Content Identifier (CIDv0 starting with Qm, or CIDv1 starting with bafy/b)."},
            {"description", RPCArg::Type::STR,     RPCArg::Default{std::string{}},
             "Optional human-readable label (max 256 characters)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,     "txid",        "Transaction ID"},
                {RPCResult::Type::STR,     "cid",         "IPFS CID"},
                {RPCResult::Type::STR,     "description", "Label"},
                {RPCResult::Type::NUM,     "timestamp",   "Unix timestamp of storage"},
            },
        },
        RPCExamples{
            HelpExampleCli("storeipfslink",
                "\"<txid>\" "
                "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\" "
                "\"My document\"")
            + HelpExampleRpc("storeipfslink",
                "\"<txid>\", "
                "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\", "
                "\"My document\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }

            const uint256 txid = ParseHashV(request.params[0], "txid");
            const std::string cid = request.params[1].get_str();
            const std::string desc = request.params.size() > 2
                ? request.params[2].get_str() : "";

            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Invalid IPFS CID. Must be a well-formed CIDv0 (Qm…, 46 base58btc chars) "
                    "or CIDv1 (multibase-prefixed: b/B=base32, z=base58btc, f=base16) "
                    "with a recognised codec and multihash function.");
            }
            if (!IsValidIPFSDescription(desc)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Invalid description: must be valid UTF-8, max 256 bytes, "
                    "no control characters (tab allowed).");
            }

            if (!g_ipfslink_db->StoreLinkForTx(txid, cid, desc)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Failed to store link — record may already exist for this txid.");
            }

            const auto stored = g_ipfslink_db->GetLinkForTx(txid);
            if (!stored) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "Store succeeded but read-back failed.");
            }
            return LinkToJSON(*stored);
        },
    };
}

// ---------------------------------------------------------------------------
// getipfslink
// ---------------------------------------------------------------------------
static RPCMethod getipfslink()
{
    return RPCMethod{
        "getipfslink",
        "Retrieve the IPFS link record associated with a transaction ID.",
        {
            {"txid", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The transaction ID to look up."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "txid",        "Transaction ID"},
                {RPCResult::Type::STR, "cid",         "IPFS CID"},
                {RPCResult::Type::STR, "description", "Label"},
                {RPCResult::Type::NUM, "timestamp",   "Unix timestamp of storage"},
            },
        },
        RPCExamples{
            HelpExampleCli("getipfslink", "\"<txid>\"")
            + HelpExampleRpc("getipfslink", "\"<txid>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }

            const uint256 txid = ParseHashV(request.params[0], "txid");
            const auto link = g_ipfslink_db->GetLinkForTx(txid);
            if (!link) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "No IPFS link found for txid " + txid.ToString());
            }
            return LinkToJSON(*link);
        },
    };
}

// ---------------------------------------------------------------------------
// listipfslinks
// ---------------------------------------------------------------------------
static RPCMethod listipfslinks()
{
    return RPCMethod{
        "listipfslinks",
        "List stored IPFS link records, newest first.\n"
        "Supports pagination via limit and offset.",
        {
            {"limit",  RPCArg::Type::NUM, RPCArg::Default{0},
             "Maximum number of records to return (0 = all)."},
            {"offset", RPCArg::Type::NUM, RPCArg::Default{0},
             "Number of records to skip from the newest end."},
        },
        RPCResult{
            RPCResult::Type::ARR, "", "",
            {
                {RPCResult::Type::OBJ, "", "",
                 {
                     {RPCResult::Type::STR, "txid",        "Transaction ID"},
                     {RPCResult::Type::STR, "cid",         "IPFS CID"},
                     {RPCResult::Type::STR, "description", "Label"},
                     {RPCResult::Type::NUM, "timestamp",   "Unix timestamp"},
                 }},
            },
        },
        RPCExamples{
            HelpExampleCli("listipfslinks", "")
            + HelpExampleCli("listipfslinks", "10 0")
            + HelpExampleCli("listipfslinks", "10 20")
            + HelpExampleRpc("listipfslinks", "10, 0")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }

            const size_t limit  = request.params.size() > 0 && !request.params[0].isNull()
                ? static_cast<size_t>(request.params[0].getInt<int>()) : 0;
            const size_t offset = request.params.size() > 1 && !request.params[1].isNull()
                ? static_cast<size_t>(request.params[1].getInt<int>()) : 0;

            UniValue arr(UniValue::VARR);
            for (const auto& link : g_ipfslink_db->ListLinks(limit, offset)) {
                arr.push_back(LinkToJSON(link));
            }
            return arr;
        },
    };
}

// ---------------------------------------------------------------------------
// removeipfslink
// ---------------------------------------------------------------------------
static RPCMethod removeipfslink()
{
    return RPCMethod{
        "removeipfslink",
        "Delete the IPFS link record for a given transaction ID.",
        {
            {"txid", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The transaction ID whose link should be removed."},
        },
        RPCResult{
            RPCResult::Type::BOOL, "", "true if the record was found and deleted"
        },
        RPCExamples{
            HelpExampleCli("removeipfslink", "\"<txid>\"")
            + HelpExampleRpc("removeipfslink", "\"<txid>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }

            const uint256 txid = ParseHashV(request.params[0], "txid");
            const bool removed = g_ipfslink_db->RemoveLinkForTx(txid);
            if (!removed) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "No IPFS link found for txid " + txid.ToString());
            }
            return UniValue{removed};
        },
    };
}

// ---------------------------------------------------------------------------
// getipfsstatus
// ---------------------------------------------------------------------------
static RPCMethod getipfsstatus()
{
    return RPCMethod{
        "getipfsstatus",
        "Return the connection status of the local IPFS daemon.\n"
        "Requires -ipfsapi=<host>:<port> to be configured.",
        {},
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::BOOL, "connected",  "True if the IPFS daemon responded"},
                {RPCResult::Type::STR,  "host",       "IPFS API host"},
                {RPCResult::Type::NUM,  "port",       "IPFS API port"},
                {RPCResult::Type::STR,  "version",    "IPFS daemon version string (if connected)"},
                {RPCResult::Type::STR,  "error",      "Error message (if not connected)"},
            },
        },
        RPCExamples{
            HelpExampleCli("getipfsstatus", "")
            + HelpExampleRpc("getipfsstatus", "")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            UniValue obj(UniValue::VOBJ);
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                obj.pushKV("connected", false);
                obj.pushKV("host",      "");
                obj.pushKV("port",      0);
                obj.pushKV("version",   "");
                obj.pushKV("error",     "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
                return obj;
            }
            obj.pushKV("host", client->GetHost());
            obj.pushKV("port", static_cast<int>(client->GetPort()));
            auto resp = client->Version();
            obj.pushKV("connected", resp.ok);
            obj.pushKV("version",   resp.ok ? resp.body : "");
            obj.pushKV("error",     resp.ok ? "" : resp.error);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// verifyipfscontent
// ---------------------------------------------------------------------------
static RPCMethod verifyipfscontent()
{
    return RPCMethod{
        "verifyipfscontent",
        "Check whether an IPFS CID is available on the network.\n"
        "First checks local availability (fast), then queries the DHT for providers.\n"
        "Requires -ipfsapi to be configured.",
        {
            {"cid", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The IPFS CID to check."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,  "cid",           "The CID that was checked"},
                {RPCResult::Type::BOOL, "local",         "True if the CID is available locally"},
                {RPCResult::Type::BOOL, "network",       "True if at least one provider was found on the network"},
                {RPCResult::Type::STR,  "error",         "Error detail if unavailable"},
            },
        },
        RPCExamples{
            HelpExampleCli("verifyipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleRpc("verifyipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
            }

            const std::string cid = request.params[0].get_str();
            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("cid", cid);

            auto local_resp = client->BlockStat(cid);
            obj.pushKV("local", local_resp.ok);

            auto net_resp = client->FindProviders(cid, 1);
            obj.pushKV("network", net_resp.ok);

            std::string err;
            if (!local_resp.ok) err += "local: " + local_resp.error + "; ";
            if (!net_resp.ok)   err += "network: " + net_resp.error;
            obj.pushKV("error", err);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// pinipfscontent
// ---------------------------------------------------------------------------
static RPCMethod pinipfscontent()
{
    return RPCMethod{
        "pinipfscontent",
        "Pin an IPFS CID on the local IPFS node.\n"
        "Requires -ipfsapi to be configured.",
        {
            {"cid", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The IPFS CID to pin."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,  "cid",    "The CID that was pinned"},
                {RPCResult::Type::BOOL, "pinned", "True if pinning succeeded"},
                {RPCResult::Type::STR,  "error",  "Error detail on failure"},
            },
        },
        RPCExamples{
            HelpExampleCli("pinipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleRpc("pinipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
            }

            const std::string cid = request.params[0].get_str();
            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }

            auto resp = client->Pin(cid);
            UniValue obj(UniValue::VOBJ);
            obj.pushKV("cid",    cid);
            obj.pushKV("pinned", resp.ok);
            obj.pushKV("error",  resp.ok ? "" : resp.error);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// unpinipfscontent
// ---------------------------------------------------------------------------
static RPCMethod unpinipfscontent()
{
    return RPCMethod{
        "unpinipfscontent",
        "Unpin an IPFS CID from the local IPFS node.\n"
        "Requires -ipfsapi to be configured.",
        {
            {"cid", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The IPFS CID to unpin."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,  "cid",      "The CID that was unpinned"},
                {RPCResult::Type::BOOL, "unpinned", "True if unpinning succeeded"},
                {RPCResult::Type::STR,  "error",    "Error detail on failure"},
            },
        },
        RPCExamples{
            HelpExampleCli("unpinipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleRpc("unpinipfscontent", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
            }

            const std::string cid = request.params[0].get_str();
            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }

            auto resp = client->Unpin(cid);
            UniValue obj(UniValue::VOBJ);
            obj.pushKV("cid",      cid);
            obj.pushKV("unpinned", resp.ok);
            obj.pushKV("error",    resp.ok ? "" : resp.error);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// listipfspins
// ---------------------------------------------------------------------------
static RPCMethod listipfspins()
{
    return RPCMethod{
        "listipfspins",
        "List CIDs currently pinned on the local IPFS node.\n"
        "Requires -ipfsapi to be configured.",
        {
            {"type", RPCArg::Type::STR, RPCArg::Default{"recursive"},
             "Pin type filter: all, direct, indirect, recursive."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::BOOL, "ok",    "True if the IPFS daemon responded"},
                {RPCResult::Type::NUM,  "count", "Number of pins returned"},
                {RPCResult::Type::ARR,  "pins",  "",
                 {
                     {RPCResult::Type::OBJ, "", "",
                      {
                          {RPCResult::Type::STR, "cid",  "CID of the pinned object"},
                          {RPCResult::Type::STR, "type", "Pin type (recursive / direct / indirect)"},
                      }},
                 }},
                {RPCResult::Type::STR,  "error", "Error detail on failure"},
            },
        },
        RPCExamples{
            HelpExampleCli("listipfspins", "")
            + HelpExampleCli("listipfspins", "all")
            + HelpExampleRpc("listipfspins", "\"recursive\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
            }
            const std::string type = request.params.size() > 0 && !request.params[0].isNull()
                ? request.params[0].get_str() : "recursive";

            auto resp = client->PinLs(type);
            UniValue out(UniValue::VOBJ);
            out.pushKV("ok", resp.ok);
            UniValue pins(UniValue::VARR);

            if (resp.ok) {
                UniValue body;
                if (body.read(resp.body) && body.isObject() && body.exists("Keys")) {
                    const UniValue& keys = body["Keys"];
                    if (keys.isObject()) {
                        const auto& ks = keys.getKeys();
                        const auto& vs = keys.getValues();
                        for (size_t i = 0; i < ks.size(); ++i) {
                            UniValue entry(UniValue::VOBJ);
                            entry.pushKV("cid", ks[i]);
                            const std::string pin_type = vs[i].isObject() && vs[i].exists("Type")
                                ? vs[i]["Type"].get_str() : "";
                            entry.pushKV("type", pin_type);
                            pins.push_back(entry);
                        }
                    }
                } else {
                    out.pushKV("error", "could not parse pin/ls JSON");
                }
            } else {
                out.pushKV("error", resp.error);
            }

            out.pushKV("count", static_cast<int>(pins.size()));
            out.pushKV("pins", pins);
            if (!out.exists("error")) out.pushKV("error", "");
            return out;
        },
    };
}

// ---------------------------------------------------------------------------
// ipfsfindproviders
// ---------------------------------------------------------------------------
static RPCMethod ipfsfindproviders()
{
    return RPCMethod{
        "ipfsfindproviders",
        "Query the IPFS DHT for peers that provide a given CID.\n"
        "Slow — may take several seconds. Requires -ipfsapi.",
        {
            {"cid", RPCArg::Type::STR, RPCArg::Optional::NO,
             "The IPFS CID to look up."},
            {"num_providers", RPCArg::Type::NUM, RPCArg::Default{5},
             "Maximum number of providers to wait for (kubo may return fewer)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::BOOL, "ok",    "True if the DHT query completed"},
                {RPCResult::Type::STR,  "cid",   "The CID that was queried"},
                {RPCResult::Type::NUM,  "count", "Number of distinct provider peer IDs returned"},
                {RPCResult::Type::ARR,  "providers", "",
                 {
                     {RPCResult::Type::STR, "", "libp2p peer ID of a provider"},
                 }},
                {RPCResult::Type::STR,  "error", "Error detail on failure"},
            },
        },
        RPCExamples{
            HelpExampleCli("ipfsfindproviders", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleCli("ipfsfindproviders", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\" 10")
            + HelpExampleRpc("ipfsfindproviders", "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\", 10")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            IPFSClient* client = GetIPFSClient();
            if (!client) {
                throw JSONRPCError(RPC_INTERNAL_ERROR,
                    "IPFS client not configured. Use -ipfsapi=<host>:<port>.");
            }
            const std::string cid = request.params[0].get_str();
            if (!IsValidIPFSCID(cid)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }
            const int num = request.params.size() > 1 && !request.params[1].isNull()
                ? request.params[1].getInt<int>() : 5;

            auto resp = client->FindProviders(cid, num);
            UniValue out(UniValue::VOBJ);
            out.pushKV("ok",  resp.ok);
            out.pushKV("cid", cid);

            // kubo streams newline-delimited JSON: one envelope per progress
            // event. Provider IDs live in Responses[*].ID. Deduplicate.
            std::set<std::string> ids;
            if (resp.ok) {
                size_t pos = 0;
                while (pos < resp.body.size()) {
                    size_t nl = resp.body.find('\n', pos);
                    std::string line = resp.body.substr(
                        pos, nl == std::string::npos ? std::string::npos : nl - pos);
                    pos = (nl == std::string::npos) ? resp.body.size() : nl + 1;
                    if (line.empty()) continue;
                    UniValue env;
                    if (!env.read(line) || !env.isObject()) continue;
                    if (!env.exists("Responses") || !env["Responses"].isArray()) continue;
                    for (size_t i = 0; i < env["Responses"].size(); ++i) {
                        const UniValue& r = env["Responses"][i];
                        if (r.isObject() && r.exists("ID") && r["ID"].isStr()) {
                            const std::string peer = r["ID"].get_str();
                            if (!peer.empty()) ids.insert(peer);
                        }
                    }
                }
            } else {
                out.pushKV("error", resp.error);
            }

            UniValue arr(UniValue::VARR);
            for (const auto& p : ids) arr.push_back(p);
            out.pushKV("count",     static_cast<int>(arr.size()));
            out.pushKV("providers", arr);
            if (!out.exists("error")) out.pushKV("error", "");
            return out;
        },
    };
}

// ===========================================================================
// OTP-encrypted IPFS link RPCs
// ===========================================================================

namespace {

constexpr std::array<uint8_t, 7> kPadBlobMagic{'G','L','C','P','A','D','1'};

UniValue EncryptedLinkToJSON(const CIPFSEncryptedLink& rec,
                             const std::optional<std::string>& decrypted_cid)
{
    UniValue obj(UniValue::VOBJ);
    obj.pushKV("txid",          rec.txid.ToString());
    obj.pushKV("pad_id",        otp::PadIDToHex(rec.pad_id));
    obj.pushKV("encrypted_cid", HexStr(rec.encrypted_cid));
    obj.pushKV("description",   rec.description);
    obj.pushKV("timestamp",     rec.timestamp);
    if (decrypted_cid) {
        obj.pushKV("cid", *decrypted_cid);
        obj.pushKV("decrypted", true);
    } else {
        obj.pushKV("decrypted", false);
    }
    return obj;
}

std::string EncodePadBlob(const CIPFSPad& rec)
{
    DataStream ds;
    ds << kPadBlobMagic
       << rec.pad_id
       << rec.pad
       << rec.txid
       << rec.encrypted_cid
       << rec.description
       << rec.timestamp;
    const uint256 checksum = Hash(MakeUCharSpan(ds));
    DataStream out;
    out << kPadBlobMagic
        << rec.pad_id
        << rec.pad
        << rec.txid
        << rec.encrypted_cid
        << rec.description
        << rec.timestamp
        << checksum;
    return HexStr(MakeUCharSpan(out));
}

std::optional<CIPFSPad> DecodePadBlob(const std::string& hex)
{
    auto bytes = TryParseHex<uint8_t>(hex);
    if (!bytes) return std::nullopt;
    DataStream ds{*bytes};

    try {
        std::array<uint8_t, 7> magic{};
        ds >> magic;
        if (magic != kPadBlobMagic) return std::nullopt;

        CIPFSPad rec;
        ds >> rec.pad_id >> rec.pad >> rec.txid
           >> rec.encrypted_cid >> rec.description >> rec.timestamp;

        uint256 checksum;
        ds >> checksum;

        // Recompute and verify checksum over everything before it.
        DataStream verify;
        verify << kPadBlobMagic
               << rec.pad_id
               << rec.pad
               << rec.txid
               << rec.encrypted_cid
               << rec.description
               << rec.timestamp;
        if (Hash(MakeUCharSpan(verify)) != checksum) return std::nullopt;

        // Consistency: pad_id must match SHA256(pad)[:8].
        if (otp::ComputePadID(std::span<const uint8_t>{rec.pad}) != rec.pad_id) {
            return std::nullopt;
        }
        return rec;
    } catch (const std::exception&) {
        return std::nullopt;
    }
}

} // namespace

// ---------------------------------------------------------------------------
// storeipfslinkencrypted
// ---------------------------------------------------------------------------
static RPCMethod storeipfslinkencrypted()
{
    return RPCMethod{
        "storeipfslinkencrypted",
        "Encrypt an IPFS CID with a fresh One-Time Pad and store the\n"
        "encrypted record locally. The pad is written to the protected\n"
        "<datadir>/ipfs_pads.dat store. Only nodes possessing the pad can\n"
        "recover the plaintext CID. The 8-byte pad-id is the public lookup\n"
        "tag that will accompany the encrypted CID on chain.",
        {
            {"txid",        RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The transaction ID to anchor the encrypted IPFS link to."},
            {"cid",         RPCArg::Type::STR,     RPCArg::Optional::NO,
             "Plaintext IPFS CID to encrypt."},
            {"description", RPCArg::Type::STR,     RPCArg::Default{std::string{}},
             "Optional human-readable label (max 256 chars, UTF-8)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "txid",          "Transaction ID"},
                {RPCResult::Type::STR, "pad_id",        "Public pad identifier (hex, 8 bytes)"},
                {RPCResult::Type::STR, "encrypted_cid", "Hex of the ciphertext"},
                {RPCResult::Type::STR, "description",   "Label"},
                {RPCResult::Type::NUM, "timestamp",     "Unix timestamp"},
                {RPCResult::Type::STR, "cid",           "Plaintext CID (echoed for confirmation)"},
                {RPCResult::Type::BOOL,"decrypted",     "True (always — caller already has plaintext)"},
            },
        },
        RPCExamples{
            HelpExampleCli("storeipfslinkencrypted",
                "\"<txid>\" "
                "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\" "
                "\"private doc\"")
            + HelpExampleRpc("storeipfslinkencrypted",
                "\"<txid>\", "
                "\"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\", "
                "\"private doc\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }
            CIPFSPadStore* padstore = GetIPFSPadStore();
            if (!padstore) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS pad store not initialised");
            }

            const uint256 txid     = ParseHashV(request.params[0], "txid");
            const std::string cid  = request.params[1].get_str();
            const std::string desc = request.params.size() > 2
                ? request.params[2].get_str() : "";

            auto parsed = cid::ParseString(cid);
            if (!parsed) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Invalid IPFS CID — must be a valid CIDv0 or CIDv1.");
            }
            if (!IsValidIPFSDescription(desc)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Invalid description: must be valid UTF-8, max 256 bytes, no control characters.");
            }

            const auto& plaintext = parsed->bytes;
            auto pad = otp::GeneratePad(plaintext.size());
            auto encrypted = otp::XorCrypt(
                std::span<const uint8_t>{plaintext},
                std::span<const uint8_t>{pad});
            auto pad_id = otp::ComputePadID(std::span<const uint8_t>{pad});

            CIPFSPad pad_record;
            pad_record.pad_id        = pad_id;
            pad_record.pad           = pad;
            pad_record.txid          = txid;
            pad_record.encrypted_cid = encrypted;
            pad_record.description   = desc;
            pad_record.timestamp     = GetTime<std::chrono::seconds>().count();

            if (!padstore->Insert(pad_record)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "A pad already exists for this txid in the local store.");
            }
            if (!g_ipfslink_db->StoreEncryptedLinkForTx(txid, pad_id, encrypted, desc)) {
                padstore->RemoveByTxid(txid);
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "An encrypted IPFS link already exists for this txid.");
            }

            const auto stored = g_ipfslink_db->GetEncryptedLinkForTx(txid);
            if (!stored) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "Store succeeded but read-back failed.");
            }
            return EncryptedLinkToJSON(*stored, cid);
        },
    };
}

// ---------------------------------------------------------------------------
// getipfslinkencrypted
// ---------------------------------------------------------------------------
static RPCMethod getipfslinkencrypted()
{
    return RPCMethod{
        "getipfslinkencrypted",
        "Retrieve the encrypted IPFS link record for a transaction.\n"
        "If the pad is present in the local pad store the plaintext CID\n"
        "is also returned in the 'cid' field.",
        {
            {"txid", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "Transaction ID."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR,  "txid",          "Transaction ID"},
                {RPCResult::Type::STR,  "pad_id",        "Public pad identifier (hex)"},
                {RPCResult::Type::STR,  "encrypted_cid", "Hex ciphertext"},
                {RPCResult::Type::STR,  "description",   "Label"},
                {RPCResult::Type::NUM,  "timestamp",     "Unix timestamp"},
                {RPCResult::Type::STR,  "cid",           "Decrypted CID (if pad is local)"},
                {RPCResult::Type::BOOL, "decrypted",     "True if cid is present"},
            },
        },
        RPCExamples{
            HelpExampleCli("getipfslinkencrypted", "\"<txid>\"")
            + HelpExampleRpc("getipfslinkencrypted", "\"<txid>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }
            CIPFSPadStore* padstore = GetIPFSPadStore();

            const uint256 txid = ParseHashV(request.params[0], "txid");
            auto rec = g_ipfslink_db->GetEncryptedLinkForTx(txid);
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "No encrypted IPFS link found for txid " + txid.ToString());
            }

            std::optional<std::string> decrypted;
            if (padstore) {
                auto pad = padstore->GetByPadID(rec->pad_id);
                if (pad) {
                    auto plaintext = otp::XorCrypt(
                        std::span<const uint8_t>{rec->encrypted_cid},
                        std::span<const uint8_t>{pad->pad});
                    auto parsed = cid::ParseBytes(plaintext);
                    if (parsed) decrypted = cid::Encode(plaintext);
                }
            }

            return EncryptedLinkToJSON(*rec, decrypted);
        },
    };
}

// ---------------------------------------------------------------------------
// listipfslinksencrypted
// ---------------------------------------------------------------------------
static RPCMethod listipfslinksencrypted()
{
    return RPCMethod{
        "listipfslinksencrypted",
        "List stored encrypted IPFS link records, newest first.\n"
        "Decrypted CIDs are filled in when the corresponding pad is\n"
        "present in the local pad store.",
        {
            {"limit",  RPCArg::Type::NUM, RPCArg::Default{0},
             "Maximum number of records (0 = all)."},
            {"offset", RPCArg::Type::NUM, RPCArg::Default{0},
             "Records to skip from the newest end."},
        },
        RPCResult{
            RPCResult::Type::ARR, "", "",
            {
                {RPCResult::Type::OBJ, "", "",
                 {
                     {RPCResult::Type::STR,  "txid",          "Transaction ID"},
                     {RPCResult::Type::STR,  "pad_id",        "Public pad identifier (hex)"},
                     {RPCResult::Type::STR,  "encrypted_cid", "Hex ciphertext"},
                     {RPCResult::Type::STR,  "description",   "Label"},
                     {RPCResult::Type::NUM,  "timestamp",     "Unix timestamp"},
                     {RPCResult::Type::STR,  "cid",           "Decrypted CID (if pad is local)"},
                     {RPCResult::Type::BOOL, "decrypted",     "True if cid is present"},
                 }},
            },
        },
        RPCExamples{
            HelpExampleCli("listipfslinksencrypted", "")
            + HelpExampleCli("listipfslinksencrypted", "10 0")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }
            CIPFSPadStore* padstore = GetIPFSPadStore();

            const size_t limit  = request.params.size() > 0 && !request.params[0].isNull()
                ? static_cast<size_t>(request.params[0].getInt<int>()) : 0;
            const size_t offset = request.params.size() > 1 && !request.params[1].isNull()
                ? static_cast<size_t>(request.params[1].getInt<int>()) : 0;

            UniValue arr(UniValue::VARR);
            for (const auto& rec : g_ipfslink_db->ListEncryptedLinks(limit, offset)) {
                std::optional<std::string> decrypted;
                if (padstore) {
                    auto pad = padstore->GetByPadID(rec.pad_id);
                    if (pad) {
                        auto plaintext = otp::XorCrypt(
                            std::span<const uint8_t>{rec.encrypted_cid},
                            std::span<const uint8_t>{pad->pad});
                        auto parsed = cid::ParseBytes(plaintext);
                        if (parsed) decrypted = cid::Encode(plaintext);
                    }
                }
                arr.push_back(EncryptedLinkToJSON(rec, decrypted));
            }
            return arr;
        },
    };
}

// ---------------------------------------------------------------------------
// removeipfslinkencrypted
// ---------------------------------------------------------------------------
static RPCMethod removeipfslinkencrypted()
{
    return RPCMethod{
        "removeipfslinkencrypted",
        "Delete the encrypted IPFS link record (and the matching pad in the\n"
        "local pad store) for a given transaction ID.",
        {
            {"txid",     RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "Transaction ID."},
            {"keep_pad", RPCArg::Type::BOOL,    RPCArg::Default{false},
             "If true, keep the pad record in ipfs_pads.dat (only delete the link entry)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::BOOL, "link_removed", "Whether the link entry existed and was removed"},
                {RPCResult::Type::BOOL, "pad_removed",  "Whether the pad entry existed and was removed"},
            },
        },
        RPCExamples{
            HelpExampleCli("removeipfslinkencrypted", "\"<txid>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            if (!g_ipfslink_db) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS link database not initialised");
            }
            const uint256 txid = ParseHashV(request.params[0], "txid");
            const bool keep_pad = request.params.size() > 1 && !request.params[1].isNull()
                ? request.params[1].get_bool() : false;

            const bool link_removed = g_ipfslink_db->RemoveEncryptedLinkForTx(txid);
            bool pad_removed = false;
            if (!keep_pad) {
                if (auto* padstore = GetIPFSPadStore()) {
                    pad_removed = padstore->RemoveByTxid(txid);
                }
            }

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("link_removed", link_removed);
            obj.pushKV("pad_removed",  pad_removed);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// exportipfspad
// ---------------------------------------------------------------------------
static RPCMethod exportipfspad()
{
    return RPCMethod{
        "exportipfspad",
        "Export the OTP pad for a transaction as a hex blob. Hand the blob\n"
        "to the intended recipient over a secure channel; they can call\n"
        "importipfspad to add the pad to their own store and decrypt the CID.\n"
        "Treat the returned blob as a SECRET — anyone with it can read the CID.",
        {
            {"txid", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "Transaction ID whose pad should be exported."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "txid",   "Transaction ID"},
                {RPCResult::Type::STR, "pad_id", "Public pad identifier (hex)"},
                {RPCResult::Type::STR, "blob",   "Hex-encoded pad export blob"},
            },
        },
        RPCExamples{
            HelpExampleCli("exportipfspad", "\"<txid>\"")
            + HelpExampleRpc("exportipfspad", "\"<txid>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            CIPFSPadStore* padstore = GetIPFSPadStore();
            if (!padstore) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS pad store not initialised");
            }
            const uint256 txid = ParseHashV(request.params[0], "txid");
            auto rec = padstore->GetByTxid(txid);
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                    "No pad found for txid " + txid.ToString());
            }

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("txid",   rec->txid.ToString());
            obj.pushKV("pad_id", otp::PadIDToHex(rec->pad_id));
            obj.pushKV("blob",   EncodePadBlob(*rec));
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// importipfspad
// ---------------------------------------------------------------------------
static RPCMethod importipfspad()
{
    return RPCMethod{
        "importipfspad",
        "Import a pad blob previously produced by exportipfspad. The blob is\n"
        "verified by an internal SHA256 checksum and by checking that\n"
        "pad-id == SHA256(pad)[:8]. On success the pad is stored locally and\n"
        "the encrypted CID becomes decryptable on this node.",
        {
            {"blob", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "Hex blob from exportipfspad."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "txid",          "Transaction ID"},
                {RPCResult::Type::STR, "pad_id",        "Pad identifier (hex)"},
                {RPCResult::Type::STR, "encrypted_cid", "Hex of the ciphertext from the blob"},
                {RPCResult::Type::STR, "description",   "Description from the blob"},
                {RPCResult::Type::NUM, "timestamp",     "Original storage timestamp"},
                {RPCResult::Type::NUM, "drained",       "Number of pending pin tracker entries drained for this pad_id"},
                {RPCResult::Type::NUM, "pinned",        "Number of those entries that actually pinned successfully"},
            },
        },
        RPCExamples{
            HelpExampleCli("importipfspad", "\"<hex blob>\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            CIPFSPadStore* padstore = GetIPFSPadStore();
            if (!padstore) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS pad store not initialised");
            }
            auto rec = DecodePadBlob(request.params[0].get_str());
            if (!rec) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Invalid pad blob (bad magic, checksum, or pad-id mismatch).");
            }
            if (!padstore->Insert(*rec)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "A pad already exists for this txid locally.");
            }

            // Drain any pin-tracker entries that were waiting for this pad.
            int drained = 0;
            int pinned  = 0;
            if (auto* tracker = GetIPFSPinTracker()) {
                auto entries = tracker->DrainByPadID(rec->pad_id);
                drained = static_cast<int>(entries.size());
                for (const auto& e : entries) {
                    std::string ctx = (e.source_kind == 0 ? "glc2 anchor=" : "glc3 tx=")
                                       + e.source_txid.ToString()
                                       + " (replayed)";
                    if (TryPinEncryptedNow(e.pad_id, e.encrypted_cid, ctx)) ++pinned;
                }
            }

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("txid",          rec->txid.ToString());
            obj.pushKV("pad_id",        otp::PadIDToHex(rec->pad_id));
            obj.pushKV("encrypted_cid", HexStr(rec->encrypted_cid));
            obj.pushKV("description",   rec->description);
            obj.pushKV("timestamp",     rec->timestamp);
            obj.pushKV("drained",       drained);
            obj.pushKV("pinned",        pinned);
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// listipfspending
// ---------------------------------------------------------------------------
static RPCMethod listipfspending()
{
    return RPCMethod{
        "listipfspending",
        "List encrypted IPFS commitments seen on-chain whose pad has not yet\n"
        "been imported locally. Each entry is auto-pinned when its pad arrives\n"
        "via importipfspad.",
        {},
        RPCResult{
            RPCResult::Type::ARR, "", "",
            {
                {RPCResult::Type::OBJ, "", "",
                 {
                     {RPCResult::Type::STR, "pad_id",            "Pad identifier (hex)"},
                     {RPCResult::Type::STR, "encrypted_cid",     "Ciphertext (hex)"},
                     {RPCResult::Type::STR, "source_kind",       "glc2 or glc3"},
                     {RPCResult::Type::STR, "source_txid",       "Anchor txid (glc2) or carrying txid (glc3)"},
                     {RPCResult::Type::NUM, "first_seen_height", "Block height where the commit was first observed"},
                     {RPCResult::Type::NUM, "first_seen_at",     "Unix timestamp when the commit was first observed"},
                 }},
            },
        },
        RPCExamples{
            HelpExampleCli("listipfspending", "")
            + HelpExampleRpc("listipfspending", "")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            auto* tracker = GetIPFSPinTracker();
            if (!tracker) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS pin tracker not initialised");
            }
            UniValue arr(UniValue::VARR);
            for (const auto& e : tracker->ListPending()) {
                UniValue obj(UniValue::VOBJ);
                obj.pushKV("pad_id",            otp::PadIDToHex(e.pad_id));
                obj.pushKV("encrypted_cid",     HexStr(e.encrypted_cid));
                obj.pushKV("source_kind",       e.source_kind == 0 ? "glc2" : "glc3");
                obj.pushKV("source_txid",       e.source_txid.ToString());
                obj.pushKV("first_seen_height", e.first_seen_height);
                obj.pushKV("first_seen_at",     e.first_seen_at);
                arr.push_back(obj);
            }
            return arr;
        },
    };
}

// ---------------------------------------------------------------------------
// buildipfscommit
// ---------------------------------------------------------------------------
static RPCMethod buildipfscommit()
{
    return RPCMethod{
        "buildipfscommit",
        "Build the OP_RETURN scriptPubKey for a coinbase IPFS commitment.\n"
        "Returns the hex-encoded script that a miner places in the coinbase output.\n"
        "The anchor txid must refer to a non-coinbase transaction in the same block.\n"
        "That transaction must satisfy the IPFSCommitBurnPerByte anti-spam rule.",
        {
            {"txid", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The anchor transaction ID (must be in the same block as the coinbase)."},
            {"cid",  RPCArg::Type::STR,     RPCArg::Optional::NO,
             "The IPFS CID to commit (CIDv0 or CIDv1 multibase string)."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "script_hex",    "Hex-encoded OP_RETURN scriptPubKey"},
                {RPCResult::Type::NUM, "payload_bytes", "Total payload size in bytes (magic+txid+CID)"},
            },
        },
        RPCExamples{
            HelpExampleCli("buildipfscommit",
                "\"<txid>\" \"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleRpc("buildipfscommit",
                "\"<txid>\", \"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            const uint256 txid = ParseHashV(request.params[0], "txid");
            const std::string cid_str = request.params[1].get_str();

            if (!IsValidIPFSCID(cid_str)) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
            }

            auto parsed = cid::ParseString(cid_str);
            if (!parsed) {
                throw JSONRPCError(RPC_INVALID_PARAMETER, "CID parse failed.");
            }

            if (parsed->bytes.size() > IPFS_COMMIT_MAX_CID_SIZE) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    strprintf("CID too large: %d bytes (max %d).",
                              parsed->bytes.size(), IPFS_COMMIT_MAX_CID_SIZE));
            }

            const auto script = BuildIPFSCommitScript(txid, parsed->bytes);
            const size_t payload_bytes = 4 + 32 + parsed->bytes.size(); // magic + txid + CID

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("script_hex",    HexStr(script));
            obj.pushKV("payload_bytes", static_cast<int>(payload_bytes));
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// buildipfscommitencrypted
// ---------------------------------------------------------------------------
static RPCMethod buildipfscommitencrypted()
{
    return RPCMethod{
        "buildipfscommitencrypted",
        "Build the OP_RETURN scriptPubKey for an encrypted (glc2) coinbase\n"
        "IPFS commitment. Either supply an existing pad-id (the pad must\n"
        "already be in the local pad store, identifying which encrypted CID\n"
        "to commit) or pass a fresh plaintext CID together with a txid to\n"
        "have the node generate the pad and persist it before returning.",
        {
            {"txid",    RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "The anchor transaction ID (must be in the same block as the coinbase)."},
            {"cid",     RPCArg::Type::STR,     RPCArg::Default{std::string{}},
             "Plaintext CID to encrypt with a fresh pad (mutually exclusive with pad_id)."},
            {"pad_id",  RPCArg::Type::STR_HEX, RPCArg::Default{std::string{}},
             "Pad-id (16 hex chars) of an existing pad in the local store."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "script_hex",    "Hex-encoded OP_RETURN scriptPubKey"},
                {RPCResult::Type::STR, "pad_id",        "Public pad identifier (hex, 8 bytes)"},
                {RPCResult::Type::STR, "encrypted_cid", "Hex of the ciphertext bytes embedded"},
                {RPCResult::Type::NUM, "payload_bytes", "Total OP_RETURN payload size"},
            },
        },
        RPCExamples{
            HelpExampleCli("buildipfscommitencrypted",
                "\"<txid>\" \"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleCli("buildipfscommitencrypted",
                "\"<txid>\" \"\" \"3b5e038307e44b10\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            CIPFSPadStore* padstore = GetIPFSPadStore();
            if (!padstore) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS pad store not initialised");
            }

            const uint256 txid    = ParseHashV(request.params[0], "txid");
            const std::string cid = request.params.size() > 1 && !request.params[1].isNull()
                ? request.params[1].get_str() : "";
            const std::string pad_id_hex = request.params.size() > 2 && !request.params[2].isNull()
                ? request.params[2].get_str() : "";

            if (cid.empty() == pad_id_hex.empty()) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Exactly one of 'cid' or 'pad_id' must be supplied.");
            }

            std::array<uint8_t, IPFS_COMMIT_PAD_ID_LEN> pad_id_arr{};
            std::vector<uint8_t> encrypted;

            if (!cid.empty()) {
                auto parsed = cid::ParseString(cid);
                if (!parsed) {
                    throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
                }
                if (parsed->bytes.size() > IPFS_COMMIT_V2_MAX_CID_SIZE) {
                    throw JSONRPCError(RPC_INVALID_PARAMETER,
                        strprintf("CID too large for encrypted commitment: %d bytes (max %d).",
                                  parsed->bytes.size(), IPFS_COMMIT_V2_MAX_CID_SIZE));
                }

                auto pad = otp::GeneratePad(parsed->bytes.size());
                encrypted = otp::XorCrypt(
                    std::span<const uint8_t>{parsed->bytes},
                    std::span<const uint8_t>{pad});
                auto id = otp::ComputePadID(std::span<const uint8_t>{pad});
                std::memcpy(pad_id_arr.data(), id.data(), IPFS_COMMIT_PAD_ID_LEN);

                CIPFSPad rec;
                rec.pad_id        = id;
                rec.pad           = pad;
                rec.txid          = txid;
                rec.encrypted_cid = encrypted;
                rec.timestamp     = GetTime<std::chrono::seconds>().count();
                if (!padstore->Insert(rec)) {
                    throw JSONRPCError(RPC_INVALID_PARAMETER,
                        "A pad already exists for this txid in the local store.");
                }
            } else {
                otp::PadID id{};
                if (!otp::PadIDFromHex(pad_id_hex, id)) {
                    throw JSONRPCError(RPC_INVALID_PARAMETER,
                        "pad_id must be exactly 16 hex characters (8 bytes).");
                }
                auto rec = padstore->GetByPadID(id);
                if (!rec) {
                    throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                        "No pad with this id in local store.");
                }
                std::memcpy(pad_id_arr.data(), id.data(), IPFS_COMMIT_PAD_ID_LEN);
                encrypted = rec->encrypted_cid;
            }

            const auto script = BuildIPFSEncryptedCommitScript(txid, pad_id_arr, encrypted);
            const size_t payload_bytes = 4 + 32 + IPFS_COMMIT_PAD_ID_LEN + encrypted.size();

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("script_hex",    HexStr(script));
            obj.pushKV("pad_id",        HexStr(pad_id_arr));
            obj.pushKV("encrypted_cid", HexStr(encrypted));
            obj.pushKV("payload_bytes", static_cast<int>(payload_bytes));
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// buildipfspertxcommit
// ---------------------------------------------------------------------------
static RPCMethod buildipfspertxcommit()
{
    return RPCMethod{
        "buildipfspertxcommit",
        "Build the OP_RETURN scriptPubKey for a per-transaction (glc3) encrypted\n"
        "IPFS commitment. Embed the returned script as one OP_RETURN output of\n"
        "the transaction you intend to anchor; that same transaction is the\n"
        "anchor (no separate coinbase commitment is needed).\n"
        "Either supply a fresh plaintext 'cid' (a fresh pad is generated and\n"
        "associated with 'txid_for_pad' in the local pad store) or an existing\n"
        "'pad_id'. The IPFS_FLAG_ENCRYPTED bit is set automatically.",
        {
            {"txid_for_pad", RPCArg::Type::STR_HEX, RPCArg::Optional::NO,
             "Local lookup key for the pad store (typically the txid you will mine)."},
            {"cid",          RPCArg::Type::STR,     RPCArg::Default{std::string{}},
             "Plaintext CID to encrypt with a fresh pad."},
            {"pad_id",       RPCArg::Type::STR_HEX, RPCArg::Default{std::string{}},
             "16 hex chars: existing pad-id in the local store."},
            {"flags",        RPCArg::Type::NUM,     RPCArg::Default{int{0x02}},
             "Optional flag byte. IPFS_FLAG_ENCRYPTED (0x02) is forced on."},
        },
        RPCResult{
            RPCResult::Type::OBJ, "", "",
            {
                {RPCResult::Type::STR, "script_hex",    "Hex-encoded OP_RETURN scriptPubKey"},
                {RPCResult::Type::STR, "pad_id",        "Pad identifier embedded (hex)"},
                {RPCResult::Type::STR, "encrypted_cid", "Hex of the embedded ciphertext"},
                {RPCResult::Type::NUM, "flags",         "Effective flag byte"},
                {RPCResult::Type::NUM, "payload_bytes", "Total OP_RETURN payload size"},
            },
        },
        RPCExamples{
            HelpExampleCli("buildipfspertxcommit",
                "\"<txid>\" \"QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG\"")
            + HelpExampleCli("buildipfspertxcommit",
                "\"<txid>\" \"\" \"3b5e038307e44b10\"")
        },
        [](const RPCMethod& self, const JSONRPCRequest& request) -> UniValue
        {
            CIPFSPadStore* padstore = GetIPFSPadStore();
            if (!padstore) {
                throw JSONRPCError(RPC_INTERNAL_ERROR, "IPFS pad store not initialised");
            }

            const uint256 txid_for_pad = ParseHashV(request.params[0], "txid_for_pad");
            const std::string cid = request.params.size() > 1 && !request.params[1].isNull()
                ? request.params[1].get_str() : "";
            const std::string pad_id_hex = request.params.size() > 2 && !request.params[2].isNull()
                ? request.params[2].get_str() : "";
            uint8_t flags = request.params.size() > 3 && !request.params[3].isNull()
                ? static_cast<uint8_t>(request.params[3].getInt<int>() & 0xFF)
                : static_cast<uint8_t>(IPFS_FLAG_ENCRYPTED);
            flags |= IPFS_FLAG_ENCRYPTED; // always on

            if ((flags & IPFS_FLAG_RESERVED) != 0) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Reserved flag bits (0xF0) must be zero.");
            }
            if (cid.empty() == pad_id_hex.empty()) {
                throw JSONRPCError(RPC_INVALID_PARAMETER,
                    "Exactly one of 'cid' or 'pad_id' must be supplied.");
            }

            std::array<uint8_t, IPFS_COMMIT_PAD_ID_LEN> pad_id_arr{};
            std::vector<uint8_t> encrypted;

            if (!cid.empty()) {
                auto parsed = cid::ParseString(cid);
                if (!parsed) {
                    throw JSONRPCError(RPC_INVALID_PARAMETER, "Invalid IPFS CID.");
                }
                if (parsed->bytes.size() > IPFS_COMMIT_V3_HARD_CID_CAP) {
                    throw JSONRPCError(RPC_INVALID_PARAMETER,
                        strprintf("CID too large: %d bytes (max %d).",
                                  parsed->bytes.size(), IPFS_COMMIT_V3_HARD_CID_CAP));
                }

                auto pad = otp::GeneratePad(parsed->bytes.size());
                encrypted = otp::XorCrypt(
                    std::span<const uint8_t>{parsed->bytes},
                    std::span<const uint8_t>{pad});
                auto id = otp::ComputePadID(std::span<const uint8_t>{pad});
                std::memcpy(pad_id_arr.data(), id.data(), IPFS_COMMIT_PAD_ID_LEN);

                CIPFSPad rec;
                rec.pad_id        = id;
                rec.pad           = pad;
                rec.txid          = txid_for_pad;
                rec.encrypted_cid = encrypted;
                rec.timestamp     = GetTime<std::chrono::seconds>().count();
                if (!padstore->Insert(rec)) {
                    throw JSONRPCError(RPC_INVALID_PARAMETER,
                        "A pad already exists for this txid in the local store.");
                }
            } else {
                otp::PadID id{};
                if (!otp::PadIDFromHex(pad_id_hex, id)) {
                    throw JSONRPCError(RPC_INVALID_PARAMETER,
                        "pad_id must be exactly 16 hex characters.");
                }
                auto rec = padstore->GetByPadID(id);
                if (!rec) {
                    throw JSONRPCError(RPC_INVALID_ADDRESS_OR_KEY,
                        "No pad with this id in local store.");
                }
                std::memcpy(pad_id_arr.data(), id.data(), IPFS_COMMIT_PAD_ID_LEN);
                encrypted = rec->encrypted_cid;
            }

            const auto script = BuildIPFSPerTxCommitScript(flags, pad_id_arr, encrypted);
            const size_t payload_bytes = IPFS_COMMIT_V3_HEADER_SIZE + encrypted.size();

            UniValue obj(UniValue::VOBJ);
            obj.pushKV("script_hex",    HexStr(script));
            obj.pushKV("pad_id",        HexStr(pad_id_arr));
            obj.pushKV("encrypted_cid", HexStr(encrypted));
            obj.pushKV("flags",         static_cast<int>(flags));
            obj.pushKV("payload_bytes", static_cast<int>(payload_bytes));
            return obj;
        },
    };
}

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------
void RegisterIPFSLinkRPCCommands(CRPCTable& t)
{
    static const CRPCCommand commands[]{
        {"ipfs", &storeipfslink},
        {"ipfs", &getipfslink},
        {"ipfs", &listipfslinks},
        {"ipfs", &removeipfslink},
        {"ipfs", &storeipfslinkencrypted},
        {"ipfs", &getipfslinkencrypted},
        {"ipfs", &listipfslinksencrypted},
        {"ipfs", &removeipfslinkencrypted},
        {"ipfs", &exportipfspad},
        {"ipfs", &importipfspad},
        {"ipfs", &getipfsstatus},
        {"ipfs", &verifyipfscontent},
        {"ipfs", &pinipfscontent},
        {"ipfs", &unpinipfscontent},
        {"ipfs", &listipfspins},
        {"ipfs", &ipfsfindproviders},
        {"ipfs", &listipfspending},
        {"ipfs", &buildipfscommit},
        {"ipfs", &buildipfscommitencrypted},
        {"ipfs", &buildipfspertxcommit},
    };
    for (const auto& c : commands) t.appendCommand(c.name, &c);
}
