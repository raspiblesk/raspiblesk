// Copyright (c) 2026 Glcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <glcoin-build-config.h> // IWYU pragma: keep

#include <ipfspintracker.h>

#include <clientversion.h>
#include <hash.h>
#include <logging.h>
#include <random.h>
#include <streams.h>
#include <tinyformat.h>
#include <util/fs.h>
#include <util/fs_helpers.h>

#include <cstdio>
#include <memory>
#include <stdexcept>

namespace {

constexpr std::array<uint8_t, 4> kFileMagic{'G', 'P', 'T', '1'};
constexpr uint32_t               kFileVersion = 1;

bool SetOwnerOnlyPerms(const fs::path& path)
{
    std::error_code ec;
    fs::permissions(path,
                    fs::perms::owner_read | fs::perms::owner_write,
                    fs::perm_options::replace, ec);
    if (ec) {
        LogInfo("[IPFSPinTracker] could not set 0600 on %s: %s",
                fs::PathToString(path), ec.message());
        return false;
    }
    return true;
}

} // namespace

CIPFSPinTracker::CIPFSPinTracker(const fs::path& datadir)
    : m_path(datadir / "ipfs_pintracker.dat")
{
    if (!Load()) {
        LogInfo("[IPFSPinTracker] starting with empty tracker at %s",
                fs::PathToString(m_path));
    }
}

bool CIPFSPinTracker::RegisterPending(const CIPFSPendingPin& entry)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Key k{entry.pad_id, entry.source_txid};
    auto [it, inserted] = m_pending.emplace(k, entry);
    if (!inserted) return false;
    if (!SaveUnlocked()) {
        m_pending.erase(it);
        return false;
    }
    return true;
}

std::vector<CIPFSPendingPin> CIPFSPinTracker::DrainByPadID(const otp::PadID& pad_id)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<CIPFSPendingPin> out;
    for (auto it = m_pending.begin(); it != m_pending.end(); ) {
        if (it->first.first == pad_id) {
            out.push_back(it->second);
            it = m_pending.erase(it);
        } else {
            ++it;
        }
    }
    if (!out.empty()) {
        if (!SaveUnlocked()) {
            LogInfo("[IPFSPinTracker] WARNING: drained %u entries but Save failed; "
                    "in-memory state ahead of disk", static_cast<unsigned>(out.size()));
        }
    }
    return out;
}

std::vector<CIPFSPendingPin> CIPFSPinTracker::ListPending() const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<CIPFSPendingPin> out;
    out.reserve(m_pending.size());
    for (const auto& [k, v] : m_pending) out.push_back(v);
    return out;
}

size_t CIPFSPinTracker::Count() const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_pending.size();
}

bool CIPFSPinTracker::Save() const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    return SaveUnlocked();
}

bool CIPFSPinTracker::SaveUnlocked() const
{
    const uint16_t randv{FastRandomContext().rand<uint16_t>()};
    fs::path tmp = m_path;
    tmp += strprintf(".%04x", randv);

    FILE* file = fsbridge::fopen(tmp, "wb");
    AutoFile fileout{file};
    if (fileout.IsNull()) {
        LogInfo("[IPFSPinTracker] cannot open %s for write", fs::PathToString(tmp));
        return false;
    }

    try {
        HashedSourceWriter hashwriter{fileout};
        hashwriter << kFileMagic << kFileVersion;
        hashwriter << static_cast<uint32_t>(m_pending.size());
        for (const auto& [k, rec] : m_pending) {
            hashwriter << rec;
        }
        fileout << hashwriter.GetHash();
    } catch (const std::exception& e) {
        LogInfo("[IPFSPinTracker] serialise error: %s", e.what());
        (void)fileout.fclose();
        remove(tmp);
        return false;
    }

    if (!fileout.Commit()) {
        (void)fileout.fclose();
        remove(tmp);
        return false;
    }
    if (fileout.fclose() != 0) {
        remove(tmp);
        return false;
    }

    SetOwnerOnlyPerms(tmp);
    if (!RenameOver(tmp, m_path)) {
        remove(tmp);
        return false;
    }
    SetOwnerOnlyPerms(m_path);
    return true;
}

bool CIPFSPinTracker::Load()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    m_pending.clear();

    FILE* file = fsbridge::fopen(m_path, "rb");
    AutoFile filein{file};
    if (filein.IsNull()) return false;

    try {
        HashVerifier verifier{filein};
        std::array<uint8_t, 4> magic{};
        uint32_t version = 0;
        verifier >> magic >> version;
        if (magic != kFileMagic) {
            LogInfo("[IPFSPinTracker] bad magic in %s", fs::PathToString(m_path));
            return false;
        }
        if (version != kFileVersion) {
            LogInfo("[IPFSPinTracker] unknown version %u in %s",
                    version, fs::PathToString(m_path));
            return false;
        }

        uint32_t count = 0;
        verifier >> count;
        for (uint32_t i = 0; i < count; ++i) {
            CIPFSPendingPin rec;
            verifier >> rec;
            Key k{rec.pad_id, rec.source_txid};
            m_pending.emplace(k, rec);
        }

        uint256 stored_hash;
        filein >> stored_hash;
        if (stored_hash != verifier.GetHash()) {
            LogInfo("[IPFSPinTracker] checksum mismatch in %s",
                    fs::PathToString(m_path));
            m_pending.clear();
            return false;
        }
    } catch (const std::exception& e) {
        LogInfo("[IPFSPinTracker] load error: %s", e.what());
        m_pending.clear();
        return false;
    }

    LogInfo("[IPFSPinTracker] loaded %u pending entries from %s",
            static_cast<unsigned>(m_pending.size()),
            fs::PathToString(m_path));
    return true;
}

static std::unique_ptr<CIPFSPinTracker> g_ipfs_pin_tracker;

void InitIPFSPinTracker(const fs::path& datadir)
{
    g_ipfs_pin_tracker = std::make_unique<CIPFSPinTracker>(datadir);
}

CIPFSPinTracker* GetIPFSPinTracker()
{
    return g_ipfs_pin_tracker.get();
}
