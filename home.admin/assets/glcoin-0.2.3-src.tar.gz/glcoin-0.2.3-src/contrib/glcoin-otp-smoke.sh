#!/usr/bin/env bash
#
# Glcoin OTP-IPFS roundtrip smoke test.
#
# Exercises the off-chain encrypted-CID workflow plus all three on-chain
# script builders against a fresh regtest node. Exits non-zero on any
# unexpected RPC response.
#
# Usage:
#   contrib/glcoin-otp-smoke.sh [path-to-build-bin-dir]
#
# Defaults the build dir to ./build/bin (relative to source root).
#

set -euo pipefail

BIN_DIR="${1:-./build/bin}"
GLCOIND="${BIN_DIR}/glcoind"
GLCOIN_CLI="${BIN_DIR}/glcoin-cli"

if [[ ! -x "$GLCOIND" ]] || [[ ! -x "$GLCOIN_CLI" ]]; then
    echo "ERROR: glcoind or glcoin-cli not found in $BIN_DIR" >&2
    exit 1
fi

DD="$(mktemp -d -t glcoin-otp-smoke-XXXX)"
PORT_RPC=23344
PORT_P2P=23345
RPCU=otpsmoke
RPCP="$(head -c 16 /dev/urandom | od -An -tx1 | tr -d ' \n')"

CLI=("$GLCOIN_CLI" -regtest -datadir="$DD" \
     -rpcport="$PORT_RPC" -rpcuser="$RPCU" -rpcpassword="$RPCP")

cleanup() {
    "${CLI[@]}" stop >/dev/null 2>&1 || true
    sleep 2
    rm -rf "$DD"
}
trap cleanup EXIT

echo ">> launching regtest daemon at $DD"
"$GLCOIND" -regtest -datadir="$DD" \
    -rpcport="$PORT_RPC" -port="$PORT_P2P" \
    -rpcuser="$RPCU" -rpcpassword="$RPCP" \
    -listen=0 -dnsseed=0 -dns=0 -natpmp=0 -daemon

# Wait for RPC.
for i in {1..30}; do
    if "${CLI[@]}" getblockcount >/dev/null 2>&1; then
        break
    fi
    sleep 0.5
done

TX1="0000000000000000000000000000000000000000000000000000000000000001"
TX2="0000000000000000000000000000000000000000000000000000000000000002"
TX3="0000000000000000000000000000000000000000000000000000000000000003"
CID="QmYwAPJzv5CZsnA625s3Xf2nemtYgPpHdWEz79ojWnPbdG"

expect_field() {
    local got="$1" key="$2" want="$3"
    local value
    value="$(python3 -c "import sys,json; print(json.loads(sys.argv[1]).get('$key'))" "$got")"
    if [[ "$value" != "$want" ]]; then
        echo "FAIL: expected $key='$want', got '$value'" >&2
        echo "Response was:" >&2
        echo "$got" >&2
        exit 1
    fi
}

get_field() {
    python3 -c "import sys,json; print(json.loads(sys.argv[1])['$2'])" "$1"
}

echo ">> 1. plaintext storeipfslink/getipfslink"
"${CLI[@]}" storeipfslink "$TX1" "$CID" "plaintext" >/dev/null
RES="$("${CLI[@]}" getipfslink "$TX1")"
expect_field "$RES" cid "$CID"

echo ">> 2. encrypted storeipfslinkencrypted/getipfslinkencrypted"
RES="$("${CLI[@]}" storeipfslinkencrypted "$TX2" "$CID" "doc2")"
expect_field "$RES" decrypted "True"
expect_field "$RES" cid "$CID"
PAD_ID="$(get_field "$RES" pad_id)"
echo "   pad_id=$PAD_ID"

echo ">> 3. export pad blob"
RES="$("${CLI[@]}" exportipfspad "$TX2")"
BLOB="$(get_field "$RES" blob)"
echo "   blob length=${#BLOB}"

echo ">> 4. wipe pad store, restart, encrypted-without-pad returns ciphertext only"
"${CLI[@]}" stop
sleep 3
rm -f "$DD/regtest/ipfs_pads.dat"
"$GLCOIND" -regtest -datadir="$DD" \
    -rpcport="$PORT_RPC" -port="$PORT_P2P" \
    -rpcuser="$RPCU" -rpcpassword="$RPCP" \
    -listen=0 -dnsseed=0 -dns=0 -natpmp=0 -daemon
for i in {1..30}; do
    if "${CLI[@]}" getblockcount >/dev/null 2>&1; then break; fi
    sleep 0.5
done

RES="$("${CLI[@]}" getipfslinkencrypted "$TX2")"
expect_field "$RES" decrypted "False"
if python3 -c "import sys,json; sys.exit(0 if 'cid' not in json.loads(sys.argv[1]) else 1)" "$RES"; then
    echo "   plaintext CID correctly absent without pad"
else
    echo "FAIL: plaintext cid leaked even without pad" >&2
    exit 1
fi

echo ">> 5. import pad, decryption returns"
"${CLI[@]}" importipfspad "$BLOB" >/dev/null
RES="$("${CLI[@]}" getipfslinkencrypted "$TX2")"
expect_field "$RES" decrypted "True"
expect_field "$RES" cid "$CID"

echo ">> 6. tampered blob rejected"
BAD="${BLOB:0:300}ff${BLOB:302}"
if "${CLI[@]}" importipfspad "$BAD" >/dev/null 2>&1; then
    echo "FAIL: tampered blob accepted" >&2
    exit 1
fi
echo "   bad blob correctly rejected"

echo ">> 7. buildipfscommit (plaintext glc1)"
RES="$("${CLI[@]}" buildipfscommit "$TX1" "$CID")"
SCRIPT="$(get_field "$RES" script_hex)"
echo "   script len=$(( ${#SCRIPT}/2 )) bytes; first 12 hex=${SCRIPT:0:12}"

echo ">> 8. buildipfscommitencrypted (glc2 coinbase, fresh CID)"
RES="$("${CLI[@]}" buildipfscommitencrypted "$TX3" "$CID" "")"
SCRIPT="$(get_field "$RES" script_hex)"
expect_field "$RES" payload_bytes "78"
[[ "${SCRIPT:6:8}" == "676c6332" ]] || { echo "FAIL: glc2 magic missing"; exit 1; }
echo "   glc2 script OK"

echo ">> 9. buildipfspertxcommit (glc3 per-tx, fresh CID)"
TX4="0000000000000000000000000000000000000000000000000000000000000004"
RES="$("${CLI[@]}" buildipfspertxcommit "$TX4" "$CID")"
SCRIPT="$(get_field "$RES" script_hex)"
expect_field "$RES" payload_bytes "47"
expect_field "$RES" flags "2"
[[ "${SCRIPT:4:8}" == "676c6333" ]] || { echo "FAIL: glc3 magic missing"; exit 1; }
echo "   glc3 script OK"

echo ">> 10. listipfslinksencrypted shows both TX2 (decrypted) and any other"
RES="$("${CLI[@]}" listipfslinksencrypted)"
COUNT="$(python3 -c "import sys,json; print(len(json.loads(sys.argv[1])))" "$RES")"
echo "   total encrypted links: $COUNT"

echo
echo "ALL OK."
